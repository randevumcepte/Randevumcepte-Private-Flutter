import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../../Backend/backend.dart';
import '../../../../Models/personel.dart';



class SalesReportsPage extends StatefulWidget {
  final dynamic isletmebilgi;
  SalesReportsPage({Key? key, required this.isletmebilgi}) : super(key: key);

  @override
  _SalesReportsPageState createState() => _SalesReportsPageState();
}

class _SalesReportsPageState extends State<SalesReportsPage> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final List<String> _tabs = ['Hizmet', 'Ürün', 'Paket', 'Personel'];
   double toplamSatisTutari = 0;
   double toplamKazanc = 0;
   double toplamAlacak = 0;
  double toplamSatisTutariUrun = 0;
  double toplamKazancUrun = 0;
  double toplamAlacakUrun = 0;
  double toplamSatisTutariPaket = 0;
  double toplamKazancPaket = 0;
  double toplamAlacakPaket = 0;
  final Map<String, DateTimeRange?> _selectedDateRanges = {
    'Hizmet': DateTimeRange(
      start: DateTime(DateTime.now().year, DateTime.now().month, 1),
      end: DateTime.now(),
    ),
    'Ürün': DateTimeRange(
      start: DateTime(DateTime.now().year, DateTime.now().month, 1),
      end: DateTime.now(),
    ),
    'Paket': DateTimeRange(
      start: DateTime(DateTime.now().year, DateTime.now().month, 1),
      end: DateTime.now(),
    ),
    'Personel': DateTimeRange(
      start: DateTime(DateTime.now().year, DateTime.now().month, 1),
      end: DateTime.now(),
    ),
  };

  final Map<String,Personel?> _selectedStaff = {
    'Hizmet': null,
    'Ürün': null,
    'Paket': null,
    'Personel': null,
  };
  bool isLoading = true;
  bool _showFilters = false;
  final DateFormat _dateFormat = DateFormat('dd.MM.yyyy');
  final tlFormat = NumberFormat.currency(locale: 'tr_TR', symbol: '');
  final Map<String, bool> _expandedCards = {};
  late List<dynamic> hizmetRaporu;
  late List<dynamic> urunRaporu;
  late List<dynamic> paketRaporu;
  late List<dynamic> personelRaporu;
  late List<Personel>personeller;
  @override
  void initState() {
    super.initState();
    initialize();
    _tabController = TabController(length: _tabs.length, vsync: this);
  }
  void initialize() async{
    setState(() {
      isLoading = true;
    });
     toplamSatisTutari = 0;
     toplamKazanc = 0;
     toplamAlacak = 0;
     toplamSatisTutariUrun = 0;
     toplamKazancUrun = 0;
     toplamAlacakUrun = 0;
     toplamSatisTutariPaket = 0;
     toplamKazancPaket = 0;
     toplamAlacakPaket = 0;
     hizmetRaporu = await hizmetRaporlari( widget.isletmebilgi['id'].toString(),  DateFormat('yyyy-MM-dd').format(_selectedDateRanges['Hizmet']!.start),  DateFormat('yyyy-MM-dd').format(_selectedDateRanges['Hizmet']!.end), _selectedStaff['Hizmet']?.id?.toString() ?? '');

     urunRaporu = await urunRaporlari( widget.isletmebilgi['id'].toString(),  DateFormat('yyyy-MM-dd').format(_selectedDateRanges['Hizmet']!.start),  DateFormat('yyyy-MM-dd').format(_selectedDateRanges['Ürün']!.end), _selectedStaff['Ürün']?.id?.toString() ?? '');
     paketRaporu = await paketRaporlari( widget.isletmebilgi['id'].toString(),  DateFormat('yyyy-MM-dd').format(_selectedDateRanges['Hizmet']!.start),  DateFormat('yyyy-MM-dd').format(_selectedDateRanges['Paket']!.end),  _selectedStaff['Paket']?.id?.toString() ?? '');
     personelRaporu = await personelRaporlari( widget.isletmebilgi['id'].toString(),  DateFormat('yyyy-MM-dd').format(_selectedDateRanges['Hizmet']!.start),  DateFormat('yyyy-MM-dd').format(_selectedDateRanges['Personel']!.end));

     personeller = await personellistegetir(widget.isletmebilgi['id'].toString());
     hizmetRaporu.forEach((element){
setState(() {
  toplamSatisTutari += element['toplamTutarNumeric'];
  toplamKazanc += element['toplamKazancNumeric'];
  toplamAlacak += element['borcNumeric'];

});


     });
     urunRaporu.forEach((element){
    setState(() {
      toplamSatisTutariUrun += element['toplamTutarNumeric'];
      toplamKazancUrun += element['toplamKazancNumeric'];
      toplamAlacakUrun += element['borcNumeric'];
    });



     });
     paketRaporu.forEach((element){
setState(() {
  toplamSatisTutariPaket += element['toplamTutarNumeric'];
  toplamKazancPaket += element['toplamKazancNumeric'];
  toplamAlacakPaket += element['borcNumeric'];
});



     });
     setState(() {
       isLoading = false;
     });
  }
  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _toggleFilters() {
    setState(() {
      _showFilters = !_showFilters;
    });
  }

  void _showDateFilter(BuildContext context, String tab) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Zaman Aralığı Seç',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    IconButton(
                      icon: Icon(Icons.close),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
              ),
              ..._getQuickDateOptions(tab).map((option) => ListTile(
                leading: Icon(_getDateOptionIcon(option['label'] as String), size: 22),
                title: Text(option['label'] as String),
                trailing: option['range'] == _selectedDateRanges[tab]
                    ? Icon(Icons.check_circle, color: Colors.blue, size: 22)
                    : null,
                onTap: () {
                  setState(() {
                    _selectedDateRanges[tab] = option['range'] as DateTimeRange?;
                    initialize();

                  });
                  Navigator.pop(context);
                },
              )).toList(),
              Divider(height: 20),
              ListTile(
                leading: Icon(Icons.date_range, size: 22),
                title: Text('Özel Tarih Aralığı'),
                trailing: Icon(Icons.chevron_right, size: 22),
                onTap: () => _showCustomDatePicker(context, tab),
              ),
              SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  void _showCustomDatePicker(BuildContext context, String tab) async {
    Navigator.pop(context);

    final DateTimeRange? picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
      currentDate: DateTime.now(),
      saveText: 'Uygula',
      helpText: 'Tarih Aralığı Seçin',
      cancelText: 'İptal',
      confirmText: 'Tamam',
      initialDateRange: _selectedDateRanges[tab],
      builder: (context, child) {
        return Theme(
          data: ThemeData.light().copyWith(
            primaryColor: Colors.blue,
            colorScheme: ColorScheme.light(primary: Colors.blue),
            buttonTheme: ButtonThemeData(textTheme: ButtonTextTheme.primary),
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        _selectedDateRanges[tab] = picked;
      });
    }
  }

  List<Map<String, dynamic>> _getQuickDateOptions(String tab) {
    final now = DateTime.now();
    return [
      {
        'label': 'Bugün',
        'range': DateTimeRange(
          start: DateTime(now.year, now.month, now.day),
          end: DateTime(now.year, now.month, now.day, 23, 59, 59),
        ),
      },
      {
        'label': 'Dün',
        'range': DateTimeRange(
          start: DateTime(now.year, now.month, now.day - 1),
          end: DateTime(now.year, now.month, now.day - 1, 23, 59, 59),
        ),
      },
      {
        'label': 'Bu Ay',
        'range': DateTimeRange(
          start: DateTime(now.year, now.month, 1),
          end: DateTime(now.year, now.month + 1, 0, 23, 59, 59),
        ),
      },
      {
        'label': 'Geçen Ay',
        'range': DateTimeRange(
          start: DateTime(now.year, now.month - 1, 1),
          end: DateTime(now.year, now.month, 0, 23, 59, 59),
        ),
      },
      {
        'label': 'Bu Yıl',
        'range': DateTimeRange(
          start: DateTime(now.year, 1, 1),
          end: DateTime(now.year, 12, 31, 23, 59, 59),
        ),
      },
      {
        'label': 'Geçen Yıl',
        'range': DateTimeRange(
          start: DateTime(now.year - 1, 1, 1),
          end: DateTime(now.year - 1, 12, 31, 23, 59, 59),
        ),
      },
    ];
  }

  IconData _getDateOptionIcon(String label) {
    switch (label) {
      case 'Bugün': return Icons.today_outlined;
      case 'Dün': return Icons.history_outlined;
      case 'Bu Ay': return Icons.calendar_month_outlined;
      case 'Geçen Ay': return Icons.calendar_today_outlined;
      case 'Bu Yıl': return Icons.event_note_outlined;
      case 'Geçen Yıl': return Icons.history_toggle_off_outlined;
      default: return Icons.date_range_outlined;
    }
  }

  void _showStaffFilter(BuildContext context, String tab) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Personel Seç',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  IconButton(
                    icon: Icon(Icons.close, size: 22),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
            ),
            ...personeller.map((staff) => ListTile(
              leading: Icon(Icons.person_outline, size: 22),
              title: Text(staff.personel_adi),
              trailing: _selectedStaff[tab] == staff ||
                  (_selectedStaff[tab] == null && staff == 'Tüm Personeller')
                  ? Icon(Icons.check_circle, color: Colors.blue, size: 22)
                  : null,
              onTap: () {
                setState(() {
                  _selectedStaff[tab] = staff.id == 'Tüm Personeller' ? null : staff;
                  initialize();

                });
                Navigator.pop(context);
              },
            )).toList(),
            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  void _toggleCardExpansion(String cardId) {
    setState(() {
      _expandedCards[cardId] = !(_expandedCards[cardId] ?? false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(
        title: Text('Satış Raporları', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: Icon(_showFilters ? Icons.filter_alt : Icons.filter_alt_outlined,
                size: 24),
            onPressed: _toggleFilters,
            tooltip: 'Filtrele',
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: _tabs.map((tab) => Tab(
            child: Text(
              tab,
              style: TextStyle(fontWeight: FontWeight.w600),
            ),
          )).toList(),
          labelColor: Colors.purple,
          unselectedLabelColor: Colors.grey[600],
          indicatorSize: TabBarIndicatorSize.tab,
          indicatorWeight: 3,
          indicatorColor: Colors.purple,
        ),
      ),
      body: Column(
        children: [
          // Filtre Alanı
          if (_showFilters) _buildFilterSection(),

          // Tab İçerikleri
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildServiceReports(),
                _buildProductReports(),
                _buildPackageReports(),
                _buildStaffReports(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterSection() {
    final currentTab = _tabs[_tabController.index];
    final dateRange = _selectedDateRanges[currentTab];

    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        border: Border(bottom: BorderSide(color: Colors.grey[200]!)),
      ),
      child: Column(
        children: [
          if (currentTab != 'Personel') ...[
            // Zaman Filtresi
            _buildFilterCard(
              icon: Icons.calendar_today_outlined,
              title: 'Zaman Aralığı',
              subtitle: dateRange != null
                  ? '${_dateFormat.format(dateRange.start)} - ${_dateFormat.format(dateRange.end)}'
                  : 'Tüm Zamanlar',
              onTap: () => _showDateFilter(context, currentTab),
              color: Colors.blue,
            ),

            SizedBox(height: 12),

            // Personel Filtresi
            _buildFilterCard(
              icon: Icons.people_outline,
              title: 'Personel',
              subtitle: _selectedStaff[currentTab]?.personel_adi ?? 'Tüm Personeller',
              onTap: () => _showStaffFilter(context, currentTab),
              color: Colors.green,
            ),
          ] else ...[
            // Personel raporlarında sadece zaman filtresi
            _buildFilterCard(
              icon: Icons.calendar_today_outlined,
              title: 'Zaman Aralığı',
              subtitle: dateRange != null
                  ? '${_dateFormat.format(dateRange.start)} - ${_dateFormat.format(dateRange.end)}'
                  : 'Tüm Zamanlar',
              onTap: () => _showDateFilter(context, currentTab),
              color: Colors.orange,
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildFilterCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    required Color color,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
          boxShadow: [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 4,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: color, size: 20),
            ),
            SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[600],
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                ],
              ),
            ),
            Icon(Icons.arrow_drop_down, color: color),
          ],
        ),
      ),
    );
  }

  Widget _buildServiceReports() {
    return isLoading ? Center(child:CircularProgressIndicator()) : SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSummaryCard(
            title: 'Hizmet Özeti',
            icon: Icons.medical_services_outlined,
            color: Colors.blue,
            totalAmount: tlFormat.format(toplamSatisTutari) +' ₺' ,
            stats: [
              _StatInfo(label: 'Toplam Kazanç', value:  tlFormat.format(toplamKazanc) +' ₺', change: '+12%'),
              _StatInfo(label: 'Kalan Alacak', value: tlFormat.format(toplamAlacak) +' ₺', change: '-8%'),
            ],
          ),

          SizedBox(height: 20),

          Text('Hizmet Detayları', style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          )),
          SizedBox(height: 12),

          ...hizmetRaporu.asMap().entries.map((entry) {
            int index = entry.key;
            var item = entry.value;
            return _buildExpandableServiceCard(item, index);
          }).toList(),
        ],
      ),
    );
  }

  Widget _buildProductReports() {
    return isLoading ?  Center(child:CircularProgressIndicator()) : SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSummaryCard(
            title: 'Ürün Özeti',
            icon: Icons.shopping_bag_outlined,
            color: Colors.green,
            totalAmount: tlFormat.format(toplamSatisTutariUrun)+' ₺',
            stats: [
              _StatInfo(label: 'Toplam Kazanç', value: tlFormat.format(toplamKazancUrun)+' ₺', change: '+8%'),
              _StatInfo(label: 'Kalan Alacak', value: tlFormat.format(toplamAlacakUrun)+' ₺', change: '-12%'),
            ],
          ),

          SizedBox(height: 20),

          Text('Ürün Detayları', style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          )),
          SizedBox(height: 12),

          ...urunRaporu.asMap().entries.map((entry) {
            int index = entry.key;
            var item = entry.value;
            return _buildExpandableProductCard(item, index);
          }).toList(),
        ],
      ),
    );
  }

  Widget _buildPackageReports() {
    return isLoading ?  Center(child:CircularProgressIndicator()) : SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSummaryCard(
            title: 'Paket Özeti',
            icon: Icons.card_giftcard_outlined,
            color: Colors.purple,
            totalAmount: tlFormat.format(toplamSatisTutariPaket) + ' ₺',
            stats: [
              _StatInfo(label: 'Toplam Kazanç', value: tlFormat.format(toplamKazancPaket) + ' ₺', change: '+15%'),
              _StatInfo(label: 'Kalan Alacak', value: tlFormat.format(toplamAlacakPaket) + ' ₺', change: '-5%'),
            ],
          ),

          SizedBox(height: 20),

          Text('Paket Detayları', style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          )),
          SizedBox(height: 12),

          ...paketRaporu.asMap().entries.map((entry) {
            int index = entry.key;
            var item = entry.value;
            return _buildExpandablePackageCard(item, index);
          }).toList(),
        ],
      ),
    );
  }

  Widget _buildStaffReports() {
    return isLoading ?  Center(child:CircularProgressIndicator()) : SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          Text('Personel Detayları', style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          )),
          SizedBox(height: 12),

          ...personelRaporu.asMap().entries.map((entry) {
            int index = entry.key;
            var item = entry.value;
            return _buildExpandableStaffCard(item, index);
          }).toList(),
        ],
      ),
    );
  }

  Widget _buildSummaryCard({
    required String title,
    required IconData icon,
    required Color color,
    required String totalAmount,
    required List<_StatInfo> stats,
  }) {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(icon, color: color, size: 24),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      )),
                      SizedBox(height: 4),
                      Text('Toplam Gelir', style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey[600],
                      )),
                    ],
                  ),
                ),
                Text(totalAmount, style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: color,
                )),
              ],
            ),
            SizedBox(height: 20),
            GridView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: MediaQuery.of(context).size.width > 600 ? 2 : 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 1.4,
              ),
              itemCount: stats.length,
              itemBuilder: (context, index) {
                final stat = stats[index];
                final isPositive = stat.change.startsWith('+');
                return Container(
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.grey[50],
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.grey[200]!),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(stat.label, style: TextStyle(
                        fontSize: 11,
                        color: Colors.grey[600],
                        fontWeight: FontWeight.w500,
                      )),
                      SizedBox(height: 4),
                      Text(stat.value, style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      )),

                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildExpandableServiceCard(Map<String, dynamic> item, int index) {
    final cardId = 'service_$index';
    final isExpanded = _expandedCards[cardId] ?? false;

    final List<Map<String, dynamic>> details = [
      {'label': 'Satış Adeti', 'value': '${item['adet']}', 'icon': Icons.format_list_numbered_outlined.codePoint.toString()},
      {'label': 'Hizmet Geliri', 'value': '${item['toplam_tutar']} ₺', 'icon': Icons.attach_money_outlined.codePoint.toString()},
      {'label': 'Toplam Kazanç', 'value': '${item['toplamKazanc']} ₺', 'icon': Icons.trending_up_outlined.codePoint.toString()},
      {'label': 'Kalan Alacak', 'value': '${item['borc']} ₺', 'icon': Icons.pending_actions_outlined.codePoint.toString()},
    ];

    return Card(
      margin: EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        onTap: () => _toggleCardExpansion(cardId),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(

            children: [
              Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: Colors.blue.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(Icons.spa_outlined, color: Colors.blue, size: 24),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          item['hizmet_adi'],
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                          ),
                        ),
                        SizedBox(height: 4),

                      ],
                    ),
                  ),

                  SizedBox(width: 8),
                  Icon(
                    isExpanded ? Icons.expand_less : Icons.expand_more,
                    color: Colors.grey[500],
                  ),
                ],
              ),

              if (isExpanded) ...[
                SizedBox(height: 16),
                Divider(height: 1),
                SizedBox(height: 16),
                GridView.builder(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: MediaQuery.of(context).size.width > 600 ? 4 : 2,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: 1.8,
                  ),
                  itemCount: details.length,
                  itemBuilder: (context, subIndex) {
                    final detail = details[subIndex];
                    return Container(
                      padding: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.blue.withOpacity(0.05),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.blue.withOpacity(0.2)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Row(
                            children: [
                              Icon(IconData(int.parse(detail['icon']!), fontFamily: 'MaterialIcons'),
                                  color: Colors.blue, size: 16),
                              SizedBox(width: 6),
                              Expanded(
                                child: Text(
                                  detail['label']!,
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: Colors.grey[700],
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 4),
                          Text(
                            detail['value']!,
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Colors.blue,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildExpandableProductCard(Map<String,dynamic>item, int index) {
    final cardId = 'product_$index';
    final isExpanded = _expandedCards[cardId] ?? false;

    final List<Map<String, String>> details = [
       {'label': 'Satış Adeti', 'value': '${item['adet']}', 'icon': Icons.format_list_numbered_outlined.codePoint.toString()},
      {'label': 'Ürün Geliri', 'value': '${item['toplam_tutar']} ₺', 'icon': Icons.monetization_on_outlined.codePoint.toString()},
      {'label': 'Toplam Kazanç', 'value': '${item['toplamKazanc']} ₺', 'icon': Icons.trending_up_outlined.codePoint.toString()},
      {'label': 'Kalan Alacak', 'value': '${item['borc']} ₺', 'icon': Icons.pending_outlined.codePoint.toString()},
    ];

    return Card(
      margin: EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        onTap: () => _toggleCardExpansion(cardId),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: Colors.green.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(Icons.shopping_basket_outlined, color: Colors.green, size: 24),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          item['urun_adi'],
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                          ),
                        ),
                        SizedBox(height: 4),

                      ],
                    ),
                  ),

                  SizedBox(width: 8),
                  Icon(
                    isExpanded ? Icons.expand_less : Icons.expand_more,
                    color: Colors.grey[500],
                  ),
                ],
              ),

              if (isExpanded) ...[
                SizedBox(height: 16),
                Divider(height: 1),
                SizedBox(height: 16),
                GridView.builder(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: MediaQuery.of(context).size.width > 600 ? 4 : 2,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: 1.8,
                  ),
                  itemCount: details.length,
                  itemBuilder: (context, subIndex) {
                    final detail = details[subIndex];
                    return Container(
                      padding: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.green.withOpacity(0.05),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.green.withOpacity(0.2)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Row(
                            children: [
                              Icon(IconData(int.parse(detail['icon']!), fontFamily: 'MaterialIcons'),
                                  color: Colors.green, size: 16),
                              SizedBox(width: 6),
                              Expanded(
                                child: Text(
                                  detail['label']!,
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: Colors.grey[700],
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 4),
                          Text(
                            detail['value']!,
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Colors.green,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildExpandablePackageCard(Map<String,dynamic>item, int index) {
    final cardId = 'package_$index';
    final isExpanded = _expandedCards[cardId] ?? false;

    final List<Map<String, String>> details = [
      {'label': 'Satış Adeti', 'value': '${item['adet']}', 'icon': Icons.format_list_numbered_outlined.codePoint.toString()},
      {'label': 'Paket Geliri', 'value': '${item['toplam_tutar']} ₺', 'icon': Icons.account_balance_wallet_outlined.codePoint.toString()},
      {'label': 'Toplam Kazanç', 'value': '${item['toplamKazanc']} ₺', 'icon': Icons.bar_chart_outlined.codePoint.toString()},
      {'label': 'Kalan Alacak', 'value': '${item['borc']} ₺', 'icon': Icons.schedule_outlined.codePoint.toString()},
    ];

    return Card(
      margin: EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        onTap: () => _toggleCardExpansion(cardId),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: Colors.purple.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(Icons.all_inclusive_outlined, color: Colors.purple, size: 24),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          item['paket_adi'],
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                          ),
                        ),
                        SizedBox(height: 4),

                      ],
                    ),
                  ),

                  SizedBox(width: 8),
                  Icon(
                    isExpanded ? Icons.expand_less : Icons.expand_more,
                    color: Colors.grey[500],
                  ),
                ],
              ),

              if (isExpanded) ...[
                SizedBox(height: 16),
                Divider(height: 1),
                SizedBox(height: 16),
                GridView.builder(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: MediaQuery.of(context).size.width > 600 ? 4 : 2,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: 1.8,
                  ),
                  itemCount: details.length,
                  itemBuilder: (context, subIndex) {
                    final detail = details[subIndex];
                    return Container(
                      padding: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.purple.withOpacity(0.05),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.purple.withOpacity(0.2)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Row(
                            children: [
                              Icon(IconData(int.parse(detail['icon']!), fontFamily: 'MaterialIcons'),
                                  color: Colors.purple, size: 16),
                              SizedBox(width: 6),
                              Expanded(
                                child: Text(
                                  detail['label']!,
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: Colors.grey[700],
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 4),
                          Text(
                            detail['value']!,
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Colors.purple,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildExpandableStaffCard(Map<String,dynamic> item ,int index) {
    final cardId = 'staff_$index';
    final isExpanded = _expandedCards[cardId] ?? false;

    final List<Map<String, String>> stats = [
      {'label': 'Hizmet Geliri', 'value': '${item['hizmet_geliri']} ₺',},
      {'label': 'Hizmet Primi', 'value': '${item['hizmet_primi']} ₺', },
      {'label': 'Ürün Geliri', 'value': '${item['urun_geliri']} ₺', },
      {'label': 'Ürün Primi', 'value': '${item['urun_primi']} ₺',},
      {'label': 'Paket Geliri', 'value': '${item['paket_geliri']} ₺', },
      {'label': 'Paket Primi', 'value': '${item['paket_primi']} ₺'},
    ];

    return Card(
      margin: EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        onTap: () => _toggleCardExpansion(cardId),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: Colors.orange.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: Icon(Icons.person_outline, color: Colors.orange, size: 24),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          item['personel_adi'] ?? 'Belirtilmemiş',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                          ),
                        ),

                      ],
                    ),
                  ),

                  SizedBox(width: 8),
                  Icon(
                    isExpanded ? Icons.expand_less : Icons.expand_more,
                    color: Colors.grey[500],
                  ),
                ],
              ),

              if (isExpanded) ...[
                SizedBox(height: 16),
                Divider(height: 1),
                SizedBox(height: 16),
                GridView.builder(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: MediaQuery.of(context).size.width > 600 ? 3 : 2,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: 2.2,
                  ),
                  itemCount: stats.length,
                  itemBuilder: (context, subIndex) {
                    final stat = stats[subIndex];
                    return Container(
                      padding: EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.orange.withOpacity(0.05),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.orange.withOpacity(0.2)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            stat['label']!,
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey[700],
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          SizedBox(height: 2),
                          Text(
                            stat['value']!,
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Colors.orange,
                            ),
                          ),

                        ],
                      ),
                    );
                  },
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _StatInfo {
  final String label;
  final String value;
  final String change;

  _StatInfo({
    required this.label,
    required this.value,
    required this.change,
  });
}