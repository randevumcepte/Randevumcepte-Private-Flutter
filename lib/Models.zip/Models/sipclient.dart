﻿import 'package:sip_ua/sip_ua.dart';

class SipClient {
  late UaSettings settings;
  late SIPUAHelper? _helper;

  SipService() {
    settings = UaSettings();
    settings.uri = 'sip:31@santral2.randevumcepte.com.tr';
    settings.webSocketUrl = 'wss://santral2.randevumcepte.com.tr:8089/ws';
    settings.authorizationUser = '31';
    settings.password='cd73c70e216e55f3a12d44ff30ba73cd';
    settings.displayName = '31';
    _helper!.start(settings);


  }


}