﻿class Salonlar {
  Salonlar({
    required this.id,
    required this.takvim,
    required this.randevu,


  });
  final String id;
  final String takvim;
  final String randevu;




  factory Salonlar.fromJson(Map<String, dynamic> json) {
    return Salonlar(
      takvim: json["randevu_saat_araligi"].toString(),
      randevu: json["randevu_takvim_turu"].toString(),

      id: json["id"].toString(),

    );
  }
}