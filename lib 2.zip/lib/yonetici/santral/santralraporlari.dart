﻿import 'dart:convert';
import 'dart:developer';

import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:randevu_sistem/Frontend/datetimeformatting.dart';
import 'package:randevu_sistem/Frontend/yukseltbutonu.dart';
import 'package:randevu_sistem/yonetici/santral/callkit/main.dart';
import 'package:randevu_sistem/yonetici/santral/sipsrc/callscreen.dart';
import 'package:randevu_sistem/yonetici/santral/sipsrc/dialpad.dart';
import 'package:share_plus/share_plus.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';

import '../../../../Frontend/popupdialogs.dart';
import '../../../../Models/randevular.dart';

import 'package:randevu_sistem/Backend/backend.dart';
import 'package:randevu_sistem/Frontend/altyuvarlakmenu.dart';
import 'package:randevu_sistem/Models/form.dart';
import 'package:randevu_sistem/Frontend/sfdatatable.dart';

import '../../Frontend/dialpad.dart';
import '../../Frontend/filedownload.dart';
import '../../Frontend/indexedstack.dart';
import '../../Models/cdr.dart';
import '../../Models/personel.dart';
import '../../Models/sipclient.dart';
import '../../Models/user.dart';
import '../../main.dart';
import '../diger/menu/musteriler/yeni_musteri.dart';
import 'arama.dart';
import 'arama.dart';
//import 'package:sip_ua/sip_ua.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'package:permission_handler/permission_handler.dart';
import 'package:percent_indicator/percent_indicator.dart';

class CDRRaporlari extends StatefulWidget {
  final dynamic isletmebilgi;
  final DialPadManager dialPadManager;
  final GlobalKey<ScaffoldMessengerState> scaffoldMessengerKey;
  final Kullanici kullanici;
  final int kullanicirolu;
  const CDRRaporlari({Key? key, required this.kullanicirolu, required this.isletmebilgi, required this.dialPadManager, required this.scaffoldMessengerKey, required this.kullanici}) : super(key: key);

  @override
  _CDRState createState() => _CDRState();
}

class _CDRState extends State<CDRRaporlari> {
  ScrollController _scrollController = ScrollController();
  DateTime _sonYuklenenTarih = DateTime.now();
  ValueNotifier<int> downloadProgressNotifier = ValueNotifier(0);
  SnackBar? currentSnackbar;
  bool isSnackbarVisible = false;
  final AudioPlayer _audioPlayer = AudioPlayer();
  late OverlayEntry _dialPadOverlayEntry;
  List<bool> _menuVisibility = [];
  late List<Cdr> items;
  late List<Cdr> filteredItems;
  late RandevuDataSource _randevuDataGridSource;
  List<Randevu> _randevu = [];
  late List<Randevu> _filteredRandevu = [];
  late String? seciliisletme;
  bool _isLoading = true;
  bool verigetiriliyor = false;
  int totalPages = 1;
  DateTime? startDate;
  DateTime? endDate;
  List<String> dahililer = [];

  TextEditingController baslangictarihi = TextEditingController();
  TextEditingController bitistarihi = TextEditingController();
  TextEditingController _controller = TextEditingController();

  @override
  void initState() {
    super.initState();

    baslangictarihi.text = '';
    bitistarihi.text = '';
    log('Santral rapor');
    initialize();

    _scrollController.addListener(() {
      _kontrolListeBoyutu();
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      log("WidgetsBinding çalıştı. ScrollController bağlandı mı kontrol ediliyor...");
      _kontrolListeBoyutu();
    });
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }

  Future<void> initialize() async {
    setState(() {
      _isLoading = true;
    });

    List<Personel> personelListesi = [];
    seciliisletme = widget.isletmebilgi['id']?.toString();
    print('initialize: seciliisletme = $seciliisletme');

    if (seciliisletme == null) {
      print('initialize: seciliisletme null, veri yükleme iptal ediliyor');
      setState(() {
        _isLoading = false;
      });
      return;
    }

    var personellerRaw = widget.isletmebilgi['personeller'];

    if (personellerRaw != null && personellerRaw is List) {
      personelListesi = personellerRaw.map((e) => Personel.fromJson(e)).toList();
    } else {
      personelListesi = [];
    }

    dahililer.clear();
    for (var element in personelListesi) {
      if (element.dahili_no != 'null') dahililer.add(element.dahili_no);
    }
    print('initialize: dahililer = ${jsonEncode(dahililer)}');

    try {
      print('initialize: santralraporlari çağrısı başlıyor...');
      items = await santralraporlari(seciliisletme!, baslangictarihi.text, bitistarihi.text);
      print('initialize: santralraporlari çağrısı bitti, items.length = ${items.length}');
    } catch (e, st) {
      print('initialize: santralraporlari hata: $e');
      print(st);
      items = [];
    }

    filteredItems = items;
    _menuVisibility = List.generate(filteredItems.length, (index) => false);

    try {
      _sonYuklenenTarih = DateTime.parse(baslangictarihi.text);
    } catch (e) {
      print('initialize: tarih parse hatası: $e');
      _sonYuklenenTarih = DateTime.now();
    }

    setState(() {
      _isLoading = false;
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      Future.delayed(Duration(milliseconds: 100), () {
        if (mounted) {
          print("initialize: scroll kontrol ediliyor...");
          _kontrolListeBoyutu();
        }
      });
    });
  }

  void _kontrolListeBoyutu() {
    if (!_scrollController.hasClients) {
      log("ScrollController henüz bağlı değil.");
      return;
    }

    final double maxScrollExtent = _scrollController.position.maxScrollExtent;
    final double viewportHeight = _scrollController.position.viewportDimension;

    log("maxScrollExtent: $maxScrollExtent, viewportHeight: $viewportHeight");

    if ((maxScrollExtent < viewportHeight || _scrollController.position.pixels >= maxScrollExtent) && !verigetiriliyor) {
      log("Liste ekranı doldurmuyor veya sonuna gelindi, yeni veri yükleniyor...");
    }
  }

  void filterSearchResults(String query) {
    DateTime? start = startDate;
    DateTime? end = endDate;

    if (query.isNotEmpty || (start != null && end != null)) {
      setState(() {
        filteredItems = items.where((item) {
          print("Filtering item: ${item.musteri}");

          bool matchesQuery = item.musteri.toLowerCase().contains(query.toLowerCase()) ||
              item.telefon.toLowerCase().contains(query.toLowerCase());

          DateTime itemDate;
          try {
            itemDate = DateTime.parse(item.tarih);
          } catch (e) {
            print("Error parsing date: ${item.tarih}");
            return false;
          }

          log("is after start " + itemDate.isAfter(start!).toString());
          log("is before end " + itemDate.isBefore(end!).toString());
          bool matchesDate = (start == null || itemDate.isAfter(start)) &&
              (end == null || itemDate.isBefore(end));

          print("Matches Query: $matchesQuery, Matches Date: $matchesDate");
          return matchesQuery && matchesDate;
        }).toList();
      });
    } else {
      setState(() {
        filteredItems = items;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final double height = MediaQuery.of(context).size.height;
    final double appBarHeight = AppBar().preferredSize.height;
    final double statusBarHeight = MediaQuery.of(context).padding.top;
    final double totalTopHeight = appBarHeight + statusBarHeight;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Santral',
          style: TextStyle(color: Colors.black, fontSize: 18),
        ),
        toolbarHeight: 60,
        actions: <Widget>[
          if (widget.isletmebilgi["demo_hesabi"].toString() == "1")
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: SizedBox(
                  width: 100,
                  child: YukseltButonu(isletme_bilgi: widget.isletmebilgi,)
              ),
            ),
          IconButton(
            onPressed: () {
              showModalBottomSheet(
                  context: context,
                  builder: (context) {
                    return StatefulBuilder(builder: (context, setStateSB) {
                      return Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          SizedBox(height: 20),
                          Container(
                            padding: const EdgeInsets.only(left: 20.0),
                            child: Text(
                              'Başlangıç Tarihi',
                              style: TextStyle(
                                  fontSize: 16,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold
                              ),
                            ),
                          ),
                          SizedBox(height: 10),
                          Container(
                            alignment: Alignment.center,
                            margin: EdgeInsets.only(left: 20, right: 20),
                            height: 40,
                            width: double.infinity,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              border: Border.all(color: Color(0xFF6A1B9A)),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: TextField(
                              controller: baslangictarihi,
                              enabled: true,
                              decoration: InputDecoration(
                                focusColor: Color(0xFF6A1B9A),
                                hoverColor: Color(0xFF6A1B9A),
                                hintStyle: TextStyle(color: Color(0xFF6A1B9A)),
                                contentPadding: EdgeInsets.all(15.0),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(color: Color(0xFF6A1B9A)),
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(color: Color(0xFF6A1B9A)),
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                              ),
                              readOnly: true,
                              onTap: () async {
                                DateTime? pickedDate = await showDatePicker(
                                    context: context,
                                    initialDate: DateTime.now(),
                                    firstDate: DateTime(1950),
                                    lastDate: DateTime(2100)
                                );

                                if (pickedDate != null) {
                                  String formattedDate = DateFormat('yyyy-MM-dd').format(pickedDate);
                                  setStateSB(() {
                                    baslangictarihi.text = formattedDate;
                                    startDate = DateTime.parse(baslangictarihi.text);
                                  });
                                }
                              },
                            ),
                          ),
                          SizedBox(height: 20),
                          Container(
                            padding: const EdgeInsets.only(left: 20.0),
                            child: Text(
                              'Bitiş Tarihi',
                              style: TextStyle(
                                  fontSize: 16,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold
                              ),
                            ),
                          ),
                          SizedBox(height: 10),
                          Container(
                            alignment: Alignment.center,
                            margin: EdgeInsets.only(left: 20, right: 20),
                            height: 40,
                            width: double.infinity,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              border: Border.all(color: Color(0xFF6A1B9A)),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: TextField(
                              controller: bitistarihi,
                              enabled: true,
                              decoration: InputDecoration(
                                focusColor: Color(0xFF6A1B9A),
                                hoverColor: Color(0xFF6A1B9A),
                                hintStyle: TextStyle(color: Color(0xFF6A1B9A)),
                                contentPadding: EdgeInsets.all(15.0),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(color: Color(0xFF6A1B9A)),
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(color: Color(0xFF6A1B9A)),
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                              ),
                              readOnly: true,
                              onTap: () async {
                                DateTime? pickedDate = await showDatePicker(
                                    context: context,
                                    initialDate: DateTime.now(),
                                    firstDate: DateTime(1950),
                                    lastDate: DateTime(2100)
                                );

                                if (pickedDate != null) {
                                  String formattedDate = DateFormat('yyyy-MM-dd').format(pickedDate);
                                  setStateSB(() {
                                    bitistarihi.text = formattedDate;
                                    endDate = DateTime.parse(bitistarihi.text);
                                  });
                                }
                              },
                            ),
                          ),
                          SizedBox(height: 20),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              ElevatedButton(
                                onPressed: () {
                                  setState(() {
                                    Navigator.of(context).pop();
                                    filterSearchResults(_controller.text);
                                  });
                                },
                                child: Text('Arama Kayıtlarını Göster'),
                                style: ElevatedButton.styleFrom(
                                  foregroundColor: Colors.white,
                                  backgroundColor: Colors.purple[800],
                                ),
                              ),
                              SizedBox(width: 10),
                              ElevatedButton(
                                onPressed: () {
                                  setState(() {
                                    baslangictarihi.text = '';
                                    bitistarihi.text = '';
                                    startDate = null;
                                    endDate = null;
                                    Navigator.of(context).pop();
                                    filterSearchResults(_controller.text);
                                  });
                                },
                                child: Text('Filtreyi Sıfırla'),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.black,
                                  foregroundColor: Colors.white,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 50),
                        ],
                      );
                    });
                  }
              );
            },
            icon: Icon(Icons.filter_list_outlined, color: Colors.black),
            iconSize: 26,
          ),
          IconButton(
            onPressed: () {
              log('dialpad açılıyor');
              widget.dialPadManager.updateDialPad(context, true, "", widget.kullanici);
            },
            icon: Icon(Icons.phone, color: Colors.black),
            iconSize: 26,
          ),
        ],
        backgroundColor: Colors.white,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextFormField(
              controller: _controller,
              onChanged: filterSearchResults,
              keyboardType: TextInputType.text,
              decoration: InputDecoration(
                hintText: 'Müşteri/Danışan Adı...',
                enabled: true,
                focusColor: Color(0xFF6A1B9A),
                hoverColor: Color(0xFF6A1B9A),
                hintStyle: TextStyle(color: Color(0xFF6A1B9A)),
                contentPadding: EdgeInsets.all(5.0),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Color(0xFF6A1B9A)),
                  borderRadius: BorderRadius.circular(10.0),
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Color(0xFF6A1B9A)),
                  borderRadius: BorderRadius.circular(10.0),
                ),
              ),
            ),
          ),
          Expanded( // Burada Expanded kullanarak kalan tüm alanı kaplamasını sağlıyoruz
            child: _isLoading
                ? Center(child: CircularProgressIndicator())
                : filteredItems.isEmpty
                ? Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  'images/pbx.png',
                  width: 150,
                  height: 150,
                ),
                SizedBox(height: 20),
                Text(
                  "Yaptığınız aramalar burada gösterilecektir.",
                  style: TextStyle(fontSize: 18, color: Colors.grey),
                ),
              ],
            )
                : ListView.builder(
              controller: _scrollController, // ScrollController'ı buraya bağlıyoruz
              padding: EdgeInsets.only(bottom: 8.0), // Alt boşluğu azaltıyoruz
              itemCount: filteredItems.length,
              itemBuilder: (BuildContext context, int index) {
                final bildirimData = filteredItems[index];
                return Column(
                  children: [
                    Card(
                      color: Colors.white,
                      elevation: 3.0,
                      margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
                      child: ListTile(
                        onTap: () {
                          setState(() {
                            for (int i = 0; i < _menuVisibility.length; i++) {
                              if (i == index) {
                                _menuVisibility[i] = !_menuVisibility[i];
                              } else {
                                _menuVisibility[i] = false;
                              }
                            }
                          });
                        },
                        leading: getCdrStatIcon(bildirimData.durum),
                        title: Text(
                          bildirimData.musteri != '' ? bildirimData.musteri : bildirimData.telefon,
                          style: TextStyle(color: Colors.black),
                        ),
                        subtitle: Row(
                          children: [
                            Text(
                              bildirimData.tarih + ' ' + bildirimData.saat,
                              style: TextStyle(color: Colors.black),
                            ),
                            SizedBox(width: 4),
                            Icon(Icons.person, color: Colors.black),
                            SizedBox(width: 4),
                            Expanded(
                              child: Text(
                                (bildirimData.gorusmeyiyapan == "null" ? "Santral" : bildirimData.gorusmeyiyapan),
                                style: TextStyle(color: Colors.black),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                        trailing: TextButton(
                          onPressed: () {
                            widget.dialPadManager.updateDialPad(context, true, "0" + bildirimData.telefon, widget.kullanici);
                          },
                          child: Icon(Icons.phone, color: Colors.deepPurple),
                        ),
                        contentPadding: EdgeInsets.symmetric(horizontal: 1.0, vertical: 0),
                      ),
                    ),
                    if (_menuVisibility[index] && (bildirimData.durum == "2" || bildirimData.durum == "3" || bildirimData.musteri == ""))
                      Container(
                        margin: EdgeInsets.symmetric(horizontal: 16.0, vertical: 4.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            bildirimData.durum == "2" || bildirimData.durum == "3"
                                ? TextButton(
                              onPressed: () {
                                seskaydinical(bildirimData.seskaydi);
                              },
                              child: Icon(Icons.play_circle_fill, color: Colors.green),
                            )
                                : SizedBox.shrink(),
                            bildirimData.durum == "2" || bildirimData.durum == "3"
                                ? TextButton(
                              onPressed: () {
                                String dosyaAdi = '${bildirimData.musteri.isNotEmpty ? bildirimData.musteri : bildirimData.telefon}_${bildirimData.tarih}.wav';
                                seskaydiniindir(bildirimData.seskaydi, dosyaAdi, context);
                              },
                              child: Icon(Icons.file_download, color: Colors.deepPurple),
                            )
                                : SizedBox.shrink(),
                            bildirimData.musteri == ''
                                ? TextButton(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => Yenimusteri(
                                      kullanicirolu: widget.kullanicirolu,
                                      isletmebilgi: widget.isletmebilgi,
                                      isim: "",
                                      telefon: bildirimData.telefon,
                                      sadeceekranikapat: true,
                                    ),
                                  ),
                                );
                              },
                              child: Icon(Icons.person_add, color: Colors.green),
                            )
                                : SizedBox.shrink(),
                          ],
                        ),
                      ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  String getCdrStat(String durum) {
    switch (durum) {
      case "1":
        return 'Ulaşılamadı';
      case "2":
        return 'Giden arama';
      case "3":
        return "Gelen arama";
      case "0":
        return "Cevapsız arama";
      default:
        return "Bilinmeyen";
    }
  }

  Widget getCdrStatIcon(String durum) {
    switch (durum) {
      case "1":
        return Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.blueAccent,
          ),
          child: Icon(Icons.call_missed_outgoing, size: 25, color: Colors.white),
        );
      case "2":
        return Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.purple,
          ),
          child: Icon(Icons.call_made, size: 25, color: Colors.white),
        );
      case "3":
        return Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.green,
          ),
          child: Icon(Icons.call_received, size: 25, color: Colors.white),
        );
      case "0":
        return Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.red[600],
          ),
          child: Icon(Icons.call_missed, size: 25, color: Colors.white),
        );
      case "4":
        return Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.black,
          ),
          child: Icon(Icons.call_received, size: 25, color: Colors.white),
        );
      case "5":
        return Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.blue,
          ),
          child: Icon(Icons.call_received, size: 25, color: Colors.white),
        );
      case "6":
        return Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.teal,
          ),
          child: Icon(Icons.call_received, size: 25, color: Colors.white),
        );
      case "7":
        return Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.greenAccent,
          ),
          child: Icon(Icons.call_received, size: 25, color: Colors.white),
        );
      case "8":
        return Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.purpleAccent,
          ),
          child: Icon(Icons.call_received, size: 25, color: Colors.white),
        );
      case "9":
        return Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.deepPurple,
          ),
          child: Icon(Icons.call_received, size: 25, color: Colors.white),
        );
      default:
        return Icon(Icons.phone, size: 25, color: Colors.black);
    }
  }

  Widget getCagriDurumu(String durum) {
    switch (durum) {
      case "1":
        return Text('Ulaşılamadı', style: TextStyle(color: Colors.black));
      case "2":
        return Text('Giden', style: TextStyle(color: Colors.black));
      case "3":
        return Text("Gelen", style: TextStyle(color: Colors.black));
      case "0":
        return Text("Cevapsız", style: TextStyle(color: Colors.black));
      case "4":
        return Text("Sonuçsuz", style: TextStyle(color: Colors.black));
      case "5":
        return Text("Yol Tarifi", style: TextStyle(color: Colors.blue));
      case "6":
        return Text("Kampanya", style: TextStyle(color: Colors.teal));
      case "7":
        return Text("Randevu Alma", style: TextStyle(color: Colors.greenAccent));
      case "8":
        return Text("Randevu Güncelleme", style: TextStyle(color: Colors.purpleAccent));
      case "9":
        return Text("Randevu İptali", style: TextStyle(color: Colors.deepPurple));
      default:
        return Text("Bilinmeyen", style: TextStyle(color: Colors.black));
    }
  }

  Future<void> seskaydinical(String url) async {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Ses Kaydı"),
          content: Padding(
            padding: const EdgeInsets.all(0.0),
            child: Wrap(
              alignment: WrapAlignment.center,
              spacing: 8,
              runSpacing: 8,
              children: [
                TextButton.icon(
                  style: TextButton.styleFrom(
                    minimumSize: Size(60, 40),
                    padding: EdgeInsets.zero,
                  ),
                  icon: Icon(Icons.play_arrow),
                  label: Text("Çal"),
                  onPressed: () async {
                    await _audioPlayer.setSourceUrl(url);
                    await _audioPlayer.resume();
                  },
                ),
                TextButton.icon(
                  style: TextButton.styleFrom(
                    minimumSize: Size(60, 40),
                    padding: EdgeInsets.zero,
                  ),
                  icon: Icon(Icons.pause),
                  label: Text("Duraklat"),
                  onPressed: () async {
                    await _audioPlayer.pause();
                  },
                ),
                TextButton.icon(
                  style: TextButton.styleFrom(
                    minimumSize: Size(60, 40),
                    padding: EdgeInsets.zero,
                  ),
                  icon: Icon(Icons.stop),
                  label: Text("Durdur"),
                  onPressed: () async {
                    await _audioPlayer.stop();
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              child: Text("Kapat"),
              onPressed: () {
                _audioPlayer.stop();
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> seskaydiniindir(String url, String fileName, BuildContext context) async {
    downloadProgressNotifier.value = 0;
    Directory directory;
    if (Platform.isIOS) {
      directory = await getApplicationDocumentsDirectory();
    } else if (Platform.isAndroid) {
      directory = (await getExternalStorageDirectory())!;
    } else {
      throw UnsupportedError("İndirme desteklenmemektedir");
    }

    String filePath = '${directory.path}/$fileName';

    Dio dio = Dio();
    indirmedialoggoster(context, "Ses kaydı indirme", downloadProgressNotifier);
    try {
      await dio.download(url, filePath,
          onReceiveProgress: (received, total) {
            if (total != -1) {
              print((received / total * 100).toStringAsFixed(0) + "%");
              downloadProgressNotifier.value = (received / total * 100).floor();
            }
          });

      await Share.shareXFiles([XFile(filePath)], text: "Ses kaydınız indirildi");
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Dosya indirilemedi: $e")),
      );
    }
  }
}