import 'dart:async';

import 'package:flutter/material.dart';
import 'package:randevu_sistem/Backend/backend.dart';
import 'package:randevu_sistem/Frontend/sfdatatable.dart';
import 'package:randevu_sistem/Frontend/yukseltbutonu.dart';
import 'package:randevu_sistem/Models/hizmetler.dart';
import 'package:randevu_sistem/theme/app_tokens.dart';
import 'package:randevu_sistem/yeni/hizmet.dart';
import 'hizmet_duzenle.dart';

class Hizmetler extends StatefulWidget {
  final dynamic isletmebilgi;
  const Hizmetler({super.key, required this.isletmebilgi});

  @override
  State<Hizmetler> createState() => _HizmetlerState();
}

class _HizmetlerState extends State<Hizmetler> {
  HizmetlerDataSource? _ds;
  String? _seciliisletme;
  bool _isLoading = true;
  Timer? _debounce;
  String? _lastQuery;
  final TextEditingController _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _init();
    _searchCtrl.addListener(_onSearchChanged);
  }

  Future<void> _init() async {
    _seciliisletme = await secilisalonid();
    if (!mounted) return;
    setState(() {
      _ds = HizmetlerDataSource(
        rowsPerPage: 10,
        salonid: _seciliisletme!,
        context: context,
        baslik: _searchCtrl.text,
        isletmebilgi: widget.isletmebilgi,
      );
      _ds!.isLoadingNotifier.addListener(_onLoadingChanged);
      _isLoading = false;
    });
  }

  void _onLoadingChanged() {
    if (mounted) setState(() {});
  }

  void _onSearchChanged() {
    final text = _searchCtrl.text;
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 400), () {
      if (text == _lastQuery) return;
      _lastQuery = text;
      _ds?.search(text);
    });
    if (mounted) setState(() {}); // suffix clear ikonu için
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _ds?.isLoadingNotifier.removeListener(_onLoadingChanged);
    _searchCtrl.dispose();
    super.dispose();
  }

  void _yeniHizmet() {
    if (_ds == null) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => HizmetSecimi(
          isletmebilgi: widget.isletmebilgi,
          hizmetDataGridSource: _ds!,
        ),
      ),
    );
  }

  void _duzenle(Hizmet h) {
    if (_ds == null) return;
    Navigator.of(context, rootNavigator: true).push(
      MaterialPageRoute(
        builder: (_) => HizmetDuzenle(
          isletmebilgi: widget.isletmebilgi,
          hizmet: h,
          onSaved: () => _ds!.fetchData('1', '', false),
        ),
      ),
    );
  }

  Future<void> _silOnay(Hizmet h) async {
    final cs = context.colors;
    final onay = await showDialog<bool>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Theme.of(ctx).cardColor,
            borderRadius: BorderRadius.circular(22),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: cs.error.withValues(alpha: 0.12),
                  shape: BoxShape.circle,
                ),
                child: Icon(Icons.delete_outline_rounded,
                    color: cs.error, size: 28),
              ),
              const SizedBox(height: 14),
              Text(
                'Hizmeti Sil',
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w800,
                  color: cs.onSurface,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                '"${h.hizmet_adi}" hizmetini silmek istediğinize emin misiniz? Bu işlem geri alınamaz.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 13,
                  color: cs.onSurfaceVariant,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 13),
                        side: BorderSide(
                            color: cs.primary.withValues(alpha: 0.3)),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      child: const Text(
                        'Vazgeç',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: cs.error,
                        foregroundColor: cs.onError,
                        padding: const EdgeInsets.symmetric(vertical: 13),
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      child: const Text(
                        'Evet, Sil',
                        style: TextStyle(fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
    if (onay == true) {
      _ds?.hizmetSil(h.id);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = context.colors;
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 62,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new_rounded,
              color: cs.onSurface, size: 20),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          'Hizmetler',
          style: TextStyle(
            color: cs.onSurface,
            fontWeight: FontWeight.w800,
            fontSize: 18,
            letterSpacing: -0.3,
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
            child: SizedBox(
              width: 100,
              child: YukseltButonu(isletme_bilgi: widget.isletmebilgi),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 10),
            child: _AddIconButton(onTap: _yeniHizmet),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: context.appTheme.borderSubtle),
        ),
      ),
      body: _isLoading || _ds == null
          ? Center(
              child: CircularProgressIndicator(
                  color: cs.primary, strokeWidth: 2.5),
            )
          : GestureDetector(
              onTap: () => FocusScope.of(context).unfocus(),
              child: Column(
                children: [
                  _buildHeader(),
                  Expanded(child: _buildBody()),
                  _buildPagination(),
                ],
              ),
            ),
    );
  }

  Widget _buildHeader() {
    final cs = context.colors;
    final ext = context.appTheme;
    final hizmetSayisi = _ds!.totalRows;
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
      child: Column(
        children: [
          // Stats banner
          Container(
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 14),
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: BorderRadius.circular(18),
              boxShadow: [
                BoxShadow(
                  color: cs.primary.withValues(alpha: 0.10),
                  blurRadius: 14,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(
                    gradient: ext.heroGradient,
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [
                      BoxShadow(
                        color: cs.primary.withValues(alpha: 0.30),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Icon(Icons.spa_rounded,
                      color: cs.onPrimary, size: 22),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Toplam Hizmet',
                        style: TextStyle(
                          fontSize: 11.5,
                          color: cs.onSurfaceVariant,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 0.2,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        '$hizmetSayisi',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                          color: cs.onSurface,
                          height: 1,
                          letterSpacing: -0.4,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          // Arama
          Container(
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: cs.primary.withValues(alpha: 0.10),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: cs.primary.withValues(alpha: 0.05),
                  blurRadius: 10,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: TextField(
              controller: _searchCtrl,
              textInputAction: TextInputAction.search,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: cs.onSurface,
              ),
              decoration: InputDecoration(
                hintText: 'Hizmet adıyla ara',
                hintStyle: TextStyle(
                  color: cs.onSurfaceVariant.withValues(alpha: 0.7),
                  fontSize: 13.5,
                  fontWeight: FontWeight.w500,
                ),
                prefixIcon: Icon(Icons.search_rounded,
                    color: cs.primary, size: 22),
                suffixIcon: _searchCtrl.text.isNotEmpty
                    ? IconButton(
                        icon: Icon(Icons.close_rounded,
                            size: 18, color: cs.onSurfaceVariant),
                        onPressed: () {
                          _searchCtrl.clear();
                          _ds?.search('');
                        },
                      )
                    : null,
                filled: false,
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 14),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBody() {
    final cs = context.colors;
    final hizmetler = _ds!.hizmet;
    if (_ds!.isLoadingNotifier.value && hizmetler.isEmpty) {
      return Center(
        child: CircularProgressIndicator(
            color: cs.primary, strokeWidth: 2.5),
      );
    }
    if (hizmetler.isEmpty) {
      return _buildEmpty();
    }
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(14, 6, 14, 12),
      itemCount: hizmetler.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (context, i) => _buildCard(hizmetler[i]),
    );
  }

  Widget _buildEmpty() {
    final cs = context.colors;
    final aramada = _searchCtrl.text.isNotEmpty;
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                color: cs.primary.withValues(alpha: 0.08),
                shape: BoxShape.circle,
              ),
              child: Icon(
                aramada ? Icons.search_off_rounded : Icons.spa_rounded,
                size: 44,
                color: cs.primary,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              aramada ? 'Eşleşme bulunamadı' : 'Henüz hizmet eklenmemiş',
              style: TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 16,
                color: cs.onSurface,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              aramada
                  ? 'Aramanı temizleyip tekrar deneyebilirsin.'
                  : 'Üstteki "Yeni" butonu ile hizmet ekleyebilirsin.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: cs.onSurfaceVariant,
                fontSize: 13,
                fontWeight: FontWeight.w500,
                height: 1.4,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCard(Hizmet h) {
    final cs = context.colors;
    final ext = context.appTheme;
    return Material(
      color: Theme.of(context).cardColor,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => _ds!.showDetailsDialog(context, h),
        child: Container(
          padding: const EdgeInsets.fromLTRB(14, 12, 8, 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: cs.primary.withValues(alpha: 0.10),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: cs.primary.withValues(alpha: 0.05),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          cs.primary.withValues(alpha: 0.18),
                          cs.primary.withValues(alpha: 0.08),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(13),
                    ),
                    child: Icon(Icons.spa_rounded,
                        color: cs.primary, size: 22),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          h.hizmet_adi.isEmpty ? '-' : h.hizmet_adi,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 14.5,
                            color: cs.onSurface,
                            letterSpacing: -0.2,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Wrap(
                          spacing: 6,
                          runSpacing: 4,
                          children: [
                            _buildChip(
                              icon: Icons.payments_rounded,
                              text: _fiyatText(h.fiyat),
                              color: ext.successColor,
                            ),
                            _buildChip(
                              icon: Icons.timer_outlined,
                              text: '${_safeNum(h.sure_dk)} dk',
                              color: ext.warningColor,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  _buildMenu(h),
                ],
              ),
              if (_hasInfo(h.personel) || _hasInfo(h.cihaz)) ...[
                const SizedBox(height: 10),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                  decoration: BoxDecoration(
                    color: ext.surfaceMuted,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (_hasInfo(h.personel))
                        _infoLine(
                          icon: Icons.person_outline_rounded,
                          label: 'Personel',
                          value: h.personel,
                        ),
                      if (_hasInfo(h.personel) && _hasInfo(h.cihaz))
                        const SizedBox(height: 6),
                      if (_hasInfo(h.cihaz))
                        _infoLine(
                          icon: Icons.devices_other_rounded,
                          label: 'Cihaz',
                          value: h.cihaz,
                        ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildChip({
    required IconData icon,
    required String text,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: color),
          const SizedBox(width: 4),
          Text(
            text,
            style: TextStyle(
              fontSize: 11.5,
              fontWeight: FontWeight.w800,
              color: color,
              letterSpacing: -0.1,
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoLine({
    required IconData icon,
    required String label,
    required String value,
  }) {
    final cs = context.colors;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 14, color: cs.onSurfaceVariant),
        const SizedBox(width: 6),
        Text(
          '$label: ',
          style: TextStyle(
            fontSize: 11.5,
            fontWeight: FontWeight.w700,
            color: cs.onSurfaceVariant,
          ),
        ),
        Expanded(
          child: Text(
            value,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 11.5,
              fontWeight: FontWeight.w500,
              color: cs.onSurfaceVariant,
              height: 1.35,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildMenu(Hizmet h) {
    final cs = context.colors;
    return PopupMenuButton<String>(
      icon: Icon(Icons.more_vert_rounded,
          color: cs.onSurfaceVariant, size: 20),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
      ),
      elevation: 6,
      onSelected: (value) {
        if (value == 'duzenle') {
          _duzenle(h);
        } else if (value == 'sil') {
          _silOnay(h);
        } else if (value == 'detay') {
          _ds?.showDetailsDialog(context, h);
        }
      },
      itemBuilder: (context) => [
        _menuItem('detay', Icons.info_outline_rounded, 'Detayı Gör'),
        _menuItem('duzenle', Icons.edit_outlined, 'Düzenle'),
        _menuItem('sil', Icons.delete_outline_rounded, 'Sil', danger: true),
      ],
    );
  }

  PopupMenuItem<String> _menuItem(
    String value,
    IconData icon,
    String label, {
    bool danger = false,
  }) {
    final cs = context.colors;
    final color = danger ? cs.error : cs.onSurface;
    return PopupMenuItem<String>(
      value: value,
      height: 40,
      child: Row(
        children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(width: 10),
          Text(
            label,
            style: TextStyle(
              color: color,
              fontWeight: FontWeight.w600,
              fontSize: 13.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPagination() {
    final cs = context.colors;
    final total = _ds!.totalPages;
    final current = _ds!.currentPage;
    if (total <= 1) return const SizedBox.shrink();

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 14),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _pageBtn(Icons.chevron_left_rounded, current > 1, () {
            setState(() => _ds!.setPage(current - 1));
          }),
          const SizedBox(width: 14),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
            decoration: BoxDecoration(
              color: cs.primary.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              'Sayfa $current / $total',
              style: TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 12.5,
                color: cs.primary,
                letterSpacing: -0.1,
              ),
            ),
          ),
          const SizedBox(width: 14),
          _pageBtn(Icons.chevron_right_rounded, current < total, () {
            setState(() => _ds!.setPage(current + 1));
          }),
        ],
      ),
    );
  }

  Widget _pageBtn(IconData icon, bool enabled, VoidCallback onTap) {
    final cs = context.colors;
    return Material(
      color: enabled ? cs.primary : cs.surfaceContainerHighest,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: enabled ? onTap : null,
        child: Container(
          padding: const EdgeInsets.all(8),
          child: Icon(
            icon,
            size: 22,
            color: enabled
                ? cs.onPrimary
                : cs.onSurfaceVariant.withValues(alpha: 0.5),
          ),
        ),
      ),
    );
  }

  bool _hasInfo(String? v) =>
      v != null && v.isNotEmpty && v != 'null' && v.trim() != ',';

  String _safeNum(String? s) {
    if (s == null || s.isEmpty || s == 'null') return '0';
    return s;
  }

  String _fiyatText(String? f) {
    final raw = _safeNum(f);
    return '$raw ₺';
  }
}

class _AddIconButton extends StatelessWidget {
  final VoidCallback onTap;
  const _AddIconButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    final cs = context.colors;
    final ext = context.appTheme;
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            gradient: ext.heroGradient,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: cs.primary.withValues(alpha: 0.30),
                blurRadius: 8,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Icon(Icons.add_rounded, color: cs.onPrimary, size: 22),
        ),
      ),
    );
  }
}
