import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:http/http.dart' as http;
import 'package:package_info_plus/package_info_plus.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import 'Backend/backend.dart';
import 'Frontend/indexedstack.dart';
import 'Frontend/randevuguncellemeprovider.dart';
import 'Login Sayfası/checklogin.dart';
import 'Login Sayfası/tanitim.dart';
import 'navigatorkey.dart';

late SharedPreferences prefs;

// Firebase background handler
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  print("🔹 Firebase background mesaj alındı");
}



// FCM token alma
Future<void> _initFCMToken() async {
  try {
    final token = await FirebaseMessaging.instance.getToken();
    if (token != null && token.isNotEmpty) {
      print("✅ FCM token alındı: $token");
      prefs.setString('fcm_token', token);
    }
  } catch (e) {
    print("❌ FCM token alınamadı: $e");
  }
}

// OneSignal Player ID alma
Future<void> ensurePlayerId() async {
  for (int i = 0; i < 10; i++) {
    final playerId = OneSignal.User.pushSubscription.id;
    if (playerId != null && playerId.isNotEmpty) {
      prefs.setString('onesignal_player_id', playerId);
      print("✅ OneSignal Player ID: $playerId");
      return;
    }
    await Future.delayed(Duration(seconds: 1));
  }
  print("❌ OneSignal Player ID alınamadı");
}

// Main
void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // 1) SharedPreferences MUST come first
  prefs = await SharedPreferences.getInstance();

  // 2) Firebase init
  await Firebase.initializeApp();
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  // 3) OneSignal init
  OneSignal.Debug.setLogLevel(OSLogLevel.verbose);
  OneSignal.initialize("ad4a065c-2984-4e51-a7b2-7903da340de3");

  // 4) iOS push permission
  await OneSignal.Notifications.requestPermission(true);


  // 5) Player ID alma
  await ensurePlayerId();

  // 6) Android 13+ izin
  if (Platform.isAndroid) {
    await Permission.notification.request();
  }

  // 7) Uygulamayı başlat
  runApp(MyApp());
}


class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppointmentProvider()),
        ChangeNotifierProvider(create: (_) => IndexedStackState()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          fontFamily: 'Roboto',
          textTheme: TextTheme(
            bodyLarge: TextStyle(fontSize: 16, fontWeight: FontWeight.normal),
            bodyMedium: TextStyle(fontSize: 14, fontWeight: FontWeight.normal),
            bodySmall: TextStyle(fontSize: 12, fontWeight: FontWeight.normal),
            titleLarge: TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
          ),
        ),
        navigatorKey: navigatorKey,
        localizationsDelegates: [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        supportedLocales: [const Locale('tr')],
        locale: const Locale('tr'),
        home: MyHomePage(),
      ),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  double _opacity = 0.0;
  bool _forceUpdateShown = false;
  @override
  void initState() {
    super.initState();

    // Fade-in animasyon
    Future.delayed(Duration(milliseconds: 100), () {
      setState(() {
        _opacity = 1.0;
      });
    });

    // Splash sonrası yönlendirme
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await checkVersion(context);

      // Normal splash timer
      if (!_forceUpdateShown)
      Future.delayed(Duration(seconds: 3), () {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => CheckAuth()),
        );
      });
    });
  }
  Future<void> checkVersion(BuildContext context) async {

    try {
      // 1. Local versiyonu al
      PackageInfo packageInfo = await PackageInfo.fromPlatform();
      String appBundle =  await appBundleAl();
      String localVersion = packageInfo.version;
      log('version kontrolü yapılıyor');
      Map<String, dynamic> formData = {
        'appBundle': appBundle,
      };

      // 2. Sunucudan JSON çek
      final response = await http.post(
        Uri.parse("https://apptest.randevumcepte.com.tr/api/v1/versiyonAppKontrol"),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(formData),

      );

      if (response.statusCode != 200) return;

      final data = jsonDecode(response.body);
      log('version bilgi '+response.body);
      bool isAndroid = Theme.of(context).platform == TargetPlatform.android;

      // Yalnızca latest kullanılacak
      String latest = isAndroid ? data["android_latest"] : data["ios_latest"];

      String forceMessage = "Uygulamamızın güncellenmiş sürümü mevcut. Devam edebilmeniz için lütfen güncelleyiniz.";

      // 3. Sadece localVersion < latest ise güncellemeye zorla
      if (_isLower(localVersion, latest)) {

        _forceUpdateShown = true;


        _showForceUpdate(context, forceMessage,data['play_store'],data['app_store'],data['app_gallery']);
      }

    } catch (e) {
      print("Version check error: $e");
    }
  }


  // Versiyon karşılaştırıcı
  bool _isLower(String v1, String v2) {
    List<String> a = v1.split(".");
    List<String> b = v2.split(".");

    for (int i = 0; i < 3; i++) {
      int x = int.parse(a[i]);
      int y = int.parse(b[i]);
      if (x < y) return true;
      if (x > y) return false;
    }
    return false;
  }

  // ZORUNLU (KAPAT YOK)
  _showForceUpdate(BuildContext context, String message,String androidURL, String iosURL, String huaweiURL) {
    showDialog(
      barrierDismissible: false, // dışa tıklamayla kapanmayı engelle
      context: context,
      builder: (context) => WillPopScope(
        onWillPop: () async => false, // geri tuşunu engelle
        child: AlertDialog(
          title: Text("Güncelleme Gerekli"),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () {
                _openStore(androidURL, iosURL, huaweiURL);
              },
              child: Text("GÜNCELLE"),
            ),
          ],
        ),
      ),
    );
  }
  // İSTEĞE BAĞLI
  /*void _showOptionalUpdate(BuildContext context, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Yeni Sürüm Mevcut"),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("DAHA SONRA"),
          ),
          TextButton(
            onPressed: () {
              _openStore();
            },
            child: Text("GÜNCELLE"),
          ),
        ],
      ),
    );
  }*/

  Future<void> _openStore(String androidURL,String iosURL, String huaweiURL) async {
    if (Platform.isAndroid) {
      String packageName = await appBundleAl();

      final Uri marketUri = Uri.parse("market://details?id=$packageName");
      final Uri webUri = Uri.parse(androidURL);

      // Önce market:// açmayı dene
      /*if (await canLaunchUrl(marketUri)) {
        await launchUrl(marketUri, mode: LaunchMode.externalApplication);
      } else {*/
      // market:// çalışmazsa web fallback
      await launchUrl(webUri, mode: LaunchMode.externalApplication);
      // }
    }

    else if (Platform.isIOS) {
      final Uri iosUri = Uri.parse(iosURL);
      await launchUrl(iosUri, mode: LaunchMode.externalApplication);
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: AnimatedOpacity(
          duration: Duration(seconds: 3),
          opacity: _opacity,
          child: Image.asset(
            "images/maxlora.png",
            height: 200,
          ),
        ),
      ),
    );
  }
}
