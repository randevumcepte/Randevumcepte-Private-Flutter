import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:randevu_sistem/Backend/backend.dart';
import '../../Models/musteri_danisanlar.dart';
import '../../Models/olcumler.dart';
import '../../Models/olcumturu.dart';
import 'package:shared_preferences/shared_preferences.dart';

class OlculerimPage extends StatefulWidget {
  final MusteriDanisan md;
  final Function(double)? onKiloGuncellendi; // Yeni callback

  const OlculerimPage({Key? key, required this.md, this.onKiloGuncellendi}) : super(key: key);

  @override
  State<OlculerimPage> createState() => _OlculerimPageState();
}

class _OlculerimPageState extends State<OlculerimPage> {
  List<Olcumler> olcumler = [];
  bool _isInitialized = false;

  @override
  void initState() {
    super.initState();
    initialize();
  }

  Future<void> initialize() async {
    try {
      final List<dynamic> jsonResponse = await olcumleriGetir(widget.md.id);
      if (mounted) {
        setState(() {
          olcumler = jsonResponse.map<Olcumler>((json) => Olcumler.fromJson(json)).toList();
          _isInitialized = true;
        });
      }
    } catch (e) {
      print('Ölçümler yüklenirken hata: $e');
      if (mounted) {
        setState(() {
          _isInitialized = true;
        });
      }
    }
  }

  // Kilo ölçümünü bul
  Olcumler? _getKiloOlcumu() {
    try {
      return olcumler.firstWhere(
            (element) => element.olcum_turu['id'].toString() == '5',
      );
    } catch (e) {
      return null;
    }
  }

  // Profildeki kiloyu güncelle
  Future<void> _updateProfileKilo(double yeniKilo) async {
    try {
      // SharedPreferences'daki mevcut kullanıcı verisini al
      SharedPreferences localStorage = await SharedPreferences.getInstance();
      var userString = localStorage.getString('musteri');

      if (userString != null) {
        var user = jsonDecode(userString);

        // Kilo verisini güncelle
        var updatedUser = {
          ...user,
          'kilo': yeniKilo.toString(),
        };

        // Local storage'ı güncelle
        await localStorage.setString('musteri', jsonEncode(updatedUser));

        print('Profil kiloku güncellendi: $yeniKilo kg');

        // Callback'i çağır (MusteriAnsayfa'ya bildir)
        if (widget.onKiloGuncellendi != null) {
          widget.onKiloGuncellendi!(yeniKilo);
        }
      }
    } catch (e) {
      print('Profil kilosu güncellenirken hata: $e');
    }
  }

  void _olcumEkle() async {
    final result = await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => OlcumEkleBottomSheet(
        md: widget.md,
        olcumler: olcumler,
        onOlcumEklendi: () async {
          await initialize();

          // Yeni ölçüm eklendiğinde, eğer kilo ölçümüyse profili güncelle
          final kiloOlcumu = _getKiloOlcumu();
          if (kiloOlcumu != null && kiloOlcumu.olcum_gecmisi.isNotEmpty) {
            final sonKiloDegeri = kiloOlcumu.olcum_gecmisi.last['deger'].toString();
            final temizlenmisKilo = sonKiloDegeri.replaceAll(' kg', '').trim();
            final doubleKilo = double.tryParse(temizlenmisKilo);
            if (doubleKilo != null) {
              await _updateProfileKilo(doubleKilo);
            }
          }
        },
      ),
    );

    if (result == 200) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Ölçüm başarıyla eklendi'),
          backgroundColor: Colors.green[700],
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      );
      await initialize();
    }
    if (result != null && result != 200) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Ölçüm eklenirken bir hata oluştu. Hata kodu:' + result.toString()),
          backgroundColor: Colors.red[700],
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      );
    }
  }

  void _olcumSil(String olcumId) async {
    final olcum = olcumler.firstWhere((o) => o.id == olcumId);
    final isKiloOlcumu = olcum.olcum_turu['id'].toString() == '5';
    double? eskiKilo;

    // Eğer kilo ölçümü siliniyorsa, silmeden önceki değeri kaydet
    if (isKiloOlcumu && olcum.olcum_gecmisi.isNotEmpty) {
      final sonKiloDegeri = olcum.olcum_gecmisi.last['deger'].toString();
      final temizlenmisKilo = sonKiloDegeri.replaceAll(' kg', '').trim();
      eskiKilo = double.tryParse(temizlenmisKilo);
    }

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Ölçüm Sil',
          style: TextStyle(color: Colors.red[700]),
        ),
        content: Text('Bu ölçümü silmek istediğinizden emin misiniz? Bu işlemi gerçekleştirdiğiniz takdirde tüm ölçüm geçmişiniz silinecektir ve geri alınamayacaktır.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(
              'İptal',
              style: TextStyle(color: Colors.grey[700]),
            ),
          ),
          TextButton(
            onPressed: () async {
              final result = await olcumSil(olcumId);
              if (result == 200) {
                setState(() {
                  olcumler.removeWhere((olcum) => olcum.id == olcumId);
                });
                Navigator.of(context).pop();

                // Eğer kilo ölçümü silindiyse ve önceki kilo varsa, profili güncelle
                if (isKiloOlcumu && eskiKilo != null) {
                  await _updateProfileKilo(eskiKilo);
                }

                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Ölçüm başarıyla silindi'),
                    backgroundColor: Colors.green[700],
                  ),
                );
              } else {
                Navigator.of(context).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Ölçüm silinirken bir hata oluştu'),
                    backgroundColor: Colors.red[700],
                  ),
                );
              }
            },
            child: Text(
              'Sil',
              style: TextStyle(color: Colors.red[700]),
            ),
          ),
        ],
      ),
    );
  }

  void _showOlcumGecmisi(String olcumId) {
    final olcum = olcumler.firstWhere((o) => o.id == olcumId);
    final isKiloOlcumu = olcum.olcum_turu['id'].toString() == '5';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => OlcumGecmisiBottomSheet(
        olcum: olcum,
        md: widget.md,
        onDegerEklendi: () async {
          await initialize();

          // Eğer kilo ölçümü güncellendiyse profili güncelle
          if (isKiloOlcumu) {
            final guncellenmisKiloOlcumu = _getKiloOlcumu();
            if (guncellenmisKiloOlcumu != null && guncellenmisKiloOlcumu.olcum_gecmisi.isNotEmpty) {
              final sonKiloDegeri = guncellenmisKiloOlcumu.olcum_gecmisi.last['deger'].toString();
              final temizlenmisKilo = sonKiloDegeri.replaceAll(' kg', '').trim();
              final doubleKilo = double.tryParse(temizlenmisKilo);
              if (doubleKilo != null) {
                await _updateProfileKilo(doubleKilo);
              }
            }
          }
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(
          'Ölçümlerim',
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.w600,
            fontSize: 20,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 1,
        iconTheme: IconThemeData(color: Colors.black),
        actions: [
          IconButton(
            onPressed: _olcumEkle,
            icon: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.red[700]!, width: 2),
              ),
              child: Icon(
                Icons.add,
                color: Colors.red[700],
                size: 24,
              ),
            ),
          ),
          SizedBox(width: 8),
        ],
      ),
      body: !_isInitialized
          ? Center(
        child: CircularProgressIndicator(
          color: Colors.red[700],
        ),
      )
          : olcumler.isEmpty
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.monitor_heart_outlined,
              size: 80,
              color: Colors.grey[300],
            ),
            SizedBox(height: 16),
            Text(
              'Henüz ölçüm eklenmemiş',
              style: TextStyle(
                color: Colors.grey[500],
                fontSize: 16,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'Yeni ölçüm eklemek için + butonuna tıklayın',
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 14,
              ),
            ),
          ],
        ),
      )
          : RefreshIndicator(
        onRefresh: initialize,
        child: ListView.builder(
          padding: EdgeInsets.all(16),
          itemCount: olcumler.length,
          itemBuilder: (context, index) {
            final olcum = olcumler[index];
            final isKiloOlcumu = olcum.olcum_turu['id'].toString() == '5';

            return _buildOlcumKarti(olcum, isKiloOlcumu);
          },
        ),
      ),
    );
  }

  Widget _buildOlcumKarti(Olcumler olcum, bool isKiloOlcumu) {
    final timeFormat = DateFormat('HH:mm');
    final dateFormat = DateFormat('dd.MM.yyyy');
    String olcumSikligi = '';

    if (olcum.olcum_sikligi == 'her_gun')
      olcumSikligi = 'Her gün';
    if (olcum.olcum_sikligi == 'her_x_gun')
      olcumSikligi = olcum.her_x_gun + ' günde bir';
    if (olcum.olcum_sikligi == 'haftanin_gunleri')
      olcumSikligi = olcum.haftanin_gunu;

    final sonOlcumDegeri = olcum.olcum_gecmisi.isNotEmpty
        ? olcum.olcum_gecmisi.last['deger']
        : 'Henüz ölçüm yapılmadı';

    return Container(
      margin: EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 12,
            offset: Offset(0, 4),
          ),
        ],
        border: Border.all(
          color: Colors.grey.withOpacity(0.2),
          width: 1,
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: Stack(
          children: [
            InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () => _showOlcumGecmisi(olcum.id),
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Row(
                  children: [
                    Container(
                      width: 50,
                      height: 50,
                      decoration: BoxDecoration(
                        color: Color(int.parse(olcum.olcum_turu['renk'])),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.white, width: 2),
                      ),
                      child: Icon(
                        _getOlcumIcon(olcum.olcum_turu['id'].toString()),
                        color: Colors.white,
                        size: 24,
                      ),
                    ),
                    SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(
                                olcum.olcum_turu['olcum_turu'],
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.grey[800],
                                ),
                              ),
                              SizedBox(width: 8),
                              if (isKiloOlcumu)
                                Container(
                                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: Colors.blue[50],
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(color: Colors.blue[200]!),
                                  ),
                                  child: Text(
                                    'Profil Bilgisi',
                                    style: TextStyle(
                                      color: Colors.blue[700],
                                      fontSize: 10,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                          SizedBox(height: 4),
                          InkWell(
                            onTap: () {
                              _showOlcumGecmisi(olcum.id);
                            },
                            child: Row(
                              children: [
                                Icon(
                                  Icons.analytics_outlined,
                                  size: 16,
                                  color: Colors.grey[500],
                                ),
                                SizedBox(width: 4),
                                Text(
                                  sonOlcumDegeri,
                                  style: TextStyle(
                                    color: Color(int.parse(olcum.olcum_turu['renk'])),
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                if (olcum.olcum_gecmisi.isNotEmpty)
                                  Icon(
                                    Icons.history,
                                    size: 14,
                                    color: Colors.grey[500],
                                  ),
                              ],
                            ),
                          ),
                          SizedBox(height: 4),
                          Row(
                            children: [
                              Icon(
                                Icons.schedule,
                                size: 16,
                                color: Colors.grey[500],
                              ),
                              SizedBox(width: 4),
                              Text(
                                olcumSikligi,
                                style: TextStyle(
                                  color: Colors.grey[600],
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 4),
                          Wrap(
                            spacing: 5,
                            children: (olcum.olcum_saatleri.split(',')).map((saat) {
                              return Container(
                                padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: Color(int.parse(olcum.olcum_turu['renk'])).withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: Color(int.parse(olcum.olcum_turu['renk'])).withOpacity(0.3)),
                                ),
                                child: Text(
                                  saat,
                                  style: TextStyle(
                                    color: Color(int.parse(olcum.olcum_turu['renk'])),
                                    fontSize: 12,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              );
                            }).toList(),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              top: 8,
              right: 8,
              child: GestureDetector(
                onTap: () => _olcumSil(olcum.id),
                child: Container(
                  width: 23,
                  height: 23,
                  decoration: BoxDecoration(
                    color: Colors.red[700],
                    borderRadius: BorderRadius.circular(15),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.2),
                        blurRadius: 4,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Icon(
                    Icons.close,
                    color: Colors.white,
                    size: 18,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  IconData _getOlcumIcon(String tur) {
    switch (tur) {
      case '1': return Icons.favorite_border;
      case '6': return Icons.favorite;
      case '5': return Icons.monitor_weight_outlined;
      case '2':
      case '3': return Icons.bloodtype_outlined;
      case '4': return Icons.thermostat_outlined;
      default: return Icons.analytics_outlined;
    }
  }
}

class OlcumEkleBottomSheet extends StatefulWidget {
  final Function() onOlcumEklendi;
  final List<Olcumler> olcumler;
  final MusteriDanisan md;

  const OlcumEkleBottomSheet({
    Key? key,
    required this.onOlcumEklendi,
    required this.olcumler,
    required this.md
  }) : super(key: key);

  @override
  State<OlcumEkleBottomSheet> createState() => _OlcumEkleBottomSheetState();
}

class _OlcumEkleBottomSheetState extends State<OlcumEkleBottomSheet> {
  final _formKey = GlobalKey<FormState>();
  OlcumTuru? seciliOlcumTuru;
  final _degerController = TextEditingController();
  final _siklikController = TextEditingController();
  List<String> _seciliSaatler = [];

  String _selectedSiklikType = 'her_gun';
  int _selectedGunAraligi = 2;
  List<String> _selectedGunler = [];

  final List<String> _haftaninGunleri = [
    'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar'
  ];

  final List<OlcumTuru> _olcumTurleri = [
    OlcumTuru(id: "1", olcum_turu: "Tansiyon"),
    OlcumTuru(id: "2", olcum_turu: "Açlık Kan Şekeri"),
    OlcumTuru(id: "3", olcum_turu: "Tokluk Kan Şekeri"),
    OlcumTuru(id: "4", olcum_turu: "Ateş"),
    OlcumTuru(id: "5", olcum_turu: "Kilo"),
    OlcumTuru(id: "6", olcum_turu: "Kalp"),
  ];

  @override
  void initState() {
    super.initState();
    _updateSiklikText();
  }

  void _saatEkle() async {
    final result = await showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _buildModernTimePicker(),
    );

    if (result != null && result is String) {
      if (!_seciliSaatler.contains(result)) {
        setState(() {
          _seciliSaatler.add(result);
          _seciliSaatler.sort();
        });
      }
    }
  }

  Widget _buildModernTimePicker() {
    int selectedHour = TimeOfDay.now().hour;
    int selectedMinute = TimeOfDay.now().minute;

    return StatefulBuilder(
      builder: (context, setState) {
        return Container(
          height: MediaQuery.of(context).size.height * 0.6,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(24),
              topRight: Radius.circular(24),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black26,
                blurRadius: 20,
                offset: Offset(0, -2),
              ),
            ],
          ),
          child: Column(
            children: [
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  border: Border(
                    bottom: BorderSide(color: Colors.grey[200]!),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextButton(
                      onPressed: () => Navigator.of(context).pop(),
                      child: Text(
                        'İptal',
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    Text(
                      'Saat Seç',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: Colors.black87,
                      ),
                    ),
                    TextButton(
                      onPressed: () {
                        final saat = '${selectedHour.toString().padLeft(2, '0')}:${selectedMinute.toString().padLeft(2, '0')}';
                        Navigator.of(context).pop(saat);
                      },
                      child: Text(
                        'Tamam',
                        style: TextStyle(
                          color: Colors.red[700],
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              Container(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Text(
                  '${selectedHour.toString().padLeft(2, '0')}:${selectedMinute.toString().padLeft(2, '0')}',
                  style: TextStyle(
                    fontSize: 48,
                    fontWeight: FontWeight.w300,
                    color: Colors.red[700],
                    letterSpacing: 2,
                  ),
                ),
              ),

              Expanded(
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        children: [
                          Padding(
                            padding: EdgeInsets.only(bottom: 8),
                            child: Text(
                              'SAAT',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: Colors.grey[500],
                                letterSpacing: 1,
                              ),
                            ),
                          ),
                          Expanded(
                            child: ListWheelScrollView(
                              itemExtent: 50,
                              perspective: 0.005,
                              diameterRatio: 1.5,
                              physics: FixedExtentScrollPhysics(),
                              onSelectedItemChanged: (index) {
                                setState(() {
                                  selectedHour = index;
                                });
                              },
                              children: List.generate(24, (hour) {
                                final isSelected = hour == selectedHour;
                                return Container(
                                  alignment: Alignment.center,
                                  child: Text(
                                    hour.toString().padLeft(2, '0'),
                                    style: TextStyle(
                                      fontSize: isSelected ? 22 : 18,
                                      fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                                      color: isSelected ? Colors.red[700] : Colors.grey[600],
                                    ),
                                  ),
                                );
                              }),
                            ),
                          ),
                        ],
                      ),
                    ),

                    Container(
                      width: 20,
                      alignment: Alignment.center,
                      child: Text(
                        ':',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.w300,
                          color: Colors.grey[400],
                        ),
                      ),
                    ),

                    Expanded(
                      child: Column(
                        children: [
                          Padding(
                            padding: EdgeInsets.only(bottom: 8),
                            child: Text(
                              'DAKİKA',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: Colors.grey[500],
                                letterSpacing: 1,
                              ),
                            ),
                          ),
                          Expanded(
                            child: ListWheelScrollView(
                              itemExtent: 50,
                              perspective: 0.005,
                              diameterRatio: 1.5,
                              physics: FixedExtentScrollPhysics(),
                              onSelectedItemChanged: (index) {
                                setState(() {
                                  selectedMinute = index;
                                });
                              },
                              children: List.generate(60, (minute) {
                                final isSelected = minute == selectedMinute;
                                return Container(
                                  alignment: Alignment.center,
                                  child: Text(
                                    minute.toString().padLeft(2, '0'),
                                    style: TextStyle(
                                      fontSize: isSelected ? 22 : 18,
                                      fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                                      color: isSelected ? Colors.red[700] : Colors.grey[600],
                                    ),
                                  ),
                                );
                              }),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              Container(
                margin: EdgeInsets.all(16),
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.red[50],
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.red[100]!),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.access_time,
                      size: 20,
                      color: Colors.red[700],
                    ),
                    SizedBox(width: 8),
                    Text(
                      'Seçilen Saat: ${selectedHour.toString().padLeft(2, '0')}:${selectedMinute.toString().padLeft(2, '0')}',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: Colors.red[700],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _saatSil(String saat) {
    setState(() {
      _seciliSaatler.remove(saat);
    });
  }

  void _updateSiklikText() {
    String siklikText = '';

    switch (_selectedSiklikType) {
      case 'her_gun':
        siklikText = 'Her gün';
        break;
      case 'her_x_gun':
        siklikText = 'Her $_selectedGunAraligi günde bir';
        break;
      case 'haftanin_gunleri':
        if (_selectedGunler.isNotEmpty) {
          siklikText = 'Haftanın günleri: ${_selectedGunler.join(', ')}';
        } else {
          siklikText = 'Haftanın belirli günleri';
        }
        break;
    }

    _siklikController.text = siklikText;
  }

  void _olcumKaydet(MusteriDanisan md, List<Olcumler> olcumler, String olcumId) async {
    if (_formKey.currentState!.validate() && _seciliSaatler.isNotEmpty) {
      if (_selectedSiklikType == 'haftanin_gunleri' && _selectedGunler.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Lütfen haftanın en az bir gününü seçiniz'),
            backgroundColor: Colors.red[700],
          ),
        );
        return;
      }

      _updateSiklikText();

      int result = await olcumEkleGuncelle(
        olcumId,
        seciliOlcumTuru?.id ?? '',
        _selectedSiklikType,
        md.id.toString(),
        _selectedGunler,
        _selectedGunAraligi.toString(),
        _seciliSaatler,
      );

      if (result == 200) {
        widget.onOlcumEklendi();
      }

      Navigator.of(context).pop(result);
    }
  }

  Widget _buildSiklikSecim() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Sıklık',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: Colors.grey[800],
          ),
        ),
        SizedBox(height: 12),

        Container(
          width: double.infinity,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildSiklikTipChip('Her Gün', 'her_gun', Icons.calendar_today),
              _buildSiklikTipChip('X Gün', 'her_x_gun', Icons.repeat),
              _buildSiklikTipChip('Haftalık', 'haftanin_gunleri', Icons.view_week),
            ],
          ),
        ),
        SizedBox(height: 16),

        if (_selectedSiklikType == 'her_x_gun') _buildGunAraligiSecim(),
        if (_selectedSiklikType == 'haftanin_gunleri') _buildHaftaninGunleriSecim(),
      ],
    );
  }

  Widget _buildSiklikTipChip(String text, String value, IconData icon) {
    final isSelected = _selectedSiklikType == value;

    return Expanded(
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 4),
        child: Material(
          color: isSelected ? Colors.red[50] : Colors.grey[50],
          borderRadius: BorderRadius.circular(12),
          child: InkWell(
            onTap: () {
              setState(() {
                _selectedSiklikType = value;
                _updateSiklikText();
              });
            },
            borderRadius: BorderRadius.circular(12),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isSelected ? Colors.red[700]! : Colors.grey[300]!,
                  width: isSelected ? 2 : 1,
                ),
                color: isSelected ? Colors.red[50] : Colors.grey[50],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    icon,
                    size: 20,
                    color: isSelected ? Colors.red[700] : Colors.grey[600],
                  ),
                  SizedBox(height: 6),
                  Text(
                    text,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      color: isSelected ? Colors.red[700] : Colors.grey[700],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildGunAraligiSecim() {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Gün Aralığı Seçin',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: Colors.grey[800],
            ),
          ),
          SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Tekrarlama sıklığı',
                      style: TextStyle(
                        fontSize: 13,
                        color: Colors.grey[600],
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'Her $_selectedGunAraligi günde bir',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: Colors.red[700],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.grey[300]!),
                ),
                child: Row(
                  children: [
                    _buildGunButton(
                      icon: Icons.remove,
                      onPressed: _selectedGunAraligi > 1 ? () {
                        setState(() {
                          _selectedGunAraligi--;
                          _updateSiklikText();
                        });
                      } : null,
                    ),
                    Container(
                      width: 40,
                      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 10),
                      child: Text(
                        '$_selectedGunAraligi',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: Colors.red[700],
                        ),
                      ),
                    ),
                    _buildGunButton(
                      icon: Icons.add,
                      onPressed: _selectedGunAraligi < 30 ? () {
                        setState(() {
                          _selectedGunAraligi++;
                          _updateSiklikText();
                        });
                      } : null,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildGunButton({required IconData icon, required VoidCallback? onPressed}) {
    return Container(
      width: 36,
      height: 36,
      margin: EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: onPressed != null ? Colors.red[700] : Colors.grey[400],
        borderRadius: BorderRadius.circular(8),
      ),
      child: IconButton(
        onPressed: onPressed,
        icon: Icon(icon, size: 16, color: Colors.white),
        padding: EdgeInsets.zero,
        constraints: BoxConstraints(),
      ),
    );
  }

  Widget _buildHaftaninGunleriSecim() {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Haftanın Günlerini Seçin',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: Colors.grey[800],
            ),
          ),
          SizedBox(height: 12),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: _haftaninGunleri.map((gun) {
              final isSelected = _selectedGunler.contains(gun);
              final gunKisaltma = _getGunKisaltma(gun);

              return Expanded(
                child: Container(
                  margin: EdgeInsets.symmetric(horizontal: 2),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: () {
                        setState(() {
                          if (isSelected) {
                            _selectedGunler.remove(gun);
                          } else {
                            _selectedGunler.add(gun);
                          }
                          _updateSiklikText();
                        });
                      },
                      borderRadius: BorderRadius.circular(8),
                      child: Container(
                        height: 60,
                        decoration: BoxDecoration(
                          color: isSelected ? Colors.red[50] : Colors.white,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: isSelected ? Colors.red[300]! : Colors.grey[300]!,
                            width: isSelected ? 1 : 1,
                          ),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            if (isSelected)
                              Icon(
                                Icons.check,
                                size: 16,
                                color: Colors.red[300],
                              )
                            else
                              SizedBox(height: 16),

                            SizedBox(height: 4),

                            Text(
                              gunKisaltma,
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                color: isSelected ? Colors.red[300] : Colors.grey[700],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
          ),

          SizedBox(height: 8),
          if (_selectedGunler.isNotEmpty)
            Container(
              padding: EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.green[50],
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.green[200]!),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.check_circle,
                    size: 16,
                    color: Colors.green[700],
                  ),
                  SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      'Seçilen: ${_selectedGunler.map((g) => _getGunKisaltma(g)).join(', ')}',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.green[700],
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  String _getGunKisaltma(String gun) {
    switch (gun) {
      case 'Pazartesi': return 'Pzt';
      case 'Salı': return 'Sal';
      case 'Çarşamba': return 'Çar';
      case 'Perşembe': return 'Per';
      case 'Cuma': return 'Cum';
      case 'Cumartesi': return 'Cmt';
      case 'Pazar': return 'Paz';
      default: return gun.substring(0, 3);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.9,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
      ),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(24),
                topRight: Radius.circular(24),
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  blurRadius: 8,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.red[700],
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(
                    Icons.add_circle_outline,
                    color: Colors.white,
                    size: 22,
                  ),
                ),
                SizedBox(width: 12),
                Text(
                  'Yeni Ölçüm Ekle',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: Colors.black,
                  ),
                ),
                Spacer(),
                IconButton(
                  onPressed: () => Navigator.of(context).pop(),
                  icon: Icon(Icons.close, color: Colors.grey[500]),
                ),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Form(
                key: _formKey,
                child: ListView(
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Ölçüm Türü',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Colors.grey[800],
                          ),
                        ),
                        SizedBox(height: 8),
                        DropdownButtonFormField<OlcumTuru>(
                          value: seciliOlcumTuru,
                          items: _olcumTurleri.map((OlcumTuru tur) {
                            return DropdownMenuItem(
                              value: tur,
                              child: Text(tur.olcum_turu),
                            );
                          }).toList(),
                          onChanged: (OlcumTuru? newValue) {
                            setState(() {
                              seciliOlcumTuru = newValue;
                            });
                          },
                          decoration: InputDecoration(
                            hintText: 'Ölçüm türünü seçiniz',
                            prefixIcon: Container(
                              width: 50,
                              child: Icon(Icons.analytics_outlined, color: Colors.red[700]),
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(color: Colors.grey[300]!),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(color: Colors.red[700]!, width: 2),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(color: Colors.grey[300]!),
                            ),
                          ),
                          validator: (value) {
                            if (value == null) {
                              return 'Ölçüm türü gereklidir';
                            }
                            return null;
                          },
                        ),
                      ],
                    ),

                    SizedBox(height: 20),
                    _buildSiklikSecim(),
                    SizedBox(height: 20),

                    Text(
                      'Ölçüm Saatleri',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.grey[800],
                      ),
                    ),
                    SizedBox(height: 12),
                    _seciliSaatler.isEmpty
                        ? Container(
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.grey[50],
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.grey[300]!),
                      ),
                      child: Center(
                        child: Text(
                          'Henüz saat eklenmedi',
                          style: TextStyle(
                            color: Colors.grey[500],
                          ),
                        ),
                      ),
                    )
                        : Wrap(
                      spacing: 10,
                      runSpacing: 10,
                      children: _seciliSaatler.map((saat) {
                        return Chip(
                          label: Text(
                            saat,
                            style: TextStyle(
                              color: Colors.red[700],
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          deleteIcon: Icon(Icons.close, size: 16),
                          onDeleted: () => _saatSil(saat),
                          backgroundColor: Colors.red[50],
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        );
                      }).toList(),
                    ),
                    SizedBox(height: 16),
                    Container(
                      height: 50,
                      child: OutlinedButton.icon(
                        onPressed: _saatEkle,
                        icon: Icon(
                          Icons.add_circle_outline,
                          color: Colors.red[700],
                          size: 20,
                        ),
                        label: Text(
                          'Saat Ekle',
                          style: TextStyle(
                            color: Colors.red[700],
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        style: OutlinedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          side: BorderSide(
                            color: Colors.red[700]!,
                            width: 1.5,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 32),

                    Container(
                      height: 54,
                      child: ElevatedButton(
                        onPressed: () {
                          _olcumKaydet(widget.md, widget.olcumler, '');
                        },
                        child: Text(
                          'Ölçümü Kaydet',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red[700],
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                          elevation: 2,
                          shadowColor: Colors.red[700]!.withOpacity(0.3),
                        ),
                      ),
                    ),
                    SizedBox(height: 16),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class OlcumGecmisiBottomSheet extends StatefulWidget {
  final Olcumler olcum;
  final MusteriDanisan md;
  final Function() onDegerEklendi;

  const OlcumGecmisiBottomSheet({
    Key? key,
    required this.olcum,
    required this.md,
    required this.onDegerEklendi,
  }) : super(key: key);

  @override
  State<OlcumGecmisiBottomSheet> createState() => _OlcumGecmisiBottomSheetState();
}

class _OlcumGecmisiBottomSheetState extends State<OlcumGecmisiBottomSheet> {
  List<dynamic> _olcumGecmisi = [];
  late Olcumler _currentOlcum;

  @override
  void initState() {
    super.initState();
    _currentOlcum = widget.olcum;
    _olcumGecmisi = List.from(_currentOlcum.olcum_gecmisi);
    _sortGecmis();
  }

  void _sortGecmis() {
    _olcumGecmisi.sort((a, b) => DateTime.parse(b['olcum_tarih_saat']).compareTo(DateTime.parse(a['olcum_tarih_saat'])));
  }

  void _yeniDegerEkle(String olcumGecmisiId) async {
    int? result = await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => YeniDegerEkleBottomSheet(
        md: widget.md,
        olcum: _currentOlcum,
        olcumGecmisiId: olcumGecmisiId,
        onDegerEklendi: () {
          widget.onDegerEklendi();
          _refreshOlcumGecmisi();
        },
      ),
    );

    if (result == 200) {
      await _refreshOlcumGecmisi();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(olcumGecmisiId != '' ? 'Değer başarıyla güncellendi' : 'Değer başarıyla eklendi'),
            backgroundColor: Colors.green[700],
          ),
        );
      }
    } else if (result != null && result != 200) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('İşlem sırasında bir hata oluştu. Hata kodu: $result'),
            backgroundColor: Colors.red[700],
          ),
        );
      }
    }
  }

  Future<void> _refreshOlcumGecmisi() async {
    try {
      final List<dynamic> jsonResponse = await olcumleriGetir(widget.md.id);
      final updatedOlcumler = jsonResponse.map<Olcumler>((json) => Olcumler.fromJson(json)).toList();

      final updatedOlcum = updatedOlcumler.firstWhere(
            (olcum) => olcum.id == widget.olcum.id,
      );

      if (mounted) {
        setState(() {
          _currentOlcum = updatedOlcum;
          _olcumGecmisi = List.from(updatedOlcum.olcum_gecmisi);
          _sortGecmis();
        });
      }
    } catch (e) {
      print('Ölçüm geçmişi güncellenirken hata: $e');
      if (mounted) {
        setState(() {
          _olcumGecmisi = List.from(_currentOlcum.olcum_gecmisi);
          _sortGecmis();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('dd.MM.yyyy HH:mm');
    final isKiloOlcumu = _currentOlcum.olcum_turu['id'].toString() == '5';

    return Container(
      height: MediaQuery.of(context).size.height * 0.9,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
      ),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(24),
                topRight: Radius.circular(24),
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  blurRadius: 8,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Color(int.parse(_currentOlcum.olcum_turu['renk'])),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(
                    Icons.history,
                    color: Colors.white,
                    size: 22,
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${_currentOlcum.olcum_turu['olcum_turu']} - Ölçüm Geçmişi',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Colors.black,
                        ),
                      ),

                    ],
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.of(context).pop(),
                  icon: Icon(Icons.close, color: Colors.grey[500]),
                ),
              ],
            ),
          ),

          Container(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Container(
              height: 50,
              child: ElevatedButton.icon(
                onPressed: () {
                  _yeniDegerEkle('');
                },
                icon: Icon(
                  Icons.add,
                  size: 20,
                ),
                label: Text(
                  'Yeni Değer Ekle',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(int.parse(_currentOlcum.olcum_turu['renk'])),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 2,
                ),
              ),
            ),
          ),

          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Text(
              'Toplam ${_olcumGecmisi.length} ölçüm kaydı',
              style: TextStyle(
                color: Colors.grey[600],
                fontSize: 14,
              ),
            ),
          ),
          Expanded(
            child: _olcumGecmisi.isEmpty
                ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.analytics_outlined,
                    size: 60,
                    color: Colors.grey[300],
                  ),
                  SizedBox(height: 16),
                  Text(
                    'Henüz ölçüm kaydı bulunmuyor',
                    style: TextStyle(
                      color: Colors.grey[500],
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            )
                : ListView.builder(
              padding: EdgeInsets.all(16),
              itemCount: _olcumGecmisi.length,
              itemBuilder: (context, index) {
                final olcumKaydi = _olcumGecmisi[index];
                final tarih = DateTime.parse(olcumKaydi['olcum_tarih_saat']);
                final isSonOlcum = index == 0;
                final olcumGecmisiId = olcumKaydi['id']?.toString() ?? '';

                return InkWell(
                  onTap: () {
                    _yeniDegerEkle(olcumGecmisiId);
                  },
                  child: Container(
                    margin: EdgeInsets.only(bottom: 12),
                    padding: EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: isSonOlcum
                          ? Color(int.parse(_currentOlcum.olcum_turu['renk'])).withOpacity(0.1)
                          : Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: isSonOlcum
                            ? Color(int.parse(_currentOlcum.olcum_turu['renk']))
                            : Colors.grey[200]!,
                        width: isSonOlcum ? 2 : 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.1),
                          blurRadius: 8,
                          offset: Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 50,
                          height: 50,
                          decoration: BoxDecoration(
                            color: isSonOlcum
                                ? Color(int.parse(_currentOlcum.olcum_turu['renk']))
                                : Colors.grey[300],
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(
                            Icons.analytics,
                            color: Colors.white,
                            size: 24,
                          ),
                        ),
                        SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                olcumKaydi['deger'] ?? '',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                  color: Color(int.parse(_currentOlcum.olcum_turu['renk'])),
                                ),
                              ),
                              SizedBox(height: 4),
                              Text(
                                dateFormat.format(tarih),
                                style: TextStyle(
                                  color: Colors.grey[600],
                                  fontSize: 14,
                                ),
                              ),
                              if (isSonOlcum)
                                Wrap(
                                  spacing: 4,
                                  children: [
                                    Container(
                                      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                      decoration: BoxDecoration(
                                        color: Color(int.parse(_currentOlcum.olcum_turu['renk'])),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Text(
                                        'SON ÖLÇÜM',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 10,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ),

                                  ],
                                ),
                            ],
                          ),
                        ),
                        Icon(
                          Icons.arrow_forward_ios,
                          size: 16,
                          color: Colors.grey[400],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class YeniDegerEkleBottomSheet extends StatefulWidget {
  final Olcumler olcum;
  final String olcumGecmisiId;
  final VoidCallback onDegerEklendi;
  final MusteriDanisan md;

  const YeniDegerEkleBottomSheet({
    Key? key,
    required this.olcum,
    required this.onDegerEklendi,
    required this.md,
    required this.olcumGecmisiId
  }) : super(key: key);

  @override
  State<YeniDegerEkleBottomSheet> createState() => _YeniDegerEkleBottomSheetState();
}

class _YeniDegerEkleBottomSheetState extends State<YeniDegerEkleBottomSheet> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _degerController;
  late String _olcumTuruId;
  final FocusNode _focusNode = FocusNode();

  final TextEditingController _sistolikController = TextEditingController();
  final TextEditingController _diyastolikController = TextEditingController();
  final TextEditingController _nabizController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _olcumTuruId = widget.olcum.olcum_turu['id'].toString();
    _degerController = TextEditingController();
    _setInitialValues();
  }

  @override
  void dispose() {
    _focusNode.dispose();
    super.dispose();
  }

  void _setInitialValues() {
    if (widget.olcumGecmisiId != '') {
      try {
        final gecmisKaydi = widget.olcum.olcum_gecmisi.firstWhere(
                (element) => element['id'].toString() == widget.olcumGecmisiId
        );

        if (_olcumTuruId == '1') {
          _parseTansiyonDegeri(gecmisKaydi['deger']);
        } else {
          _degerController.text = gecmisKaydi['deger'].split(' ')[0].toString();
        }
      } catch (e) {
        print('ölçüm geçmişi gelemedi $e');
      }
    }
    else {
      _degerController.clear();
      _sistolikController.clear();
      _diyastolikController.clear();
      _nabizController.clear();
    }
  }

  void _parseTansiyonDegeri(String deger) {
    try {
      final sistolikMatch = RegExp(r'(\d+)/').firstMatch(deger);
      final diyastolikMatch = RegExp(r'/(\d+)').firstMatch(deger);
      final nabizMatch = RegExp(r'Nabız\s*:\s*(\d+)').firstMatch(deger);

      if (sistolikMatch != null) {
        _sistolikController.text = sistolikMatch.group(1)!;
      }
      if (diyastolikMatch != null) {
        _diyastolikController.text = diyastolikMatch.group(1)!;
      }
      if (nabizMatch != null) {
        _nabizController.text = nabizMatch.group(1)!;
      }
    } catch (e) {
      // Hata durumunda sessizce devam et
    }
  }

  void _dismissKeyboard() {
    FocusScope.of(context).unfocus();
  }

  String? _degerValidator(String? value) {
    if (value == null || value.isEmpty) {
      return 'Değer gereklidir';
    }

    switch (_olcumTuruId) {
      case '1': // Tansiyon
        if (_sistolikController.text.isEmpty || _diyastolikController.text.isEmpty) {
          return 'Tansiyon değerleri gereklidir';
        }
        final sistolik = int.tryParse(_sistolikController.text);
        final diyastolik = int.tryParse(_diyastolikController.text);
        if (sistolik == null || diyastolik == null) {
          return 'Geçerli tansiyon değerleri giriniz';
        }
        if (sistolik < 50 || sistolik > 250 || diyastolik < 30 || diyastolik > 150) {
          return 'Tansiyon değerleri normal aralıkta olmalıdır';
        }
        break;

      case '2': // Açlık Kan Şekeri
      case '3': // Tokluk Kan Şekeri
        final seker = double.tryParse(value);
        if (seker == null) {
          return 'Geçerli bir değer giriniz';
        }
        if (seker < 20 || seker > 600) {
          return 'Kan şekeri değeri 20-600 mg/dL arasında olmalıdır';
        }
        break;

      case '4': // Ateş
        final ates = double.tryParse(value);
        if (ates == null) {
          return 'Geçerli bir değer giriniz';
        }
        if (ates < 35 || ates > 42) {
          return 'Ateş değeri 35-42°C arasında olmalıdır';
        }
        break;

      case '5': // Kilo
        final kilo = double.tryParse(value);
        if (kilo == null) {
          return 'Geçerli bir değer giriniz';
        }
        if (kilo < 20 || kilo > 300) {
          return 'Kilo değeri 20-300 kg arasında olmalıdır';
        }
        break;

      case '6': // Kalp
        final kalp = int.tryParse(value);
        if (kalp == null) {
          return 'Geçerli bir değer giriniz';
        }
        if (kalp < 30 || kalp > 250) {
          return 'Kalp atışı 30-250 arasında olmalıdır';
        }
        break;
    }

    return null;
  }

  String _getHintText() {
    switch (_olcumTuruId) {
      case '1': return 'Tansiyon değeri';
      case '2': return 'Açlık kan şekeri (mg/dL)';
      case '3': return 'Tokluk kan şekeri (mg/dL)';
      case '4': return 'Ateş (°C)';
      case '5': return 'Kilo (kg)';
      case '6': return 'Kalp atışı (bpm)';
      default: return 'Değer';
    }
  }

  TextInputType _getKeyboardType() {
    switch (_olcumTuruId) {
      case '1': return TextInputType.number;
      case '2': case '3': return TextInputType.numberWithOptions(decimal: true);
      case '4': return TextInputType.numberWithOptions(decimal: true);
      case '5': return TextInputType.numberWithOptions(decimal: true);
      case '6': return TextInputType.number;
      default: return TextInputType.text;
    }
  }

  Widget _buildTansiyonInputs() {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: TextFormField(
                controller: _sistolikController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Sistolik (Büyük)',
                  hintText: '120',
                  suffixText: 'mmHg',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Sistolik değer gereklidir';
                  }
                  final val = int.tryParse(value);
                  if (val == null || val < 50 || val > 250) {
                    return '50-250 arası değer giriniz';
                  }
                  return null;
                },
              ),
            ),
            SizedBox(width: 16),
            Expanded(
              child: TextFormField(
                controller: _diyastolikController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Diyastolik (Küçük)',
                  hintText: '80',
                  suffixText: 'mmHg',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Diyastolik değer gereklidir';
                  }
                  final val = int.tryParse(value);
                  if (val == null || val < 30 || val > 150) {
                    return '30-150 arası değer giriniz';
                  }
                  return null;
                },
              ),
            ),
          ],
        ),
        SizedBox(height: 16),
        TextFormField(
          controller: _nabizController,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(
            labelText: 'Nabız (Opsiyonel)',
            hintText: '72',
            suffixText: 'bpm',
          ),
          validator: (value) {
            if (value != null && value.isNotEmpty) {
              final val = int.tryParse(value);
              if (val == null || val < 30 || val > 250) {
                return '30-250 arası değer giriniz';
              }
            }
            return null;
          },
        ),
      ],
    );
  }

  Widget _buildNormalInput() {
    return TextFormField(
      controller: _degerController,
      keyboardType: _getKeyboardType(),
      decoration: InputDecoration(
        hintText: _getHintText(),
        suffixText: _getSuffixText(),
      ),
      validator: _degerValidator,
    );
  }

  String _getSuffixText() {
    switch (_olcumTuruId) {
      case '1': return 'mmHg';
      case '2': case '3': return 'mg/dL';
      case '4': return '°C';
      case '5': return 'kg';
      case '6': return 'bpm';
      default: return '';
    }
  }

  void _degerKaydet(String deger1,String deger2,String deger3,String deger4, String olcumId, String olcumTuruId,String olcumGecmisiId) async {
    if (_formKey.currentState!.validate()) {
      _dismissKeyboard();

      int result = await olcumDegeriEkleGuncelle(deger1, deger2, deger3, deger4, olcumId,olcumTuruId,olcumGecmisiId.toString());

      if (result == 200) {
        widget.onDegerEklendi();
      }

      Navigator.of(context).pop(result);
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _dismissKeyboard,
      behavior: HitTestBehavior.opaque,
      child: Container(
        height: MediaQuery.of(context).size.height * 0.85,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(24),
            topRight: Radius.circular(24),
          ),
        ),
        child: Column(
          children: [
            GestureDetector(
              onTap: () {},
              child: Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(24),
                    topRight: Radius.circular(24),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.1),
                      blurRadius: 8,
                      offset: Offset(0, 2),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: Color(int.parse(widget.olcum.olcum_turu['renk'])),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Icon(
                        Icons.add_chart,
                        color: Colors.white,
                        size: 22,
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '${widget.olcum.olcum_turu['olcum_turu']} Değeri ${widget.olcumGecmisiId != '' ? 'Güncelle' : 'Ekle'}',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              color: Colors.black,
                            ),
                          ),
                          if (widget.olcum.olcum_turu['id'].toString() == '5')
                            Text(
                              'Profil bilgisi de güncellenecek',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.blue[600],
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: () {
                        _dismissKeyboard();
                        Navigator.of(context).pop();
                      },
                      icon: Icon(Icons.close, color: Colors.grey[500]),
                    ),
                  ],
                ),
              ),
            ),

            Expanded(
              child: Padding(
                padding: EdgeInsets.only(
                  bottom: MediaQuery.of(context).viewInsets.bottom + 16,
                ),
                child: SingleChildScrollView(
                  physics: AlwaysScrollableScrollPhysics(),
                  padding: EdgeInsets.all(16),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          padding: EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.grey[50],
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.grey[300]!),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.info_outline,
                                color: Color(int.parse(widget.olcum.olcum_turu['renk'])),
                              ),
                              SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  widget.olcum.olcum_turu['id'].toString() == '5'
                                      ? 'Kilo ölçümü, profil bilginizle senkronize çalışır.'
                                      : '${widget.olcum.olcum_turu['olcum_turu']} ölçümü için ${widget.olcumGecmisiId != '' ? 'mevcut kaydı güncelliyorsunuz' : 'yeni değer ekliyorsunuz'}',
                                  style: TextStyle(
                                    color: Colors.grey[700],
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 24),

                        _olcumTuruId == '1'
                            ? _buildTansiyonInputs()
                            : _buildNormalInput(),

                        SizedBox(height: 32),

                        Container(
                          width: double.infinity,
                          height: 54,
                          child: ElevatedButton(
                            onPressed: () {
                              if(widget.olcum.olcum_turu['id'].toString() == "1") {
                                _degerKaydet(
                                    _sistolikController.text,
                                    _diyastolikController.text,
                                    _nabizController.text,
                                    '',
                                    widget.olcum.id.toString(),
                                    widget.olcum.olcum_turu['id'].toString(),
                                    widget.olcumGecmisiId
                                );
                              } else {
                                _degerKaydet(
                                    "", "", "",
                                    _degerController.text,
                                    widget.olcum.id.toString(),
                                    widget.olcum.olcum_turu['id'].toString(),
                                    widget.olcumGecmisiId
                                );
                              }
                            },
                            child: Text(
                              widget.olcumGecmisiId != '' ? 'Değeri Güncelle' : 'Değeri Kaydet',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Color(int.parse(widget.olcum.olcum_turu['renk'])),
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                              elevation: 2,
                            ),
                          ),
                        ),

                        SizedBox(height: MediaQuery.of(context).viewInsets.bottom > 0 ? 100 : 20),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}