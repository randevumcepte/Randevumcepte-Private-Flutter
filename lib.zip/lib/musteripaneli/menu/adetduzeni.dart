

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import '../../Backend/backend.dart';
import '../../Models/AdetDuzeni.dart';
import '../../Models/musteri_danisanlar.dart';

class AdetTakipPage extends StatefulWidget {
  final dynamic kullanici;
  final MusteriDanisan md;
  final dynamic isletmebilgi;
  const AdetTakipPage({Key? key, this.kullanici, required this.md,required this.isletmebilgi}) : super(key: key);

  @override
  State<AdetTakipPage> createState() => _AdetTakipPageState();
}

class _AdetTakipPageState extends State<AdetTakipPage> {
  List<AdetDonemi> adetDonemleri = [];
  bool _isLoading = true;
  String _errorMessage = '';

  // Takvim state
  CalendarFormat _calendarFormat = CalendarFormat.month;
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  int _defaultSure = 5; // Varsayılan adet süresi

  // Ortalama değerler
  int ortalamaDongu = 28; // Varsayılan 28 gün
  int ortalamaSure = 5;
  DateTime? tahminiSonrakiTarih;

  // Tüm dönemler için listeler
  List<DateTime> tumAdetGunleri = [];
  List<DateTime> tumZayifHamilelikGunleri = [];
  List<DateTime> tumNormalHamilelikGunleri = [];
  List<DateTime> tumYuksekHamilelikGunleri = [];
  List<DateTime> tumAdetOncesiGunleri = [];
  List<DateTime> tumTahminiAdetGunleri = [];
  List<DateTime> tumTahminiAdetOncesiGunleri = [];
  List<DateTime> tumTahminiZayifHamilelikGunleri = [];
  List<DateTime> tumTahminiNormalHamilelikGunleri = [];
  List<DateTime> tumTahminiYuksekHamilelikGunleri = [];

  // Seçili gün bilgisi
  DateTime? _infoGun;
  FertilityInfo? _selectedDayInfo;

  @override
  void initState() {
    super.initState();
    _selectedDay = DateTime.now();
    _infoGun = DateTime.now();
    _adetDonemleriniGetir();
  }

  Future<void> _adetDonemleriniGetir() async {
    try {
      setState(() {
        _isLoading = true;
        _errorMessage = '';
      });

      final response = await adetduzeniGetir(widget.md.id.toString());

      if (response is List) {
        List<AdetDonemi> donemler = response.map((item) {
          return AdetDonemi(
            id: item['id'].toString(),
            baslangicTarihi: DateTime.parse(item['baslangic_tarihi']),
            bitisTarihi: DateTime.parse(item['bitis_tarihi']),
            sure: int.parse(item['sure'].toString()),
            dongu: int.parse(item['dongu'].toString()),
            belirtiler: List<String>.from(item['belirtiler'] ?? []),
            not: item['not_metni'] ?? item['not'] ?? '',
            renk: _stringToColor(item['renk'] ?? '#C2185B'),
          );
        }).toList();

        donemler.sort((a, b) => b.baslangicTarihi.compareTo(a.baslangicTarihi));

        setState(() {
          adetDonemleri = donemler;
          _hesaplaOrtalamalar();
          _hesaplaTahminiTarih();
          _hesaplaTumHamilelikDonemleri(); // Tüm dönemleri hesapla
          // Gün bilgisini güncelle
          _selectedDayInfo = _getFertilityInfoForDay(_selectedDay!);
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Adet dönemleri yüklenirken hata oluştu: $e';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Color _stringToColor(String colorString) {
    try {
      String hexColor = colorString.replaceAll('#', '');
      if (hexColor.length == 6) {
        hexColor = 'FF$hexColor';
      }
      return Color(int.parse(hexColor, radix: 16));
    } catch (e) {
      return Colors.pink[700]!;
    }
  }

  void _hesaplaOrtalamalar() {
    if (adetDonemleri.isNotEmpty) {
      List<int> donguSureleri = [];
      List<int> adetSureleri = [];

      // Döngü sürelerini hesapla (en az 2 kayıt gerekiyor)
      if (adetDonemleri.length >= 2) {
        for (int i = 0; i < adetDonemleri.length - 1; i++) {
          final current = adetDonemleri[i];
          final next = adetDonemleri[i + 1];
          final dongu = current.baslangicTarihi.difference(next.baslangicTarihi).inDays;
          if (dongu > 0 && dongu < 60) { // 60 günden uzun döngüleri atla (olası hatalar için)
            donguSureleri.add(dongu);
          }
        }
      }

      adetSureleri = adetDonemleri.map((e) => e.sure).toList();

      if (donguSureleri.isNotEmpty) {
        final toplamDongu = donguSureleri.reduce((a, b) => a + b);
        ortalamaDongu = (toplamDongu / donguSureleri.length).round();
      } else {
        // Eğer döngü hesaplanamıyorsa, ilk kayıttaki döngü değerini kullan veya varsayılan 28 gün
        ortalamaDongu = adetDonemleri.first.dongu > 0 ? adetDonemleri.first.dongu : 28;
      }

      if (adetSureleri.isNotEmpty) {
        final toplamSure = adetSureleri.reduce((a, b) => a + b);
        ortalamaSure = (toplamSure / adetSureleri.length).round();
        _defaultSure = ortalamaSure;
      }

      setState(() {});
    }
  }

  void _hesaplaTahminiTarih() {
    if (adetDonemleri.isNotEmpty && ortalamaDongu > 0) {
      final sonDonem = adetDonemleri.first;
      setState(() {
        tahminiSonrakiTarih = sonDonem.baslangicTarihi.add(Duration(days: ortalamaDongu));
      });
    }
  }

  void _hesaplaTumHamilelikDonemleri() {
    // Listeleri temizle
    tumAdetGunleri.clear();
    tumZayifHamilelikGunleri.clear();
    tumNormalHamilelikGunleri.clear();
    tumYuksekHamilelikGunleri.clear();
    tumAdetOncesiGunleri.clear();
    tumTahminiAdetGunleri.clear();
    tumTahminiAdetOncesiGunleri.clear();
    tumTahminiZayifHamilelikGunleri.clear();
    tumTahminiNormalHamilelikGunleri.clear();
    tumTahminiYuksekHamilelikGunleri.clear();

    if (adetDonemleri.isNotEmpty) {
      // Tüm geçmiş dönemleri işle
      for (final adetDonemi in adetDonemleri) {
        _hesaplaTekilHamilelikDonemi(adetDonemi);
      }

      // Tahmini gelecek dönemleri hesapla
      _hesaplaTahminiGelecekDonemler();
    }
  }

  void _hesaplaTekilHamilelikDonemi(AdetDonemi donem) {
    // 1. ADET GÜNLERİ (KIRMIZI) - Gerçek kayıt
    DateTime currentAdet = donem.baslangicTarihi;
    for (int i = 0; i < donem.sure; i++) {
      if (!tumAdetGunleri.any((gun) => isSameDay(gun, currentAdet))) {
        tumAdetGunleri.add(currentAdet);
      }
      currentAdet = currentAdet.add(Duration(days: 1));
    }

    // 2. ZAYIF HAMİLELİK (GRİ) - Adet bitişinden sonraki 3 gün
    final zayifBaslangic = donem.bitisTarihi.add(Duration(days: 1));
    for (int i = 0; i < 3; i++) {
      final gun = zayifBaslangic.add(Duration(days: i));
      if (!tumZayifHamilelikGunleri.any((mevcutGun) => isSameDay(mevcutGun, gun)) &&
          !tumAdetGunleri.any((adetGun) => isSameDay(adetGun, gun))) {
        tumZayifHamilelikGunleri.add(gun);
      }
    }

    // 3. YÜKSEK HAMİLELİK (MOR) - Adet başlangıcından 14 gün sonrası (2 gün)
    final yuksekBaslangic = donem.baslangicTarihi.add(Duration(days: 13));
    for (int i = 0; i < 1; i++) {
      final gun = yuksekBaslangic.add(Duration(days: i));
      if (!tumYuksekHamilelikGunleri.any((mevcutGun) => isSameDay(mevcutGun, gun)) &&
          !tumAdetGunleri.any((adetGun) => isSameDay(adetGun, gun)) &&
          !tumZayifHamilelikGunleri.any((zayifGun) => isSameDay(zayifGun, gun))) {
        tumYuksekHamilelikGunleri.add(gun);
      }
    }

    // 4. ADET ÖNCESİ (SARI) - Adet başlangıcından 5 gün öncesi
    final adetOncesiBaslangic = donem.baslangicTarihi.subtract(Duration(days: 5));
    for (int i = 0; i < 5; i++) {
      final gun = adetOncesiBaslangic.add(Duration(days: i));
      if (!tumAdetOncesiGunleri.any((mevcutGun) => isSameDay(mevcutGun, gun)) &&
          !tumAdetGunleri.any((adetGun) => isSameDay(adetGun, gun)) &&
          !tumZayifHamilelikGunleri.any((zayifGun) => isSameDay(zayifGun, gun)) &&
          !tumYuksekHamilelikGunleri.any((yuksekGun) => isSameDay(yuksekGun, gun))) {
        tumAdetOncesiGunleri.add(gun);
      }
    }

    // 5. NORMAL HAMİLELİK (MAVİ) - Zayıf hamilelikten sonraki 5 gün + Yüksek hamilelikten 2 gün sonrası
    final normal1Baslangic = zayifBaslangic.add(Duration(days: 3)); // Zayıf hamilelikten sonra
    for (int i = 0; i < 5; i++) {
      final gun = normal1Baslangic.add(Duration(days: i));
      if (!tumNormalHamilelikGunleri.any((mevcutGun) => isSameDay(mevcutGun, gun)) &&
          !tumAdetGunleri.any((adetGun) => isSameDay(adetGun, gun)) &&
          !tumZayifHamilelikGunleri.any((zayifGun) => isSameDay(zayifGun, gun)) &&
          !tumYuksekHamilelikGunleri.any((yuksekGun) => isSameDay(yuksekGun, gun)) &&
          !tumAdetOncesiGunleri.any((oncesiGun) => isSameDay(oncesiGun, gun))) {
        tumNormalHamilelikGunleri.add(gun);
      }
    }

    final normal2Baslangic = yuksekBaslangic.add(Duration(days: 1)); // Yüksek hamilelikten sonra
    for (int i = 0; i < 2; i++) {
      final gun = normal2Baslangic.add(Duration(days: i));
      if (!tumNormalHamilelikGunleri.any((mevcutGun) => isSameDay(mevcutGun, gun)) &&
          !tumAdetGunleri.any((adetGun) => isSameDay(adetGun, gun)) &&
          !tumZayifHamilelikGunleri.any((zayifGun) => isSameDay(zayifGun, gun)) &&
          !tumYuksekHamilelikGunleri.any((yuksekGun) => isSameDay(yuksekGun, gun)) &&
          !tumAdetOncesiGunleri.any((oncesiGun) => isSameDay(oncesiGun, gun))) {
        tumNormalHamilelikGunleri.add(gun);
      }
    }
  }

  void _hesaplaTahminiGelecekDonemler() {
    if (adetDonemleri.isNotEmpty && tahminiSonrakiTarih != null) {
      final sonDonem = adetDonemleri.first;

      // Birden fazla gelecek dönem hesapla (6 dönem kadar)
      for (int donemIndex = 0; donemIndex < 6; donemIndex++) {
        final tahminiBaslangic = tahminiSonrakiTarih!.add(Duration(days: donemIndex * ortalamaDongu));

        // TAHMİNİ ADET (SOLUK PEMBE)
        for (int i = 0; i < _defaultSure; i++) {
          final gun = tahminiBaslangic.add(Duration(days: i));
          if (!tumTahminiAdetGunleri.any((tahminiGun) => isSameDay(tahminiGun, gun)) &&
              !tumAdetGunleri.any((adetGun) => isSameDay(adetGun, gun))) {
            tumTahminiAdetGunleri.add(gun);
          }
        }

        final tahminiBitis = tahminiBaslangic.add(Duration(days: _defaultSure - 1));

        // TAHMİNİ ZAYIF HAMİLELİK (SOLUK GRİ)
        final tahminiZayifBaslangic = tahminiBitis.add(Duration(days: 1));
        for (int i = 0; i < 3; i++) {
          final gun = tahminiZayifBaslangic.add(Duration(days: i));
          if (!tumTahminiZayifHamilelikGunleri.any((tahminiGun) => isSameDay(tahminiGun, gun)) &&
              !tumTahminiAdetGunleri.any((adetGun) => isSameDay(adetGun, gun)) &&
              !tumAdetGunleri.any((adetGun) => isSameDay(adetGun, gun))) {
            tumTahminiZayifHamilelikGunleri.add(gun);
          }
        }

        // TAHMİNİ YÜKSEK HAMİLELİK (SOLUK MOR)
        final tahminiYuksekBaslangic = tahminiBaslangic.add(Duration(days: 13));
        for (int i = 0; i < 1; i++) {
          final gun = tahminiYuksekBaslangic.add(Duration(days: i));
          if (!tumTahminiYuksekHamilelikGunleri.any((tahminiGun) => isSameDay(tahminiGun, gun)) &&
              !tumTahminiAdetGunleri.any((adetGun) => isSameDay(adetGun, gun)) &&
              !tumTahminiZayifHamilelikGunleri.any((zayifGun) => isSameDay(zayifGun, gun)) &&
              !tumAdetGunleri.any((adetGun) => isSameDay(adetGun, gun))) {
            tumTahminiYuksekHamilelikGunleri.add(gun);
          }
        }

        // TAHMİNİ ADET ÖNCESİ (SOLUK SARI)
        final tahminiAdetOncesiBaslangic = tahminiBaslangic.subtract(Duration(days: 5));
        for (int i = 0; i < 5; i++) {
          final gun = tahminiAdetOncesiBaslangic.add(Duration(days: i));
          if (!tumTahminiAdetOncesiGunleri.any((tahminiOncesi) => isSameDay(tahminiOncesi, gun)) &&
              !tumAdetOncesiGunleri.any((oncesiGun) => isSameDay(oncesiGun, gun)) &&
              !tumAdetGunleri.any((adetGun) => isSameDay(adetGun, gun)) &&
              !tumTahminiAdetGunleri.any((tahminiAdet) => isSameDay(tahminiAdet, gun))) {
            tumTahminiAdetOncesiGunleri.add(gun);
          }
        }

        // TAHMİNİ NORMAL HAMİLELİK (SOLUK MAVİ)
        final tahminiNormal1Baslangic = tahminiZayifBaslangic.add(Duration(days: 3));
        for (int i = 0; i < 5; i++) {
          final gun = tahminiNormal1Baslangic.add(Duration(days: i));
          if (!tumTahminiNormalHamilelikGunleri.any((tahminiGun) => isSameDay(tahminiGun, gun)) &&
              !tumTahminiAdetGunleri.any((adetGun) => isSameDay(adetGun, gun)) &&
              !tumTahminiZayifHamilelikGunleri.any((zayifGun) => isSameDay(zayifGun, gun)) &&
              !tumTahminiYuksekHamilelikGunleri.any((yuksekGun) => isSameDay(yuksekGun, gun)) &&
              !tumTahminiAdetOncesiGunleri.any((oncesiGun) => isSameDay(oncesiGun, gun))) {
            tumTahminiNormalHamilelikGunleri.add(gun);
          }
        }

        final tahminiNormal2Baslangic = tahminiYuksekBaslangic.add(Duration(days: 1));
        for (int i = 0; i < 2; i++) {
          final gun = tahminiNormal2Baslangic.add(Duration(days: i));
          if (!tumTahminiNormalHamilelikGunleri.any((tahminiGun) => isSameDay(tahminiGun, gun)) &&
              !tumTahminiAdetGunleri.any((adetGun) => isSameDay(adetGun, gun)) &&
              !tumTahminiZayifHamilelikGunleri.any((zayifGun) => isSameDay(zayifGun, gun)) &&
              !tumTahminiYuksekHamilelikGunleri.any((yuksekGun) => isSameDay(yuksekGun, gun)) &&
              !tumTahminiAdetOncesiGunleri.any((oncesiGun) => isSameDay(oncesiGun, gun))) {
            tumTahminiNormalHamilelikGunleri.add(gun);
          }
        }
      }
    }
  }

  FertilityInfo _getFertilityInfoForDay(DateTime day) {
    final isAdetGunu = tumAdetGunleri.any((gun) => isSameDay(gun, day));
    final isTahminiAdet = tumTahminiAdetGunleri.any((gun) => isSameDay(gun, day));
    final isZayifHamilelik = tumZayifHamilelikGunleri.any((gun) => isSameDay(gun, day));
    final isNormalHamilelik = tumNormalHamilelikGunleri.any((gun) => isSameDay(gun, day));
    final isYuksekHamilelik = tumYuksekHamilelikGunleri.any((gun) => isSameDay(gun, day));
    final isAdetOncesi = tumAdetOncesiGunleri.any((gun) => isSameDay(gun, day));
    final isTahminiAdetOncesi = tumTahminiAdetOncesiGunleri.any((gun) => isSameDay(gun, day));
    final isTahminiZayifHamilelik = tumTahminiZayifHamilelikGunleri.any((gun) => isSameDay(gun, day));
    final isTahminiNormalHamilelik = tumTahminiNormalHamilelikGunleri.any((gun) => isSameDay(gun, day));
    final isTahminiYuksekHamilelik = tumTahminiYuksekHamilelikGunleri.any((gun) => isSameDay(gun, day));

    if (isAdetGunu) {
      return FertilityInfo(
        durum: 'Adet Dönemi',
        aciklama: 'Hamile kalma ihtimali çok düşük',
        renk: Colors.red[400]!,
        icon: Icons.bloodtype,
        yuzde: '%0-5',
        risk: 'Çok Düşük',
      );
    } else if (isTahminiAdet) {
      return FertilityInfo(
        durum: 'Tahmini Adet',
        aciklama: 'Adet dönemi başlayabilir',
        renk: Colors.pink[100]!,
        icon: Icons.calendar_today,
        yuzde: '%0-5',
        risk: 'Çok Düşük',
      );
    } else if (isYuksekHamilelik) {
      return FertilityInfo(
        durum: 'Yüksek Hamilelik',
        aciklama: 'Hamile kalma ihtimali en yüksek',
        renk: Colors.purple[400]!,
        icon: Icons.arrow_upward,
        yuzde: '%25-30',
        risk: 'Çok Yüksek',
      );
    } else if (isTahminiYuksekHamilelik) {
      return FertilityInfo(
        durum: 'Tahmini Yüksek Hamilelik',
        aciklama: 'Hamile kalma ihtimali en yüksek (tahmini)',
        renk: Colors.purple[100]!,
        icon: Icons.arrow_upward,
        yuzde: '%25-30',
        risk: 'Çok Yüksek',
      );
    } else if (isNormalHamilelik) {
      return FertilityInfo(
        durum: 'Normal Hamilelik',
        aciklama: 'Hamile kalma ihtimali orta',
        renk: Colors.blue[400]!,
        icon: Icons.trending_up,
        yuzde: '%15-20',
        risk: 'Orta',
      );
    } else if (isTahminiNormalHamilelik) {
      return FertilityInfo(
        durum: 'Tahmini Normal Hamilelik',
        aciklama: 'Hamile kalma ihtimali orta (tahmini)',
        renk: Colors.blue[100]!,
        icon: Icons.trending_up,
        yuzde: '%15-20',
        risk: 'Orta',
      );
    } else if (isZayifHamilelik) {
      return FertilityInfo(
        durum: 'Zayıf Hamilelik',
        aciklama: 'Hamile kalma ihtimali düşük',
        renk: Colors.grey[400]!,
        icon: Icons.arrow_downward,
        yuzde: '%5-10',
        risk: 'Düşük',
      );
    } else if (isTahminiZayifHamilelik) {
      return FertilityInfo(
        durum: 'Tahmini Zayıf Hamilelik',
        aciklama: 'Hamile kalma ihtimali düşük (tahmini)',
        renk: Colors.grey[300]!,
        icon: Icons.arrow_downward,
        yuzde: '%5-10',
        risk: 'Düşük',
      );
    } else if (isAdetOncesi) {
      return FertilityInfo(
        durum: 'Adet Öncesi',
        aciklama: 'PMS dönemi - hamilelik ihtimali düşük',
        renk: Colors.orange[400]!,
        icon: Icons.warning,
        yuzde: '%5-10',
        risk: 'Düşük',
      );
    } else if (isTahminiAdetOncesi) {
      return FertilityInfo(
        durum: 'Tahmini Adet Öncesi',
        aciklama: 'PMS dönemi - hamilelik ihtimali düşük (tahmini)',
        renk: Colors.orange[100]!,
        icon: Icons.warning,
        yuzde: '%5-10',
        risk: 'Düşük',
      );
    } else {
      return FertilityInfo(
        durum: 'Normal Dönem',
        aciklama: 'Hamile kalma ihtimali düşük',
        renk: Colors.grey[300]!, // Kalan günler için gri
        icon: Icons.horizontal_rule,
        yuzde: '%5-10',
        risk: 'Düşük',
      );
    }
  }

  void _onDaySelected(DateTime selectedDay, DateTime focusedDay) {
    setState(() {
      _selectedDay = selectedDay;
      _focusedDay = focusedDay;
      _infoGun = selectedDay;
      _selectedDayInfo = _getFertilityInfoForDay(selectedDay);
    });

    final isAdetGunu = tumAdetGunleri.any((gun) => isSameDay(gun, selectedDay));
    final isTahminiAdet = tumTahminiAdetGunleri.any((gun) => isSameDay(gun, selectedDay));

    // Eğer bu gün TAHMİNİ ADET günüyse ve bugün veya geçmiş bir günse,
    // otomatik olarak gerçek adet dönemi yap
    if (isTahminiAdet && selectedDay.isBefore(DateTime.now().add(Duration(days: 1)))) {
      _tahminiAdetiGercekYap(selectedDay);
    }
    // Sadece GERÇEK ADET GÜNÜ (kırmızı) ise BİLGİ göster
    else if (isAdetGunu) {
      _showAdetDayInfo(selectedDay);
    }
    // BOŞ gün ise EKLEME dialog göster
    else {
      _showAdetEklemeOnayi(selectedDay);
    }
  }
  void _tahminiAdetiGercekYap(DateTime selectedDay) {
    // Seçilen günün tahmini adet dönemini bul
    final tahminiAdetDonemi = _findTahminiAdetDonemi(selectedDay);

    if (tahminiAdetDonemi != null) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Row(
            children: [
              Icon(Icons.check_circle, color: Colors.green[700]),
              SizedBox(width: 8),
              Text('Tahmini Adet Onayı'),
            ],
          ),
          content: Text(
            '${DateFormat('dd.MM.yyyy').format(tahminiAdetDonemi['baslangic'])} - ${DateFormat('dd.MM.yyyy').format(tahminiAdetDonemi['bitis'])} tarihleri arasında '
                '${tahminiAdetDonemi['sure']} günlük adet dönemi başladı mı?\n\n'
                'Tahmini adet dönemi gerçek adet dönemine dönüştürülecek.',
            style: TextStyle(fontSize: 14),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('Hayır', style: TextStyle(color: Colors.grey[600])),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                _tahminiAdetiKaydet(tahminiAdetDonemi, selectedDay);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green[700],
                foregroundColor: Colors.white,
              ),
              child: Text('Evet, Başladı'),
            ),
          ],
        ),
      );
    } else {
      _showAdetEklemeOnayi(selectedDay);
    }
  }
  Future<void> _tahminiAdetiKaydet(Map<String, dynamic> tahminiDonem, DateTime selectedDay) async {
    try {
      final dateFormat = DateFormat('yyyy-MM-dd');
      final baslangicTarihi = tahminiDonem['baslangic'] as DateTime;
      final bitisTarihi = tahminiDonem['bitis'] as DateTime;
      final sure = tahminiDonem['sure'] as int;

      // Önceki dönemi bul
      final AdetDonemi? oncekiDonem = adetDonemleri.isNotEmpty ? adetDonemleri.first : null;
      int? dongu;

      if (oncekiDonem != null) {
        dongu = baslangicTarihi.difference(oncekiDonem.baslangicTarihi).inDays;
      } else {
        // İlk kayıt için varsayılan döngü
        dongu = 28;
      }

      // Veritabanına kaydet
      final result = await adetekle(
          dateFormat.format(baslangicTarihi),
          dateFormat.format(bitisTarihi),
          dongu.toString(),
          widget.md.id.toString(),
          '',
          sure.toString(),
          [],
          widget.isletmebilgi['id'].toString()
      );

      if (result['success'] == true) {
        // Başarılı kayıt sonrası takvimi yenile
        await _adetDonemleriniGetir();

        // Takvimi yeniden hesapla
        setState(() {
          _hesaplaOrtalamalar();
          _hesaplaTahminiTarih();
          _hesaplaTumHamilelikDonemleri();

          // Seçili gün bilgisini güncelle
          _selectedDayInfo = _getFertilityInfoForDay(selectedDay);
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Adet dönemi gerçek kayıt olarak eklendi!'),
            backgroundColor: Colors.green[700],
            duration: Duration(seconds: 3),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Hata: ${result['message']}'),
            backgroundColor: Colors.red[700],
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Hata oluştu: $e'),
          backgroundColor: Colors.red[700],
        ),
      );
    }
  }
  Map<String, dynamic>? _findTahminiAdetDonemi(DateTime day) {
    // Bu günün içinde olduğu tahmini adet dönemini bul
    for (int i = 0; i < tumTahminiAdetGunleri.length; i++) {
      final tahminiAdetGunu = tumTahminiAdetGunleri[i];

      // Bu tahmini adet gününün başlangıcını bul
      DateTime? baslangic;
      DateTime? bitis;

      // Önceki tahmini adet günlerine bakarak başlangıcı bul
      for (int j = i; j >= 0; j--) {
        if (j == 0 || !tumTahminiAdetGunleri[j].subtract(Duration(days: 1)).isAtSameMomentAs(tumTahminiAdetGunleri[j-1])) {
          baslangic = tumTahminiAdetGunleri[j];
          break;
        }
      }

      // Sonraki tahmini adet günlerine bakarak bitişi bul
      for (int j = i; j < tumTahminiAdetGunleri.length; j++) {
        if (j == tumTahminiAdetGunleri.length - 1 ||
            !tumTahminiAdetGunleri[j].add(Duration(days: 1)).isAtSameMomentAs(tumTahminiAdetGunleri[j+1])) {
          bitis = tumTahminiAdetGunleri[j];
          break;
        }
      }

      if (baslangic != null && bitis != null &&
          (day.isAfter(baslangic.subtract(Duration(days: 1))) && day.isBefore(bitis.add(Duration(days: 1))))) {
        final sure = bitis.difference(baslangic).inDays + 1;
        return {
          'baslangic': baslangic,
          'bitis': bitis,
          'sure': sure,
          'dongu': ortalamaDongu,
        };
      }
    }
    return null;
  }
  void _showAdetEklemeOnayi(DateTime baslangicTarihi) {
    final bitisTarihi = baslangicTarihi.add(Duration(days: _defaultSure - 1));
    final dateFormat = DateFormat('dd.MM.yyyy');

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Icon(Icons.calendar_today, color: Colors.pink[700]),
            SizedBox(width: 8),
            Text('Adet Dönemi Ekle'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${dateFormat.format(baslangicTarihi)} - ${dateFormat.format(bitisTarihi)} tarihleri arasında $_defaultSure günlük adet dönemi eklemek istiyor musunuz?',
              style: TextStyle(fontSize: 14),
            ),
            SizedBox(height: 16),
            Text(
              'Belirtileri eklemek ister misiniz?',
              style: TextStyle(fontWeight: FontWeight.w600, color: Colors.grey[700]),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('İptal', style: TextStyle(color: Colors.grey[600])),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              _adetDonemiOtomatikEkle(baslangicTarihi, belirtiler: []);
            },
            child: Text('Sadece Ekle', style: TextStyle(color: Colors.blue[700])),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              _showBelirtiSecimDialog(baslangicTarihi);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.pink[700],
              foregroundColor: Colors.white,
            ),
            child: Text('Belirti Ekle'),
          ),
        ],
      ),
    );
  }

  void _showBelirtiSecimDialog(DateTime baslangicTarihi) {
    showDialog(
      context: context,
      builder: (context) => BelirtiSecimDialog(
        baslangicTarihi: baslangicTarihi,
        isletmebilgi: widget.isletmebilgi,
        defaultSure: _defaultSure,
        onAdetDonemiEklendi: (yeniDonem) {
          _adetDonemleriniGetir();
        },
        userId: widget.md.id.toString(),
        oncekiDonem: adetDonemleri.isNotEmpty ? adetDonemleri.first : null,
      ),
    );
  }

  Future<void> _adetDonemiOtomatikEkle(DateTime baslangicTarihi, {List<String> belirtiler = const []}) async {
    final bitisTarihi = baslangicTarihi.add(Duration(days: _defaultSure - 1));
    final sure = _defaultSure;

    // Önceki dönemi bul
    final AdetDonemi? oncekiDonem = adetDonemleri.isNotEmpty ? adetDonemleri.first : null;
    int? dongu;

    if (oncekiDonem != null) {
      dongu = baslangicTarihi.difference(oncekiDonem.baslangicTarihi).inDays;
    } else {
      // İlk kayıt için varsayılan döngü
      dongu = 28;
    }

    try {
      final dateFormat = DateFormat('yyyy-MM-dd');
      final donguStr = (dongu ?? 28).toString();

      final result = await adetekle(
          dateFormat.format(baslangicTarihi),
          dateFormat.format(bitisTarihi),
          donguStr,
          widget.md.id.toString(),
          '',
          sure.toString(),
          belirtiler,
          widget.isletmebilgi['id'].toString()
      );

      if (result['success'] == true) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('$sure günlük adet dönemi başarıyla eklendi${belirtiler.isNotEmpty ? ' (${belirtiler.length} belirti)' : ''}'),
            backgroundColor: Colors.green[700],
            duration: Duration(seconds: 2),
          ),
        );

        // Takvimi tamamen yenile
        await _adetDonemleriniGetir();

        setState(() {
          _hesaplaOrtalamalar();
          _hesaplaTahminiTarih();
          _hesaplaTumHamilelikDonemleri();

          // Seçili gün bilgisini güncelle
          _selectedDayInfo = _getFertilityInfoForDay(_selectedDay!);
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Hata: ${result['message']}'),
            backgroundColor: Colors.red[700],
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Adet dönemi eklenirken hata oluştu: $e'),
          backgroundColor: Colors.red[700],
        ),
      );
    }
  }
  void _showAdetDayInfo(DateTime day) {
    // Bu güne ait adet dönemini bul
    AdetDonemi? adetDonemi;
    for (final donem in adetDonemleri) {
      if ((day.isAfter(donem.baslangicTarihi.subtract(Duration(days: 1))) &&
          day.isBefore(donem.bitisTarihi.add(Duration(days: 1))))) {
        adetDonemi = donem;
        break;
      }
    }

    // Eğer bulunamazsa son dönemi kullan
    adetDonemi ??= adetDonemleri.first;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => AdetGunuInfoBottomSheet(
        gun: day,
        adetDonemi: adetDonemi!,
        fertilityInfo: _getFertilityInfoForDay(day),
      ),
    );
  }

  void _showFertilityInfo() {
    showDialog(
      context: context,
      builder: (context) => FertilityInfoDialog(
        adetGunleri: tumAdetGunleri,
        zayifHamilelikGunleri: tumZayifHamilelikGunleri,
        normalHamilelikGunleri: tumNormalHamilelikGunleri,
        yuksekHamilelikGunleri: tumYuksekHamilelikGunleri,
        adetOncesiGunleri: tumAdetOncesiGunleri,
        tahminiAdetGunleri: tumTahminiAdetGunleri,
        tahminiAdetOncesiGunleri: tumTahminiAdetOncesiGunleri,
        tahminiZayifHamilelikGunleri: tumTahminiZayifHamilelikGunleri,
        tahminiNormalHamilelikGunleri: tumTahminiNormalHamilelikGunleri,
        tahminiYuksekHamilelikGunleri: tumTahminiYuksekHamilelikGunleri,
      ),
    );
  }

  void _showSureAyari() {
    showDialog(
      context: context,
      builder: (context) => SureAyariDialog(
        mevcutSure: _defaultSure,
        onSureDegisti: (yeniSure) {
          setState(() {
            _defaultSure = yeniSure;
          });
        },
      ),
    );
  }
  void _yenileTakvim() {
    if (mounted) {
      setState(() {
        _hesaplaOrtalamalar();
        _hesaplaTahminiTarih();
        _hesaplaTumHamilelikDonemleri();
        _selectedDayInfo = _getFertilityInfoForDay(_selectedDay ?? DateTime.now());
      });
    }
  }
  Widget _buildCalendarDay(DateTime day, DateTime focusedDay) {
    bool isSameMonth(DateTime a, DateTime b) {
      return a.month == b.month && a.year == b.year;
    }

    final isSelected = isSameDay(_selectedDay, day);
    final isToday = isSameDay(day, DateTime.now());
    final isAdetGunu = tumAdetGunleri.any((gun) => isSameDay(gun, day));
    final isTahminiAdet = tumTahminiAdetGunleri.any((gun) => isSameDay(gun, day));
    final isZayifHamilelik = tumZayifHamilelikGunleri.any((gun) => isSameDay(gun, day));
    final isNormalHamilelik = tumNormalHamilelikGunleri.any((gun) => isSameDay(gun, day));
    final isYuksekHamilelik = tumYuksekHamilelikGunleri.any((gun) => isSameDay(gun, day));
    final isAdetOncesi = tumAdetOncesiGunleri.any((gun) => isSameDay(gun, day));
    final isTahminiAdetOncesi = tumTahminiAdetOncesiGunleri.any((gun) => isSameDay(gun, day));
    final isTahminiZayifHamilelik = tumTahminiZayifHamilelikGunleri.any((gun) => isSameDay(gun, day));
    final isTahminiNormalHamilelik = tumTahminiNormalHamilelikGunleri.any((gun) => isSameDay(gun, day));
    final isTahminiYuksekHamilelik = tumTahminiYuksekHamilelikGunleri.any((gun) => isSameDay(gun, day));

    // Bu gün şu an görüntülenen aya mı ait değil mi?
    final isOutsideMonth = !isSameMonth(day, focusedDay);

    Color backgroundColor = Colors.grey[300]!;
    Color textColor = Colors.black;
    String? label;
    Border? border;
    double opacity = isOutsideMonth ? 0.5 : 1.0;

    // TAHMİNİ günler SADECE GELECEKTE ise göster (bugün ve geçmiş değilse)
    final isTahminiDayAndFuture = (isTahminiAdet || isTahminiAdetOncesi || isTahminiZayifHamilelik ||
        isTahminiNormalHamilelik || isTahminiYuksekHamilelik) &&
        day.isAfter(DateTime.now());

    // GERÇEK kayıtlar - her zaman göster
    if (isAdetGunu) {
      backgroundColor = Colors.red[500]!.withOpacity(opacity);
      textColor = Colors.black.withOpacity(opacity);
      label = 'A';
    } else if (isYuksekHamilelik) {
      backgroundColor = Colors.purple[400]!.withOpacity(opacity);
      textColor = Colors.black.withOpacity(opacity);
      label = 'Y';
    } else if (isNormalHamilelik) {
      backgroundColor = Colors.blue[400]!.withOpacity(opacity);
      textColor = Colors.black.withOpacity(opacity);
      label = 'N';
    } else if (isZayifHamilelik) {
      backgroundColor = Colors.grey[300]!.withOpacity(opacity);
      textColor = Colors.black.withOpacity(opacity);
      label = 'Z';
    } else if (isAdetOncesi) {
      backgroundColor = Colors.orange[400]!.withOpacity(opacity);
      textColor = Colors.black.withOpacity(opacity);
      label = 'Ö';
    }
    // TAHMİNİ günler - sadece gelecekte ise göster
    else if (isTahminiDayAndFuture) {
      if (isTahminiAdet) {
        backgroundColor = Colors.pink[100]!.withOpacity(opacity);
        textColor = Colors.pink[800]!.withOpacity(opacity);
        label = 'T';
      } else if (isTahminiYuksekHamilelik) {
        backgroundColor = Colors.purple[100]!.withOpacity(opacity);
        textColor = Colors.purple[800]!.withOpacity(opacity);
        label = 'TY';
      } else if (isTahminiNormalHamilelik) {
        backgroundColor = Colors.blue[100]!.withOpacity(opacity);
        textColor = Colors.blue[800]!.withOpacity(opacity);
        label = 'TN';
      } else if (isTahminiZayifHamilelik) {
        backgroundColor = Colors.grey[300]!.withOpacity(opacity);
        textColor = Colors.grey[700]!.withOpacity(opacity);
        label = 'TZ';
      } else if (isTahminiAdetOncesi) {
        backgroundColor = Colors.orange[100]!.withOpacity(opacity);
        textColor = Colors.orange[800]!.withOpacity(opacity);
        label = 'TÖ';
      }
    } else {
      backgroundColor = Colors.grey[300]!.withOpacity(opacity);
      textColor = Colors.black.withOpacity(opacity);
    }

    return Container(
      margin: EdgeInsets.all(1),
      decoration: BoxDecoration(
        color: backgroundColor,
        shape: BoxShape.circle,
        border: border ?? Border.all(
          color: isSelected ? Colors.pink[700]!.withOpacity(opacity) :
          isToday ? Colors.blue[300]!.withOpacity(opacity) : Colors.transparent,
          width: isSelected ? 2 : isToday ? 1 : 0,
        ),
      ),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              day.day.toString(),
              style: TextStyle(
                color: textColor,
                fontWeight: isToday ? FontWeight.bold : FontWeight.normal,
                fontSize: 12,
              ),
            ),
            if (label != null)
              Text(
                label,
                style: TextStyle(
                  color: textColor,
                  fontSize: 8,
                  fontWeight: FontWeight.bold,
                ),
              ),
          ],
        ),
      ),
    );
  }  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: Text(
          'Regl Takibi',
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.w600,
            fontSize: 18,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 1,
        iconTheme: IconThemeData(color: Colors.black),
        actions: [
          IconButton(
            icon: Icon(Icons.timer),
            onPressed: _showSureAyari,
            tooltip: 'Varsayılan Süre Ayarı',
          ),
          IconButton(
            icon: Icon(Icons.pregnant_woman_outlined),
            onPressed: _showFertilityInfo,
            tooltip: 'Doğurganlık Bilgileri',
          ),
        ],
      ),
      body: _isLoading
          ? _buildLoadingWidget()
          : _errorMessage.isNotEmpty
          ? _buildErrorWidget()
          : Column(
        children: [
          // Takvim
          Expanded(
            flex: 2,
            child: _buildTakvimVeRenkAciklamalari(),
          ),

          // Gün bilgisi
          if (_infoGun != null && _selectedDayInfo != null)
            _buildGunBilgisi(),

          // Adet listesi
          Expanded(
            flex: 1,
            child: _buildAdetListesi(),
          ),
        ],
      ),
    );
  }

  Widget _buildGunBilgisi() {
    return Container(
      padding: EdgeInsets.all(12),
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 8,
            offset: Offset(0, 2),
          ),
        ],
        border: Border.all(color: _selectedDayInfo!.renk.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: _selectedDayInfo!.renk,
              shape: BoxShape.circle,
            ),
            child: Icon(_selectedDayInfo!.icon, color: Colors.white, size: 20),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  DateFormat('dd MMMM yyyy', 'tr_TR').format(_infoGun!),
                  style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                ),
                SizedBox(height: 2),
                Text(
                  _selectedDayInfo!.durum,
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: _selectedDayInfo!.renk),
                ),
                SizedBox(height: 2),
                Text(
                  _selectedDayInfo!.aciklama,
                  style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                ),
              ],
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: _selectedDayInfo!.renk.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              _selectedDayInfo!.yuzde,
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: _selectedDayInfo!.renk),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTakvimVeRenkAciklamalari() {
    return SingleChildScrollView(
      child: Column(
        children: [
          _buildTakvim(),
          _buildRenkAciklamalari(),
        ],
      ),
    );
  }

  Widget _buildIstatistikKartlari() {
    return Container(
      margin: EdgeInsets.all(16),
      child: Row(
        children: [
          Expanded(
            child: _buildIstatistikKart(
              icon: Icons.cyclone,
              title: 'Döngü',
              value: '$ortalamaDongu gün',
              renk: Colors.pink[700]!,
            ),
          ),
          SizedBox(width: 8),
          Expanded(
            child: _buildIstatistikKart(
              icon: Icons.schedule,
              title: 'Süre',
              value: '$ortalamaSure gün',
              renk: Colors.purple[700]!,
            ),
          ),
          SizedBox(width: 8),
          Expanded(
            child: _buildIstatistikKart(
              icon: Icons.calendar_today,
              title: 'Tahmini',
              value: tahminiSonrakiTarih != null
                  ? DateFormat('dd/MM').format(tahminiSonrakiTarih!)
                  : '---',
              renk: Colors.blue[700]!,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildIstatistikKart({
    required IconData icon,
    required String title,
    required String value,
    required Color renk,
  }) {
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 6,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Icon(icon, color: renk, size: 18),
          SizedBox(height: 6),
          Text(
            title,
            style: TextStyle(fontSize: 10, color: Colors.grey[600], fontWeight: FontWeight.w500),
          ),
          SizedBox(height: 2),
          Text(
            value,
            style: TextStyle(fontSize: 12, color: renk, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }

  Widget _buildTakvim() {
    return Container(
      margin: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 12,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: TableCalendar(
        locale: 'tr_TR',
        firstDay: DateTime.now().subtract(Duration(days: 365)),
        lastDay: DateTime.now().add(Duration(days: 365)),
        focusedDay: _focusedDay,
        calendarFormat: CalendarFormat.month,
        availableCalendarFormats: const {CalendarFormat.month: 'Ay'},
        selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
        onDaySelected: _onDaySelected,
        onPageChanged: (focusedDay) {
          setState(() {
            _focusedDay = focusedDay;
          });
        },
        calendarStyle: CalendarStyle(
          defaultDecoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.transparent,
          ),
          todayDecoration: BoxDecoration(
            color: Colors.transparent,
            shape: BoxShape.circle,
            border: Border.all(color: Colors.white, width: 1),
          ),
          selectedDecoration: BoxDecoration(
            color: Colors.transparent,
            shape: BoxShape.circle,
            border: Border.all(color: Colors.pink[100]!, width: 1),
          ),
          weekendDecoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.transparent,
          ),
          // ÖNEMLİ: Dış günlerin (diğer ayların günleri) stilini değiştir
          outsideDecoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.transparent,
          ),
          defaultTextStyle: TextStyle(fontSize: 14, color: Colors.black),
          weekendTextStyle: TextStyle(color: Colors.red[400]),
          // ÖNEMLİ: Dış günlerin metin stilini değiştir
          outsideTextStyle: TextStyle(fontSize: 14, color: Colors.grey[600]),
          todayTextStyle: TextStyle(
              fontSize: 14,
              color: Colors.black,
              fontWeight: FontWeight.bold
          ),
          selectedTextStyle: TextStyle(
              fontSize: 14,
              color: Colors.black,
              fontWeight: FontWeight.bold
          ),
          cellPadding: EdgeInsets.all(2),
        ),
        headerStyle: HeaderStyle(
          formatButtonVisible: false,
          titleCentered: true,
          titleTextStyle: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: Colors.pink[700]),
          leftChevronIcon: Icon(Icons.chevron_left, color: Colors.pink[700]),
          rightChevronIcon: Icon(Icons.chevron_right, color: Colors.pink[700]),
        ),
        daysOfWeekStyle: DaysOfWeekStyle(
          weekdayStyle: TextStyle(fontWeight: FontWeight.w600, color: Colors.grey[700]),
          weekendStyle: TextStyle(fontWeight: FontWeight.w600, color: Colors.red[400]),
        ),
        calendarBuilders: CalendarBuilders(
          // ÖNEMLİ: Tüm gün tipleri için aynı builder'ı kullan
          defaultBuilder: (context, day, focusedDay) {
            return _buildCalendarDay(day, focusedDay);
          },
          todayBuilder: (context, day, focusedDay) {
            return _buildCalendarDay(day, focusedDay);
          },
          selectedBuilder: (context, day, focusedDay) {
            return _buildCalendarDay(day, focusedDay);
          },
          // ÖNEMLİ: Dış günler (diğer ayların günleri) için de aynı builder'ı kullan
          outsideBuilder: (context, day, focusedDay) {
            return _buildCalendarDay(day, focusedDay);
          },
          // ÖNEMLİ: Haftanın ilk günü için de aynı builder'ı kullan
          headerTitleBuilder: (context, day) {
            return Container(
              padding: EdgeInsets.all(8.0),
              child: Text(
                DateFormat('MMMM yyyy', 'tr_TR').format(day),
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
              ),
            );
          },
        ),
      ),
    );
  }
  Widget _buildRenkAciklamalari() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 6,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Wrap(
        spacing: 12,
        runSpacing: 6,
        children: [
          _buildRenkAciklama(Colors.red[400]!, 'Adet', '%0-5'),
          _buildRenkAciklama(Colors.pink[100]!, 'Tahmini Adet', '%0-5'),
          _buildRenkAciklama(Colors.purple[400]!, 'Yüksek', '%25-30'),
          _buildRenkAciklama(Colors.purple[100]!, 'Tahmini Yüksek', '%25-30'),
          _buildRenkAciklama(Colors.blue[400]!, 'Normal', '%15-20'),
          _buildRenkAciklama(Colors.blue[100]!, 'Tahmini Normal', '%15-20'),
          _buildRenkAciklama(Colors.grey[400]!, 'Zayıf', '%5-10'),
          _buildRenkAciklama(Colors.grey[200]!, 'Tahmini Zayıf', '%5-10'),
          _buildRenkAciklama(Colors.orange[400]!, 'Adet Öncesi', '%5-10'),
          _buildRenkAciklama(Colors.orange[100]!, 'Tahmini Öncesi', '%5-10'),
          _buildRenkAciklama(Colors.grey[300]!, 'Normal Dönem', '%5-10'),
        ],
      ),
    );
  }

  Widget _buildRenkAciklama(Color renk, String text, String yuzde) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(
            color: renk,
            shape: BoxShape.circle,
          ),
        ),
        SizedBox(width: 4),
        Text(
          text,
          style: TextStyle(fontSize: 10, color: Colors.grey[600]),
        ),
        SizedBox(width: 2),
        Text(
          yuzde,
          style: TextStyle(fontSize: 9, color: Colors.grey[500], fontWeight: FontWeight.w500),
        ),
      ],
    );
  }

  Widget _buildAdetListesi() {
    return Container(
      margin: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20),
          topRight: Radius.circular(20),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 12,
            offset: Offset(0, -4),
          ),
        ],
      ),
      child: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(16),
            child: Row(
              children: [
                Text(
                  'Geçmiş Dönemler',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: Colors.grey[800]),
                ),
                Spacer(),
                Text(
                  '${adetDonemleri.length} kayıt',
                  style: TextStyle(fontSize: 12, color: Colors.grey[500]),
                ),
              ],
            ),
          ),
          Expanded(
            child: adetDonemleri.isEmpty
                ? _buildEmptyWidget()
                : ListView.builder(
              padding: EdgeInsets.symmetric(horizontal: 16),
              itemCount: adetDonemleri.length,
              itemBuilder: (context, index) {
                final donem = adetDonemleri[index];
                return _buildAdetDonemiKarti(donem);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAdetDonemiKarti(AdetDonemi donem) {
    final dateFormat = DateFormat('dd.MM.yyyy');

    return Container(
      margin: EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[200]!),
      ),
      child: ListTile(
        leading: Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            color: donem.renk,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(Icons.cyclone, color: Colors.white, size: 18),
        ),
        title: Text(
          '${dateFormat.format(donem.baslangicTarihi)} - ${dateFormat.format(donem.bitisTarihi)}',
          style: TextStyle(fontWeight: FontWeight.w600, color: Colors.grey[800], fontSize: 14),
        ),
        subtitle: Text(
          '${donem.sure} gün • Döngü: ${donem.dongu} gün${donem.belirtiler.isNotEmpty ? ' • ${donem.belirtiler.length} belirti' : ''}',
          style: TextStyle(color: Colors.grey[600], fontSize: 12),
        ),
        trailing: Icon(Icons.chevron_right, color: Colors.grey[400], size: 20),
        onTap: () => _adetDonemiDetay(donem),
      ),
    );
  }

  Widget _buildLoadingWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Colors.pink[700]!)),
          SizedBox(height: 16),
          Text('Adet dönemleri yükleniyor...', style: TextStyle(color: Colors.grey[600])),
        ],
      ),
    );
  }

  Widget _buildErrorWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.error_outline, size: 60, color: Colors.red[300]),
          SizedBox(height: 16),
          Text('Hata Oluştu', style: TextStyle(color: Colors.grey[800], fontSize: 16, fontWeight: FontWeight.w600)),
          SizedBox(height: 8),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 32),
            child: Text(_errorMessage, textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[600], fontSize: 12)),
          ),
          SizedBox(height: 16),
          ElevatedButton(
            onPressed: _adetDonemleriniGetir,
            style: ElevatedButton.styleFrom(backgroundColor: Colors.pink[700], foregroundColor: Colors.white),
            child: Text('Tekrar Dene'),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.cyclone, size: 60, color: Colors.grey[300]),
          SizedBox(height: 5),
          Text(
            'Henüz adet dönemi eklenmemiş',
            style: TextStyle(color: Colors.grey[500], fontSize: 14),
          ),
          SizedBox(height: 2),
          Text(
            'Takvimde renksiz (boş) bir güne tıklayarak dönem ekleyin',
            style: TextStyle(color: Colors.grey[400], fontSize: 12),
            textAlign: TextAlign.center,
          ),


        ],
      ),
    );
  }

  void _adetDonemiDetay(AdetDonemi donem) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => AdetDonemiDetayBottomSheet(
        donem: donem,
        onAdetDonemiGuncellendi: _adetDonemleriniGetir,
        userId: widget.md.id.toString(),
      ),
    );
  }
}

class FertilityInfoDialog extends StatelessWidget {
  final List<DateTime> adetGunleri;
  final List<DateTime> zayifHamilelikGunleri;
  final List<DateTime> normalHamilelikGunleri;
  final List<DateTime> yuksekHamilelikGunleri;
  final List<DateTime> adetOncesiGunleri;
  final List<DateTime> tahminiAdetGunleri;
  final List<DateTime> tahminiAdetOncesiGunleri;
  final List<DateTime> tahminiZayifHamilelikGunleri;
  final List<DateTime> tahminiNormalHamilelikGunleri;
  final List<DateTime> tahminiYuksekHamilelikGunleri;

  const FertilityInfoDialog({
    Key? key,
    required this.adetGunleri,
    required this.zayifHamilelikGunleri,
    required this.normalHamilelikGunleri,
    required this.yuksekHamilelikGunleri,
    required this.adetOncesiGunleri,
    required this.tahminiAdetGunleri,
    required this.tahminiAdetOncesiGunleri,
    required this.tahminiZayifHamilelikGunleri,
    required this.tahminiNormalHamilelikGunleri,
    required this.tahminiYuksekHamilelikGunleri,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      insetPadding: EdgeInsets.all(20),
      backgroundColor: Colors.white,
      child: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.pregnant_woman, color: Colors.pink[700], size: 24),
                SizedBox(width: 8),
                Text(
                  'Hamilelik İhtimalleri',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.pink[700]),
                ),
              ],
            ),
            SizedBox(height: 16),

            _buildInfoItem(
                'Adet Dönemi',
                '${adetGunleri.length} gün',
                Colors.red[400]!,
                Icons.bloodtype,
                '%0-5 - Hamile kalma ihtimali çok düşük'
            ),
            SizedBox(height: 8),

            _buildInfoItem(
                'Tahmini Adet',
                '${tahminiAdetGunleri.length} gün',
                Colors.pink[100]!,
                Icons.calendar_today,
                '%0-5 - Adet dönemi başlayabilir'
            ),
            SizedBox(height: 8),

            _buildInfoItem(
                'Yüksek Hamilelik',
                '${yuksekHamilelikGunleri.length} gün',
                Colors.purple[400]!,
                Icons.arrow_upward,
                '%25-30 - Hamile kalma ihtimali en yüksek'
            ),
            SizedBox(height: 8),

            _buildInfoItem(
                'Tahmini Yüksek Hamilelik',
                '${tahminiYuksekHamilelikGunleri.length} gün',
                Colors.purple[100]!,
                Icons.arrow_upward,
                '%25-30 - Hamile kalma ihtimali en yüksek (tahmini)'
            ),
            SizedBox(height: 8),

            _buildInfoItem(
                'Normal Hamilelik',
                '${normalHamilelikGunleri.length} gün',
                Colors.blue[400]!,
                Icons.trending_up,
                '%15-20 - Hamile kalma ihtimali orta'
            ),
            SizedBox(height: 8),

            _buildInfoItem(
                'Tahmini Normal Hamilelik',
                '${tahminiNormalHamilelikGunleri.length} gün',
                Colors.blue[100]!,
                Icons.trending_up,
                '%15-20 - Hamile kalma ihtimali orta (tahmini)'
            ),
            SizedBox(height: 8),

            _buildInfoItem(
                'Zayıf Hamilelik',
                '${zayifHamilelikGunleri.length} gün',
                Colors.grey[400]!,
                Icons.arrow_downward,
                '%5-10 - Hamile kalma ihtimali düşük'
            ),
            SizedBox(height: 8),

            _buildInfoItem(
                'Tahmini Zayıf Hamilelik',
                '${tahminiZayifHamilelikGunleri.length} gün',
                Colors.grey[200]!,
                Icons.arrow_downward,
                '%5-10 - Hamile kalma ihtimali düşük (tahmini)'
            ),
            SizedBox(height: 8),

            _buildInfoItem(
                'Adet Öncesi',
                '${adetOncesiGunleri.length} gün',
                Colors.orange[400]!,
                Icons.warning,
                '%5-10 - PMS dönemi'
            ),

            SizedBox(height: 8),

            _buildInfoItem(
                'Tahmini Adet Öncesi',
                '${tahminiAdetOncesiGunleri.length} gün',
                Colors.orange[100]!,
                Icons.warning,
                '%5-10 - Tahmini PMS dönemi'
            ),

            SizedBox(height: 8),

            _buildInfoItem(
                'Normal Dönem',
                'Gri renkli günler',
                Colors.grey[300]!,
                Icons.horizontal_rule,
                '%5-10 - Hamile kalma ihtimali düşük'
            ),

            SizedBox(height: 16),
            Center(
              child: ElevatedButton(
                onPressed: () => Navigator.of(context).pop(),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.pink[700],
                  foregroundColor: Colors.white,
                ),
                child: Text('Tamam'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoItem(String title, String value, Color color, IconData icon, String aciklama) {
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 20),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(fontWeight: FontWeight.w600, color: color),
                ),
                SizedBox(height: 4),
                Text(
                  aciklama,
                  style: TextStyle(fontSize: 10, color: Colors.grey[600]),
                ),
              ],
            ),
          ),
          Text(
            value,
            style: TextStyle(fontWeight: FontWeight.w600, color: color),
          ),
        ],
      ),
    );
  }
}

class BelirtiSecimDialog extends StatefulWidget {
  final DateTime baslangicTarihi;
  final int defaultSure;
  final Function(AdetDonemi) onAdetDonemiEklendi;
  final String userId;
  final AdetDonemi? oncekiDonem;
  final dynamic isletmebilgi;

  const BelirtiSecimDialog({
    Key? key,
    required this.baslangicTarihi,
    required this.defaultSure,
    required this.onAdetDonemiEklendi,
    required this.userId,
    this.oncekiDonem,
    required this.isletmebilgi,
  }) : super(key: key);

  @override
  State<BelirtiSecimDialog> createState() => _BelirtiSecimDialogState();
}

class _BelirtiSecimDialogState extends State<BelirtiSecimDialog> {
  final List<String> _seciliBelirtiler = [];
  final TextEditingController _notController = TextEditingController();
  bool _isLoading = false;

  final List<String> _belirtiListesi = [
    'Karın ağrısı',
    'Baş ağrısı',
    'Sırt ağrısı',
    'Yorgunluk',
    'Mide bulantısı',
    'İştah artışı',
    'Duygu durum değişiklikleri',
    'Şişkinlik',
    'Akne',
    'Göğüs hassasiyeti',
    'Uyku hali',
    'Eklem ağrısı',
    'Baş dönmesi',
    'Sıcak basması',
    'Kas ağrısı'
  ];

  int? _dongu;

  @override
  void initState() {
    super.initState();
    _donguHesapla();
  }

  void _donguHesapla() {
    if (widget.oncekiDonem != null) {
      final oncekiBaslangic = widget.oncekiDonem!.baslangicTarihi;
      final simdikiBaslangic = widget.baslangicTarihi;
      final hesaplananDongu = simdikiBaslangic.difference(oncekiBaslangic).inDays;
      if (hesaplananDongu > 0) {
        setState(() {
          _dongu = hesaplananDongu;
        });
      }
    }
  }

  Future<void> _adetDonemiKaydet() async {
    if (_isLoading) return;

    setState(() {
      _isLoading = true;
    });

    try {
      final dateFormat = DateFormat('yyyy-MM-dd');
      final dongu = _dongu ?? 0;
      final bitisTarihi = widget.baslangicTarihi.add(Duration(days: widget.defaultSure - 1));

      final result = await adetekle(
        dateFormat.format(widget.baslangicTarihi),
        dateFormat.format(bitisTarihi),
        dongu.toString(),
        widget.userId,
        _notController.text,
        widget.defaultSure.toString(),
        _seciliBelirtiler,
        widget.isletmebilgi['id'].toString()

      );

      if (result['success'] == true) {
        Navigator.of(context).pop();

        widget.onAdetDonemiEklendi(AdetDonemi(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          baslangicTarihi: widget.baslangicTarihi,
          bitisTarihi: bitisTarihi,
          sure: widget.defaultSure,
          dongu: dongu,
          belirtiler: _seciliBelirtiler,
          not: _notController.text,
          renk: _getRandomRenk(),
        ));

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${widget.defaultSure} günlük adet dönemi başarıyla eklendi${_seciliBelirtiler.isNotEmpty ? ' (${_seciliBelirtiler.length} belirti)' : ''}'),
            backgroundColor: Colors.green[700],
            duration: Duration(seconds: 3),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Hata: ${result['message']}'),
            backgroundColor: Colors.red[700],
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Adet dönemi eklenirken hata oluştu: $e'),
          backgroundColor: Colors.red[700],
        ),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Color _getRandomRenk() {
    final colors = [Colors.pink[700]!, Colors.purple[700]!, Colors.deepPurple[700]!, Colors.red[700]!, Colors.orange[700]!];
    return colors[DateTime.now().millisecond % colors.length];
  }

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('dd.MM.yyyy');
    final bitisTarihi = widget.baslangicTarihi.add(Duration(days: widget.defaultSure - 1));

    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      insetPadding: EdgeInsets.all(20),
      child: Container(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.8),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Header
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.pink[700],
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                ),
              ),
              child: Row(
                children: [
                  Icon(Icons.medical_services, color: Colors.white, size: 24),
                  SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Belirti ve Not Ekle',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          '${dateFormat.format(widget.baslangicTarihi)} - ${dateFormat.format(bitisTarihi)}',
                          style: TextStyle(color: Colors.white.withOpacity(0.9), fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            // Content
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Belirtiler
                    Text(
                      'Belirtiler (İsteğe Bağlı)',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.grey[800],
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Bu adet döneminde yaşadığınız belirtileri seçin:',
                      style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                    ),
                    SizedBox(height: 12),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: _belirtiListesi.map((belirti) {
                        final isSelected = _seciliBelirtiler.contains(belirti);
                        return FilterChip(
                          label: Text(belirti),
                          selected: isSelected,
                          onSelected: (selected) {
                            setState(() {
                              if (selected) {
                                _seciliBelirtiler.add(belirti);
                              } else {
                                _seciliBelirtiler.remove(belirti);
                              }
                            });
                          },
                          selectedColor: Colors.pink[50],
                          checkmarkColor: Colors.pink[700],
                          labelStyle: TextStyle(
                            color: isSelected ? Colors.pink[700] : Colors.grey[700],
                            fontSize: 12,
                          ),
                        );
                      }).toList(),
                    ),
                    SizedBox(height: 20),

                    // Not
                    Text(
                      'Not (İsteğe Bağlı)',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.grey[800],
                      ),
                    ),
                    SizedBox(height: 8),
                    TextFormField(
                      controller: _notController,
                      maxLines: 3,
                      decoration: InputDecoration(
                        hintText: 'Bu adet dönemi hakkında notlarınız...',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: Colors.grey[600]!),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: Colors.pink[700]!),
                        ),
                      ),
                    ),
                    SizedBox(height: 16),

                    // Bilgiler
                    Container(
                      padding: EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.blue[50],
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Özet:',
                            style: TextStyle(fontWeight: FontWeight.w600, color: Colors.blue[800]),
                          ),
                          SizedBox(height: 4),
                          Text('• ${widget.defaultSure} günlük adet dönemi'),
                          if (_dongu != null && _dongu! > 0)
                            Text('• Döngü süresi: $_dongu gün'),
                          Text('• ${_seciliBelirtiler.length} belirti seçildi'),
                          if (_notController.text.isNotEmpty)
                            Text('• Not eklendi'),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // Butonlar
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.grey[50],
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(20),
                  bottomRight: Radius.circular(20),
                ),
                border: Border(top: BorderSide(color: Colors.grey[600]!)),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: _isLoading ? null : () => Navigator.of(context).pop(),
                      child: Text(
                        'İptal',
                        style: TextStyle(color: Colors.grey[600]),
                      ),
                    ),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _isLoading ? null : _adetDonemiKaydet,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.pink[700],
                        foregroundColor: Colors.white,
                      ),
                      child: _isLoading
                          ? SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                          : Text('Kaydet'),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class FertilityInfo {
  final String durum;
  final String aciklama;
  final Color renk;
  final IconData icon;
  final String yuzde;
  final String risk;

  FertilityInfo({
    required this.durum,
    required this.aciklama,
    required this.renk,
    required this.icon,
    required this.yuzde,
    required this.risk,
  });
}

class AdetGunuInfoBottomSheet extends StatelessWidget {
  final DateTime gun;
  final AdetDonemi adetDonemi;
  final FertilityInfo fertilityInfo;

  const AdetGunuInfoBottomSheet({
    Key? key,
    required this.gun,
    required this.adetDonemi,
    required this.fertilityInfo,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('dd MMMM yyyy', 'tr_TR');

    return Container(
      height: MediaQuery.of(context).size.height * 0.6,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
      ),
      child: Column(
        children: [
          // Header
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: fertilityInfo.renk,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(24),
                topRight: Radius.circular(24),
              ),
            ),
            child: Row(
              children: [
                Icon(fertilityInfo.icon, color: Colors.white, size: 24),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        dateFormat.format(gun),
                        style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600),
                      ),
                      Text(
                        fertilityInfo.durum,
                        style: TextStyle(color: Colors.white, fontSize: 14),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.of(context).pop(),
                  icon: Icon(Icons.close, color: Colors.white),
                ),
              ],
            ),
          ),
          // Content
          Expanded(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                children: [
                  // Doğurganlık Bilgisi
                  Container(
                    padding: EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: fertilityInfo.renk.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: fertilityInfo.renk.withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.pregnant_woman, color: fertilityInfo.renk, size: 24),
                        SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Hamile Kalma İhtimali',
                                style: TextStyle(fontWeight: FontWeight.w600, color: fertilityInfo.renk),
                              ),
                              SizedBox(height: 4),
                              Text(
                                fertilityInfo.aciklama,
                                style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: fertilityInfo.renk,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            fertilityInfo.yuzde,
                            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 20),

                  // Adet Dönemi Bilgisi
                  Container(
                    padding: EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.grey[50],
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Adet Dönemi Bilgisi',
                          style: TextStyle(fontWeight: FontWeight.w600, color: Colors.grey[600]),
                        ),
                        SizedBox(height: 8),
                        Row(
                          children: [
                            Icon(Icons.calendar_today, color: Colors.pink[700], size: 16),
                            SizedBox(width: 8),
                            Text('Başlangıç: ${DateFormat('dd.MM.yyyy').format(adetDonemi.baslangicTarihi)}'),
                          ],
                        ),
                        SizedBox(height: 4),
                        Row(
                          children: [
                            Icon(Icons.event_available, color: Colors.pink[700], size: 16),
                            SizedBox(width: 8),
                            Text('Bitiş: ${DateFormat('dd.MM.yyyy').format(adetDonemi.bitisTarihi)}'),
                          ],
                        ),
                        SizedBox(height: 4),
                        Row(
                          children: [
                            Icon(Icons.schedule, color: Colors.pink[700], size: 16),
                            SizedBox(width: 8),
                            Text('Süre: ${adetDonemi.sure} gün'),
                          ],
                        ),
                        if (adetDonemi.belirtiler.isNotEmpty) ...[
                          SizedBox(height: 4),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Icon(Icons.medical_services, color: Colors.pink[700], size: 16),
                              SizedBox(width: 8),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Belirtiler:'),
                                    SizedBox(height: 4),
                                    Wrap(
                                      spacing: 4,
                                      runSpacing: 2,
                                      children: adetDonemi.belirtiler.map((belirti) {
                                        return Container(
                                          padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                          decoration: BoxDecoration(
                                            color: Colors.pink[50],
                                            borderRadius: BorderRadius.circular(4),
                                          ),
                                          child: Text(
                                            belirti,
                                            style: TextStyle(fontSize: 10, color: Colors.pink[700]),
                                          ),
                                        );
                                      }).toList(),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ],
                    ),
                  ),
                  SizedBox(height: 20),


                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class SureAyariDialog extends StatefulWidget {
  final int mevcutSure;
  final Function(int) onSureDegisti;

  const SureAyariDialog({
    Key? key,
    required this.mevcutSure,
    required this.onSureDegisti,
  }) : super(key: key);

  @override
  State<SureAyariDialog> createState() => _SureAyariDialogState();
}

class _SureAyariDialogState extends State<SureAyariDialog> {
  late int _sure;

  @override
  void initState() {
    super.initState();
    _sure = widget.mevcutSure;
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Varsayılan Adet Süresi',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.pink[700]),
            ),
            SizedBox(height: 16),
            Text(
              'Takvimde boş bir güne tıkladığınızda otomatik olarak kaç günlük adet dönemi oluşturulsun?',
              style: TextStyle(fontSize: 14, color: Colors.grey[600]),
            ),
            SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: Slider(
                    value: _sure.toDouble(),
                    min: 1,
                    max: 10,
                    divisions: 9,
                    label: '$_sure gün',
                    onChanged: (value) {
                      setState(() {
                        _sure = value.toInt();
                      });
                    },
                    activeColor: Colors.pink[700],
                    inactiveColor: Colors.grey[600],
                  ),
                ),
                SizedBox(width: 16),
                Container(
                  width: 60,
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.pink[700],
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    '$_sure gün',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
            SizedBox(height: 8),
            Text(
              'Genellikle adet süresi 3-7 gün arasındadır',
              style: TextStyle(fontSize: 12, color: Colors.grey[600]),
            ),
            SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: TextButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: Text('İptal', style: TextStyle(color: Colors.grey[600])),
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      widget.onSureDegisti(_sure);
                      Navigator.of(context).pop();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.pink[700],
                      foregroundColor: Colors.white,
                    ),
                    child: Text('Kaydet'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class AdetDonemiDetayBottomSheet extends StatefulWidget {
  final AdetDonemi donem;
  final Function() onAdetDonemiGuncellendi;
  final String userId;

  const AdetDonemiDetayBottomSheet({
    Key? key,
    required this.donem,
    required this.onAdetDonemiGuncellendi,
    required this.userId,
  }) : super(key: key);

  @override
  State<AdetDonemiDetayBottomSheet> createState() => _AdetDonemiDetayBottomSheetState();
}

class _AdetDonemiDetayBottomSheetState extends State<AdetDonemiDetayBottomSheet> {
  bool _isEditing = false;
  bool _isLoading = false;

  // Düzenleme için controller'lar
  late TextEditingController _baslangicController;
  late TextEditingController _bitisController;
  late TextEditingController _sureController;
  late TextEditingController _donguController;
  late TextEditingController _notController;
  late List<String> _belirtiler;

  @override
  void initState() {
    super.initState();
    _baslangicController = TextEditingController(text: DateFormat('yyyy-MM-dd').format(widget.donem.baslangicTarihi));
    _bitisController = TextEditingController(text: DateFormat('yyyy-MM-dd').format(widget.donem.bitisTarihi));
    _sureController = TextEditingController(text: widget.donem.sure.toString());
    _donguController = TextEditingController(text: widget.donem.dongu.toString());
    _notController = TextEditingController(text: widget.donem.not);
    _belirtiler = List.from(widget.donem.belirtiler);
  }

  @override
  void dispose() {
    _baslangicController.dispose();
    _bitisController.dispose();
    _sureController.dispose();
    _donguController.dispose();
    _notController.dispose();
    super.dispose();
  }

  // Başlangıç tarihi değiştiğinde bitiş tarihini otomatik güncelle
  void _updateBitisTarihi() {
    try {
      final baslangicTarihi = DateTime.parse(_baslangicController.text);
      final sure = int.tryParse(_sureController.text) ?? widget.donem.sure;
      final yeniBitisTarihi = baslangicTarihi.add(Duration(days: sure - 1));
      _bitisController.text = DateFormat('yyyy-MM-dd').format(yeniBitisTarihi);
    } catch (e) {
      print('Tarih güncelleme hatası: $e');
    }
  }

  // Süre değiştiğinde bitiş tarihini otomatik güncelle
  void _updateBitisTarihiFromSure() {
    try {
      final baslangicTarihi = DateTime.parse(_baslangicController.text);
      final sure = int.tryParse(_sureController.text) ?? widget.donem.sure;
      final yeniBitisTarihi = baslangicTarihi.add(Duration(days: sure - 1));
      _bitisController.text = DateFormat('yyyy-MM-dd').format(yeniBitisTarihi);
    } catch (e) {
      print('Süre güncelleme hatası: $e');
    }
  }

  Future<void> _guncelleAdetDonemi() async {
    if (_isLoading) return;

    setState(() {
      _isLoading = true;
    });

    try {
      final result = await adetguncelle(
        _baslangicController.text,
        _bitisController.text,
        _donguController.text,
        widget.donem.id,
        _notController.text,
        _sureController.text,
        _belirtiler,
      );

      if (result['success'] == true) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Adet dönemi başarıyla güncellendi'),
            backgroundColor: Colors.green[700],
            duration: Duration(seconds: 2),
          ),
        );

        // Ana sayfayı güncelle
        widget.onAdetDonemiGuncellendi();

        // Bottom sheet'i kapat
        Navigator.of(context).pop();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Hata: ${result['message']}'),
            backgroundColor: Colors.red[700],
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Adet dönemi güncellenirken hata oluştu: $e'),
          backgroundColor: Colors.red[700],
        ),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }
  void _toggleBelirti(String belirti) {
    setState(() {
      if (_belirtiler.contains(belirti)) {
        _belirtiler.remove(belirti);
      } else {
        _belirtiler.add(belirti);
      }
    });
  }

  Future<void> _selectDate(TextEditingController controller, {Function? onDateSelected}) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.parse(controller.text),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      controller.text = DateFormat('yyyy-MM-dd').format(picked);
      if (onDateSelected != null) onDateSelected();
    }
  }

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('dd.MM.yyyy');
    final belirtiListesi = [
      'Karın ağrısı', 'Baş ağrısı', 'Sırt ağrısı', 'Yorgunluk', 'Mide bulantısı',
      'İştah artışı', 'Duygu durum değişiklikleri', 'Şişkinlik', 'Akne', 'Göğüs hassasiyeti',
      'Uyku hali', 'Eklem ağrısı', 'Baş dönmesi', 'Sıcak basması', 'Kas ağrısı'
    ];

    return Container(
      height: MediaQuery.of(context).size.height * 0.8,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
      ),
      child: Column(
        children: [
          // Header
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: widget.donem.renk,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(24),
                topRight: Radius.circular(24),
              ),
            ),
            child: Row(
              children: [
                Icon(Icons.cyclone, color: Colors.white, size: 24),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _isEditing ? 'Adet Dönemi Düzenle' : 'Adet Dönemi Detayı',
                        style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600),
                      ),
                      Text(
                        '${dateFormat.format(widget.donem.baslangicTarihi)} - ${dateFormat.format(widget.donem.bitisTarihi)}',
                        style: TextStyle(color: Colors.white.withOpacity(0.9), fontSize: 14),
                      ),
                    ],
                  ),
                ),
                if (!_isEditing)
                  IconButton(
                    onPressed: () {
                      setState(() {
                        _isEditing = true;
                      });
                    },
                    icon: Icon(Icons.edit, color: Colors.white),
                    tooltip: 'Düzenle',
                  ),
                IconButton(
                  onPressed: () => Navigator.of(context).pop(),
                  icon: Icon(Icons.close, color: Colors.white),
                ),
              ],
            ),
          ),

          // Content
          Expanded(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: SingleChildScrollView(
                child: _isEditing ? _buildEditForm(belirtiListesi) : _buildDetailView(),
              ),
            ),
          ),

          // Butonlar (sadece edit modunda)
          if (_isEditing)
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.grey[50],
                border: Border(top: BorderSide(color: Colors.grey[300]!)),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: _isLoading ? null : () {
                        setState(() {
                          _isEditing = false;
                          // Değerleri sıfırla
                          _baslangicController.text = DateFormat('yyyy-MM-dd').format(widget.donem.baslangicTarihi);
                          _bitisController.text = DateFormat('yyyy-MM-dd').format(widget.donem.bitisTarihi);
                          _sureController.text = widget.donem.sure.toString();
                          _donguController.text = widget.donem.dongu.toString();
                          _notController.text = widget.donem.not;
                          _belirtiler = List.from(widget.donem.belirtiler);
                        });
                      },
                      child: Text('İptal', style: TextStyle(color: Colors.grey[600])),
                    ),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _isLoading ? null : _guncelleAdetDonemi,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.pink[700],
                        foregroundColor: Colors.white,
                      ),
                      child: _isLoading
                          ? SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                          : Text('Kaydet'),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildDetailView() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Temel Bilgiler
        _buildInfoCard(
          title: 'Temel Bilgiler',
          children: [
            _buildInfoRow('Başlangıç Tarihi', DateFormat('dd.MM.yyyy').format(widget.donem.baslangicTarihi)),
            _buildInfoRow('Bitiş Tarihi', DateFormat('dd.MM.yyyy').format(widget.donem.bitisTarihi)),
            _buildInfoRow('Süre', '${widget.donem.sure} gün'),
            _buildInfoRow('Döngü Uzunluğu', '${widget.donem.dongu} gün'),
          ],
        ),

        SizedBox(height: 16),

        // Belirtiler
        if (widget.donem.belirtiler.isNotEmpty)
          _buildInfoCard(
            title: 'Belirtiler (${widget.donem.belirtiler.length})',
            children: [
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: widget.donem.belirtiler.map((belirti) {
                  return Chip(
                    label: Text(belirti),
                    backgroundColor: widget.donem.renk.withOpacity(0.1),
                    labelStyle: TextStyle(color: widget.donem.renk, fontSize: 12),
                  );
                }).toList(),
              ),
            ],
          ),

        if (widget.donem.belirtiler.isNotEmpty) SizedBox(height: 16),

        // Not
        if (widget.donem.not.isNotEmpty)
          _buildInfoCard(
            title: 'Not',
            children: [
              Text(
                widget.donem.not,
                style: TextStyle(fontSize: 14, color: Colors.grey[700]),
              ),
            ],
          ),
      ],
    );
  }

  Widget _buildEditForm(List<String> belirtiListesi) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Tarih Bilgileri
        _buildInfoCard(
          title: 'Tarih Bilgileri',
          children: [
            // Başlangıç Tarihi
            TextFormField(
              controller: _baslangicController,
              decoration: InputDecoration(
                labelText: 'Başlangıç Tarihi',
                suffixIcon: IconButton(
                  onPressed: () => _selectDate(_baslangicController, onDateSelected: _updateBitisTarihi),
                  icon: Icon(Icons.calendar_today),
                ),
              ),
              readOnly: true,
              onTap: () => _selectDate(_baslangicController, onDateSelected: _updateBitisTarihi),
            ),
            SizedBox(height: 12),

            // Bitiş Tarihi (readonly - otomatik hesaplanacak)
            TextFormField(
              controller: _bitisController,
              decoration: InputDecoration(
                labelText: 'Bitiş Tarihi (Otomatik)',
                suffixIcon: Icon(Icons.lock, color: Colors.grey),
              ),
              readOnly: true,
              style: TextStyle(color: Colors.grey[600]),
            ),
            SizedBox(height: 12),

            // Süre ve Döngü
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _sureController,
                    decoration: InputDecoration(
                      labelText: 'Süre (gün)',
                    ),
                    keyboardType: TextInputType.number,
                    onChanged: (value) {
                      if (value.isNotEmpty) {
                        _updateBitisTarihiFromSure();
                      }
                    },
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: TextFormField(
                    controller: _donguController,
                    decoration: InputDecoration(
                      labelText: 'Döngü (gün)',
                    ),
                    keyboardType: TextInputType.number,
                  ),
                ),
              ],
            ),
            SizedBox(height: 8),
            Container(
              padding: EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.blue[50],
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                '💡 Başlangıç tarihi veya süre değiştiğinde bitiş tarihi otomatik güncellenir',
                style: TextStyle(fontSize: 12, color: Colors.blue[800]),
              ),
            ),
          ],
        ),

        SizedBox(height: 16),

        // Belirtiler
        _buildInfoCard(
          title: 'Belirtiler (${_belirtiler.length})',
          children: [
            Text(
              'Bu adet döneminde yaşadığınız belirtileri seçin:',
              style: TextStyle(fontSize: 12, color: Colors.grey[600]),
            ),
            SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: belirtiListesi.map((belirti) {
                final isSelected = _belirtiler.contains(belirti);
                return FilterChip(
                  label: Text(belirti),
                  selected: isSelected,
                  onSelected: (_) => _toggleBelirti(belirti),
                  selectedColor: Colors.pink[50],
                  checkmarkColor: Colors.pink[700],
                  labelStyle: TextStyle(
                    color: isSelected ? Colors.pink[700] : Colors.grey[700],
                    fontSize: 12,
                  ),
                );
              }).toList(),
            ),
          ],
        ),

        SizedBox(height: 16),

        // Not
        _buildInfoCard(
          title: 'Not',
          children: [
            TextFormField(
              controller: _notController,
              maxLines: 3,
              decoration: InputDecoration(
                hintText: 'Bu adet dönemi hakkında notlarınız...',
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildInfoCard({required String title, required List<Widget> children}) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[200]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Colors.grey[800],
            ),
          ),
          SizedBox(height: 12),
          ...children,
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: TextStyle(fontWeight: FontWeight.w500, color: Colors.grey[600]),
            ),
          ),
          Text(
            value,
            style: TextStyle(fontWeight: FontWeight.w600, color: Colors.grey[800]),
          ),
        ],
      ),
    );
  }
}