import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import '../../../Backend/backend.dart';
import '../../../Models/ilac.dart';
import '../../../Models/musteri_danisanlar.dart';

class IlaclarimPage extends StatefulWidget {
  final dynamic kullanici;
  final MusteriDanisan md;
  final dynamic isletmebilgi;
  const IlaclarimPage({Key? key, this.kullanici, required this.md,required this.isletmebilgi}) : super(key: key);

  @override
  State<IlaclarimPage> createState() => _IlaclarimPageState();
}

class _IlaclarimPageState extends State<IlaclarimPage> {
  List<Ilac> ilaclar = [];
  bool _isLoading = true;
  bool _hasError = false;
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    _loadIlaclar();
  }

  Future<void> _loadIlaclar() async {
    try {
      setState(() {
        _isLoading = true;
        _hasError = false;
      });

      final data = await ilacget(widget.md.id.toString());

      setState(() {
        ilaclar = _parseIlacData(data);
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _hasError = true;
        _errorMessage = e.toString();
      });
    }
  }

  List<Ilac> _parseIlacData(List<dynamic> data) {
    try {
      List<Ilac> parsedIlaclar = [];

      for (var item in data) {
        try {
          final ilac = Ilac.fromJson(item);
          parsedIlaclar.add(ilac);
        } catch (e) {
          print('İlaç parse hatası: $e - Data: $item');
        }
      }

      // YENİ EKLENEN EN ÜSTTE OLACAK ŞEKİLDE TERS ÇEVİR
      // Varsayım: Veritabanından gelen data tarihe göre artan sırada geliyor (eski -> yeni)
      // Biz en yeni eklenenin en üstte görünmesini istiyoruz
      parsedIlaclar.sort((a, b) {
        // Eğer başlangıç tarihi varsa ona göre sırala
        if (a.baslangicTarihi != null && b.baslangicTarihi != null) {
          return b.baslangicTarihi.compareTo(a.baslangicTarihi); // Yeniden eskiye (büyükten küçüğe)
        }
        // Eğer bitiş tarihi varsa ona göre sırala
        if (a.bitisTarihi != null && b.bitisTarihi != null) {
          return b.bitisTarihi.compareTo(a.bitisTarihi); // Yeniden eskiye
        }
        return 0;
      });

      return parsedIlaclar;
    } catch (e) {
      print('İlaç listesi parse hatası: $e');
      return [];
    }
  }

  Widget _buildKlavyeKapatmaWrapper(Widget child) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
      },
      behavior: HitTestBehavior.opaque,
      child: child,
    );
  }

  void _ilacEkle() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => IlacEkleBottomSheet(
        onIlacEklendi: (yeniIlac) async {
          try {
            final result = await ilacekle(
                yeniIlac.adi,
                yeniIlac.gunlukKullanim.toString(),
                yeniIlac.kalanAdet.toString(),
                widget.md.id.toString(),
                yeniIlac.saatler,
                widget.isletmebilgi['id'].toString()
            );

            print('İlaç ekleme sonucu: $result');

            if (result['success'] == true) {
              // YENİ İLAÇ LİSTENİN BAŞINA EKLENSİN
              setState(() {
                ilaclar.insert(0, yeniIlac); // En üste ekle
              });

              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('İlaç başarıyla eklendi'),
                  backgroundColor: Colors.green[700],
                ),
              );
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('İlaç eklenirken hata oluştu: ${result['message']}'),
                  backgroundColor: Colors.red[700],
                ),
              );
            }
          } catch (e) {
            print('İlaç ekleme hatası: $e');
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('İlaç eklenirken beklenmeyen hata: $e'),
                backgroundColor: Colors.red[700],
              ),
            );
          }
        },
      ),
    );
  }

  void _ilacSil(String ilacId) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'İlaç Sil',
          style: TextStyle(color: Colors.red[700]),
        ),
        content: Text('Bu ilacı silmek istediğinizden emin misiniz?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(
              'İptal',
              style: TextStyle(color: Colors.grey[700]),
            ),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                ilaclar.removeWhere((ilac) => ilac.id == ilacId);
              });
              Navigator.of(context).pop();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('İlaç başarıyla silindi'),
                  backgroundColor: Colors.red[700],
                ),
              );
            },
            child: Text(
              'Sil',
              style: TextStyle(color: Colors.red[700]),
            ),
          ),
        ],
      ),
    );
  }

  void _ilacDetay(Ilac ilac) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => IlacDetayBottomSheet(
        ilac: ilac,
        onIlacDuzenlendi: (guncellenenIlac) async {
          final result = await ilacguncelle(
            guncellenenIlac.adi,
            guncellenenIlac.gunlukKullanim.toString(),
            guncellenenIlac.kalanAdet.toString(),
            guncellenenIlac.id,
            guncellenenIlac.saatler,
          );

          if (result['success'] == true) {
            setState(() {
              final index = ilaclar.indexWhere((i) => i.id == guncellenenIlac.id);
              if (index != -1) {
                ilaclar[index] = guncellenenIlac;
              }
            });
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('İlaç başarıyla güncellendi'),
                backgroundColor: Colors.green[700],
              ),
            );
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('İlaç güncellenirken hata oluştu: ${result['message']}'),
                backgroundColor: Colors.red[700],
              ),
            );
          }
        },
        onIlacKullanildi: (ilacId) {
          _ilacKullanildi(ilacId);
        },
      ),
    );
  }

  void _ilacKullanildi(String ilacId) async {
    try {
      final result = await ilacKullanildi(ilacId, widget.md.id.toString());

      if (result['success'] == true) {
        setState(() {
          final index = ilaclar.indexWhere((ilac) => ilac.id == ilacId);
          if (index != -1) {
            final ilac = ilaclar[index];
            final guncellenenIlac = ilac.copyWith(
              kalanAdet: ilac.kalanAdet - 1,
              alindi: "1", // String olarak "1"
            );
            ilaclar[index] = guncellenenIlac;

            if (guncellenenIlac.kalanAdet == 0) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('${ilac.adi} ilacı bitmiştir!'),
                  backgroundColor: Colors.orange[700],
                  duration: Duration(seconds: 3),
                ),
              );
            }
          }
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('İlaç kullanımı başarıyla kaydedildi'),
            backgroundColor: Colors.green[700],
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('İlaç kullanımı kaydedilemedi: ${result['message']}'),
            backgroundColor: Colors.red[700],
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('İlaç kullanımı kaydedilirken hata oluştu: $e'),
          backgroundColor: Colors.red[700],
        ),
      );
    }
  }

  bool _isMissedDose(String doseTime, TimeOfDay now) {
    final parts = doseTime.split(':');
    final doseHour = int.parse(parts[0]);
    final doseMinute = int.parse(parts[1]);

    final nowInMinutes = now.hour * 60 + now.minute;
    final doseInMinutes = doseHour * 60 + doseMinute;

    return nowInMinutes > (doseInMinutes + 15);
  }

  bool _isWaitingDose(String doseTime, TimeOfDay now) {
    final parts = doseTime.split(':');
    final doseHour = int.parse(parts[0]);
    final doseMinute = int.parse(parts[1]);

    final nowInMinutes = now.hour * 60 + now.minute;
    final doseInMinutes = doseHour * 60 + doseMinute;

    return nowInMinutes < doseInMinutes;
  }

  bool _isTakenDose(String doseTime, Ilac ilac) {
    final now = TimeOfDay.now();
    final parts = doseTime.split(':');
    final doseHour = int.parse(parts[0]);
    final doseMinute = int.parse(parts[1]);

    final nowInMinutes = now.hour * 60 + now.minute;
    final doseInMinutes = doseHour * 60 + doseMinute;

    return nowInMinutes > doseInMinutes && ilac.alindi == "1";
  }

  void _refreshData() {
    _loadIlaclar();
  }

  // YENİ: Alındı durumuna göre buton metnini belirle
  String _getAlindiButtonText(Ilac ilac) {
    if (ilac.alindi == "1") {
      return "Alındı";
    } else if (ilac.alindi == "0" || ilac.alindi == "null" || ilac.alindi.isEmpty) {
      return "Onayla";
    }
    return "Onayla";
  }

  // YENİ: Alındı durumuna göre buton rengini belirle
  Color _getAlindiButtonColor(Ilac ilac) {
    if (ilac.alindi == "1") {
      return Colors.grey[700]!;
    } else if (ilac.alindi == "0" || ilac.alindi == "null" || ilac.alindi.isEmpty) {
      return Colors.green[700]!;
    }
    return Colors.green[700]!;
  }

  // YENİ: Alındı durumuna göre butonun tıklanabilirliğini belirle
  bool _isAlindiButtonEnabled(Ilac ilac) {
    return ilac.alindi != "1" && ilac.kalanAdet > 0;
  }

  @override
  Widget build(BuildContext context) {
    return _buildKlavyeKapatmaWrapper(
      Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          title: Text(
            'İlaçlarım',
            style: TextStyle(
              color: Colors.black,
              fontWeight: FontWeight.w600,
              fontSize: 20,
            ),
          ),
          backgroundColor: Colors.white,
          elevation: 1,
          iconTheme: IconThemeData(color: Colors.black),
          actions: [
            IconButton(
              icon: Icon(Icons.refresh),
              onPressed: _refreshData,
              tooltip: 'Yenile',
            ),
            IconButton(
              onPressed: _ilacEkle,
              icon: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.red[700]!, width: 2),
                ),
                child: Icon(
                  Icons.add,
                  color: Colors.red[700],
                  size: 24,
                ),
              ),
            ),
            SizedBox(width: 8),
          ],
        ),
        body: _buildBody(),
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return _buildLoadingState();
    }

    if (_hasError) {
      return _buildErrorState();
    }

    if (ilaclar.isEmpty) {
      return _buildEmptyState();
    }

    return _buildIlacList();
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(
            color: Colors.red[700],
          ),
          SizedBox(height: 16),
          Text(
            'İlaçlar yükleniyor...',
            style: TextStyle(
              color: Colors.grey[600],
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.error_outline,
            size: 80,
            color: Colors.grey[300],
          ),
          SizedBox(height: 16),
          Text(
            'Hata oluştu',
            style: TextStyle(
              color: Colors.grey[600],
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 8),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 32),
            child: Text(
              _errorMessage,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.grey[500],
                fontSize: 14,
              ),
            ),
          ),
          SizedBox(height: 20),
          ElevatedButton.icon(
            onPressed: _refreshData,
            icon: Icon(Icons.refresh),
            label: Text('Tekrar Dene'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red[700],
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return _buildKlavyeKapatmaWrapper(
      Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.medication_outlined,
              size: 80,
              color: Colors.grey[300],
            ),
            SizedBox(height: 16),
            Text(
              'Henüz ilaç eklenmemiş',
              style: TextStyle(
                color: Colors.grey[500],
                fontSize: 16,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'Yeni ilaç eklemek için + butonuna tıklayın',
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildIlacList() {
    return _buildKlavyeKapatmaWrapper(
      RefreshIndicator(
        onRefresh: _loadIlaclar,
        color: Colors.red[700],
        child: ListView.builder(
          padding: EdgeInsets.all(16),
          itemCount: ilaclar.length,
          itemBuilder: (context, index) {
            final ilac = ilaclar[index];
            return _buildIlacKarti(ilac);
          },
        ),
      ),
    );
  }

  Widget _buildIlacKarti(Ilac ilac) {
    final now = TimeOfDay.now();
    final nextDoseTime = _findNextDoseTime(ilac.saatler, now);
    final isTimeForDose = nextDoseTime != null && _isTimeForDose(nextDoseTime, now);
    final isMissedDose = nextDoseTime != null && _isMissedDose(nextDoseTime, now);

    return Container(
      margin: EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 12,
            offset: Offset(0, 4),
          ),
        ],
        border: Border.all(
          color: Colors.grey.withOpacity(0.2),
          width: 1,
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: Stack(
          children: [
            InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () => _ilacDetay(ilac),
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Row(
                  children: [
                    // İlaç ikonu ve durumu
                    Stack(
                      children: [
                        Container(
                          width: 50,
                          height: 50,
                          decoration: BoxDecoration(
                            color: _getIlacRenk(ilac.adi),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.white, width: 2),
                          ),
                          child: Icon(
                            Icons.medication_outlined,
                            color: Colors.white,
                            size: 24,
                          ),
                        ),
                        // Alındı durumu badge
                        if (ilac.alindi == "1")
                          Positioned(
                            top: -2,
                            right: -2,
                            child: Container(
                              width: 20,
                              height: 20,
                              decoration: BoxDecoration(
                                color: Colors.green[700],
                                shape: BoxShape.circle,
                                border: Border.all(color: Colors.white, width: 2),
                              ),
                              child: Icon(
                                Icons.check,
                                color: Colors.white,
                                size: 12,
                              ),
                            ),
                          ),
                      ],
                    ),
                    SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // İlaç adı ve alındı durumu
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  ilac.adi,
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.grey[800],
                                  ),
                                ),
                              ),
                              // YENİ EKLEME BADGE
                          
                            ],
                          ),
                          SizedBox(height: 4),
                          Row(
                            children: [
                              Icon(
                                Icons.schedule,
                                size: 16,
                                color: Colors.grey[500],
                              ),
                              SizedBox(width: 4),
                              Text(
                                'Günde ${ilac.gunlukKullanim} kez',
                                style: TextStyle(
                                  color: Colors.grey[600],
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 4),
                          if (ilac.saatler.isNotEmpty)
                            Wrap(
                              spacing: 5,
                              children: ilac.saatler.map((saat) {
                                return Container(
                                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: Colors.grey[50]!,
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(color: Colors.grey[300]!),
                                  ),
                                  child: Text(
                                    saat,
                                    style: TextStyle(
                                      color: Colors.grey[600]!,
                                      fontSize: 12,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                );
                              }).toList(),
                            ),
                        ],
                      ),
                    ),
                    Column(
                      children: [
                        // Kalan adet
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: _getKalanAdetRenk(ilac.kalanAdet),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            '${ilac.kalanAdet} adet',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        SizedBox(height: 8),
                        // Onayla/Alındı butonu
                        if (ilac.kalanAdet > 0)
                          Container(
                            height: 30,
                            child: ElevatedButton(
                              onPressed: _isAlindiButtonEnabled(ilac)
                                  ? () => _showIlacKullanildiOnay(ilac)
                                  : null,
                              child: Text(
                                _getAlindiButtonText(ilac),
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: _getAlindiButtonColor(ilac),
                                foregroundColor: Colors.white,
                                padding: EdgeInsets.symmetric(horizontal: 12),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15),
                                ),
                              ),
                            ),
                          )
                        else if (isMissedDose && ilac.kalanAdet > 0)
                          Container(
                            height: 30,
                            child: OutlinedButton(
                              onPressed: () => _showIlacAlinmadiUyari(ilac),
                              child: Text(
                                'Alınmadı',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.red[700],
                                ),
                              ),
                              style: OutlinedButton.styleFrom(
                                side: BorderSide(color: Colors.red[700]!),
                                padding: EdgeInsets.symmetric(horizontal: 12),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15),
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showIlacKullanildiOnay(Ilac ilac) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('İlaç Kullanım Onayı', style: TextStyle(color: Colors.green[700])),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${ilac.adi} ilacını kullandığınızı onaylıyor musunuz?'),
            SizedBox(height: 8),
            Text(
              'Kalan adet: ${ilac.kalanAdet} → ${ilac.kalanAdet - 1}',
              style: TextStyle(fontSize: 12, color: Colors.grey[600]),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('İptal', style: TextStyle(color: Colors.grey[700])),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              _ilacKullanildi(ilac.id);
            },
            child: Text('Onayla', style: TextStyle(color: Colors.green[700])),
          ),
        ],
      ),
    );
  }

  void _showIlacAlinmadiUyari(Ilac ilac) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('İlaç Zamanında Alınmadı', style: TextStyle(color: Colors.orange[700])),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${ilac.adi} ilacını zamanında almadınız. Yine de kullandıysanız onaylayabilirsiniz.'),
            SizedBox(height: 8),
            Text(
              'Kalan adet: ${ilac.kalanAdet} → ${ilac.kalanAdet - 1}',
              style: TextStyle(fontSize: 12, color: Colors.grey[600]),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('İptal', style: TextStyle(color: Colors.grey[700])),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              _ilacKullanildi(ilac.id);
            },
            child: Text('Onayla', style: TextStyle(color: Colors.orange[700])),
          ),
        ],
      ),
    );
  }

  String? _findNextDoseTime(List<String> saatler, TimeOfDay now) {
    if (saatler.isEmpty) return null;

    final times = saatler.map((saat) {
      final parts = saat.split(':');
      return TimeOfDay(hour: int.parse(parts[0]), minute: int.parse(parts[1]));
    }).toList();

    times.sort((a, b) {
      if (a.hour != b.hour) return a.hour.compareTo(b.hour);
      return a.minute.compareTo(b.minute);
    });

    for (final time in times) {
      if (time.hour > now.hour || (time.hour == now.hour && time.minute > now.minute)) {
        return '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
      }
    }

    final firstTime = times.first;
    return '${firstTime.hour.toString().padLeft(2, '0')}:${firstTime.minute.toString().padLeft(2, '0')}';
  }

  bool _isTimeForDose(String doseTime, TimeOfDay now) {
    final parts = doseTime.split(':');
    final doseHour = int.parse(parts[0]);
    final doseMinute = int.parse(parts[1]);
    final nowInMinutes = now.hour * 60 + now.minute;
    final doseInMinutes = doseHour * 60 + doseMinute;

    return (nowInMinutes >= doseInMinutes - 15) && (nowInMinutes <= doseInMinutes + 15);
  }

  Color _getIlacRenk(String ilacAdi) {
    final colors = [
      Colors.red[700]!,
      Colors.orange[700]!,
      Colors.blue[700]!,
      Colors.green[700]!,
      Colors.purple[700]!,
    ];
    final index = ilacAdi.hashCode % colors.length;
    return colors[index];
  }

  Color _getKalanAdetRenk(int kalanAdet) {
    if (kalanAdet <= 5) return Colors.red[700]!;
    if (kalanAdet <= 10) return Colors.orange[700]!;
    return Colors.green[700]!;
  }
}

class IlacEkleBottomSheet extends StatefulWidget {
  final Function(Ilac) onIlacEklendi;

  const IlacEkleBottomSheet({Key? key, required this.onIlacEklendi}) : super(key: key);

  @override
  State<IlacEkleBottomSheet> createState() => _IlacEkleBottomSheetState();
}

class _IlacEkleBottomSheetState extends State<IlacEkleBottomSheet> {
  final _formKey = GlobalKey<FormState>();
  final _ilacAdiController = TextEditingController();
  final _gunlukKullanimController = TextEditingController();
  final _toplamAdetController = TextEditingController();
  List<String> _seciliSaatler = [];

  DateTime _calculateEndDate(int toplamAdet, int gunlukKullanim) {
    final gunSayisi = toplamAdet ~/ gunlukKullanim;
    return DateTime.now().add(Duration(days: gunSayisi));
  }

  int _calculateRemainingDays(DateTime endDate) {
    final now = DateTime.now();
    return endDate.difference(now).inDays;
  }

  void _updateCalculations() {
    if (_toplamAdetController.text.isNotEmpty && _gunlukKullanimController.text.isNotEmpty) {
      final toplamAdet = int.tryParse(_toplamAdetController.text) ?? 0;
      final gunlukKullanim = int.tryParse(_gunlukKullanimController.text) ?? 1;

      if (toplamAdet > 0 && gunlukKullanim > 0) {
        setState(() {});
      }
    }
  }

  // YENİ: Saat sayısı kontrolü
  String? _validateSaatSayisi() {
    final gunlukKullanim = int.tryParse(_gunlukKullanimController.text) ?? 0;

    if (_seciliSaatler.isEmpty) {
      return 'En az bir saat eklemelisiniz';
    }

    if (_seciliSaatler.length != gunlukKullanim) {
      return 'Günde $gunlukKullanim kez kullanım için tam $gunlukKullanim adet saat eklemelisiniz. Şu an ${_seciliSaatler.length} saat ekli.';
    }

    return null;
  }

  void _saatEkle() async {
    FocusManager.instance.primaryFocus?.unfocus();

    await Future.delayed(Duration(milliseconds: 100));

    final gunlukKullanim = int.tryParse(_gunlukKullanimController.text) ?? 0;

    // YENİ: Maksimum saat kontrolü
    if (gunlukKullanim > 0 && _seciliSaatler.length >= gunlukKullanim) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Günde $gunlukKullanim kez kullanım için maksimum $gunlukKullanim saat ekleyebilirsiniz'),
          backgroundColor: Colors.orange[700],
        ),
      );
      return;
    }

    final result = await showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _buildModernTimePicker(),
    );

    if (result != null && result is String) {
      if (!_seciliSaatler.contains(result)) {
        setState(() {
          _seciliSaatler.add(result);
          _seciliSaatler.sort();
        });
      }
    }
  }

  Widget _buildModernTimePicker() {
    int selectedHour = TimeOfDay.now().hour;
    int selectedMinute = TimeOfDay.now().minute;

    return StatefulBuilder(
      builder: (context, setState) {
        return GestureDetector(
          onTap: () {},
          child: Container(
            height: MediaQuery.of(context).size.height * 0.6,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(24),
                topRight: Radius.circular(24),
              ),
            ),
            child: Column(
              children: [
                Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    border: Border(
                      bottom: BorderSide(color: Colors.grey[200]!),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TextButton(
                        onPressed: () => Navigator.of(context).pop(),
                        child: Text(
                          'İptal',
                          style: TextStyle(
                            color: Colors.grey[600],
                            fontSize: 16,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                      Text(
                        'Saat Seç',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Colors.black87,
                        ),
                      ),
                      TextButton(
                        onPressed: () {
                          final saat = '${selectedHour.toString().padLeft(2, '0')}:${selectedMinute.toString().padLeft(2, '0')}';
                          Navigator.of(context).pop(saat);
                        },
                        child: Text(
                          'Tamam',
                          style: TextStyle(
                            color: Colors.red[700],
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                Container(
                  padding: EdgeInsets.symmetric(vertical: 24),
                  child: Text(
                    '${selectedHour.toString().padLeft(2, '0')}:${selectedMinute.toString().padLeft(2, '0')}',
                    style: TextStyle(
                      fontSize: 48,
                      fontWeight: FontWeight.w300,
                      color: Colors.red[700],
                    ),
                  ),
                ),

                Expanded(
                  child: Row(
                    children: [
                      Expanded(
                        child: ListWheelScrollView(
                          itemExtent: 50,
                          perspective: 0.005,
                          diameterRatio: 1.5,
                          physics: FixedExtentScrollPhysics(),
                          onSelectedItemChanged: (index) {
                            setState(() {
                              selectedHour = index;
                            });
                          },
                          children: List.generate(24, (hour) {
                            final isSelected = hour == selectedHour;
                            return Container(
                              alignment: Alignment.center,
                              child: Text(
                                hour.toString().padLeft(2, '0'),
                                style: TextStyle(
                                  fontSize: isSelected ? 22 : 18,
                                  fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                                  color: isSelected ? Colors.red[700] : Colors.grey[600],
                                ),
                              ),
                            );
                          }),
                        ),
                      ),

                      Expanded(
                        child: ListWheelScrollView(
                          itemExtent: 50,
                          perspective: 0.005,
                          diameterRatio: 1.5,
                          physics: FixedExtentScrollPhysics(),
                          onSelectedItemChanged: (index) {
                            setState(() {
                              selectedMinute = index;
                            });
                          },
                          children: List.generate(60, (minute) {
                            final isSelected = minute == selectedMinute;
                            return Container(
                              alignment: Alignment.center,
                              child: Text(
                                minute.toString().padLeft(2, '0'),
                                style: TextStyle(
                                  fontSize: isSelected ? 22 : 18,
                                  fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                                  color: isSelected ? Colors.red[700] : Colors.grey[600],
                                ),
                              ),
                            );
                          }),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _saatSil(String saat) {
    setState(() {
      _seciliSaatler.remove(saat);
    });
  }

  void _ilacKaydet() {
    FocusManager.instance.primaryFocus?.unfocus();

    if (_formKey.currentState!.validate()) {
      final saatHatasi = _validateSaatSayisi();
      if (saatHatasi != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(saatHatasi),
            backgroundColor: Colors.red[700],
          ),
        );
        return;
      }

      final toplamAdet = int.parse(_toplamAdetController.text);
      final gunlukKullanim = int.parse(_gunlukKullanimController.text);
      final bitisTarihi = _calculateEndDate(toplamAdet, gunlukKullanim);

      final yeniIlac = Ilac(
        id: '',
        adi: _ilacAdiController.text,
        gunlukKullanim: gunlukKullanim,
        saatler: _seciliSaatler,
        kalanAdet: toplamAdet,
        baslangicTarihi: DateTime.now(),
        bitisTarihi: bitisTarihi,
        alindi: "0", // Varsayılan olarak "0" (kullanılmadı)

      );

      widget.onIlacEklendi(yeniIlac);
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final toplamAdet = int.tryParse(_toplamAdetController.text) ?? 0;
    final gunlukKullanim = int.tryParse(_gunlukKullanimController.text) ?? 1;
    final bitisTarihi = _calculateEndDate(toplamAdet, gunlukKullanim);
    final kalanGun = _calculateRemainingDays(bitisTarihi);

    return GestureDetector(
      onTap: () {
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Container(
        height: MediaQuery.of(context).size.height * 0.9,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(24),
            topRight: Radius.circular(24),
          ),
        ),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.1),
                    blurRadius: 8,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: Colors.red[700],
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(
                      Icons.add_circle_outline,
                      color: Colors.white,
                      size: 22,
                    ),
                  ),
                  SizedBox(width: 12),
                  Text(
                    'Yeni İlaç Ekle',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Spacer(),
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: Icon(Icons.close, color: Colors.grey[500]),
                  ),
                ],
              ),
            ),

            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.all(16),
                child: Form(
                  key: _formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _buildTextField(
                        controller: _ilacAdiController,
                        label: 'İlaç Adı',
                        hintText: 'İlacın adını giriniz',
                        icon: Icons.medication_outlined,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'İlaç adı gereklidir';
                          }
                          return null;
                        },
                      ),
                      SizedBox(height: 20),

                      _buildTextField(
                        controller: _gunlukKullanimController,
                        label: 'Günde Kaç Kez',
                        hintText: 'Günlük kullanım sayısı',
                        icon: Icons.repeat,
                        keyboardType: TextInputType.number,
                        onChanged: (_) => _updateCalculations(),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Günlük kullanım sayısı gereklidir';
                          }
                          final sayi = int.tryParse(value);
                          if (sayi == null) {
                            return 'Geçerli bir sayı giriniz';
                          }
                          if (sayi < 1) {
                            return 'En az 1 olmalıdır';
                          }
                          if (sayi > 10) {
                            return 'En fazla 10 olabilir';
                          }
                          return null;
                        },
                      ),
                      SizedBox(height: 20),

                      _buildTextField(
                        controller: _toplamAdetController,
                        label: 'Toplam Adet',
                        hintText: 'Toplam ilaç adedi',
                        icon: Icons.inventory_2_outlined,
                        keyboardType: TextInputType.number,
                        onChanged: (_) => _updateCalculations(),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Toplam adet gereklidir';
                          }
                          if (int.tryParse(value) == null) {
                            return 'Geçerli bir sayı giriniz';
                          }
                          return null;
                        },
                      ),
                      SizedBox(height: 20),

                      if (toplamAdet > 0 && gunlukKullanim > 0)
                        Container(
                          padding: EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.blue[50],
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.blue[100]!),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Hesaplanan Bilgiler:',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.blue[800],
                                ),
                              ),
                              SizedBox(height: 8),
                              Text('Bitiş Tarihi: ${DateFormat('dd.MM.yyyy').format(bitisTarihi)}'),
                              Text('Toplam Süre: $kalanGun gün'),
                              Text('Kalan Adet: $toplamAdet adet'),
                              // YENİ: Saat bilgisi
                              Text(
                                'Eklenmesi gereken saat sayısı: $gunlukKullanim',
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: Colors.blue[700],
                                ),
                              ),
                            ],
                          ),
                        ),
                      SizedBox(height: 20),

                      Text(
                        'Alım Saatleri',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(height: 8),

                      // YENİ: Saat durumu bilgisi
                      if (gunlukKullanim > 0)
                        Text(
                          'Günde $gunlukKullanim kez kullanım için $gunlukKullanim adet saat eklemelisiniz (${_seciliSaatler.length}/$gunlukKullanim)',
                          style: TextStyle(
                            color: _seciliSaatler.length == gunlukKullanim ? Colors.green[700] : Colors.orange[700],
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      SizedBox(height: 12),

                      _seciliSaatler.isEmpty
                          ? Container(
                        padding: EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.grey[50],
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.grey[300]!),
                        ),
                        child: Center(
                          child: Text(
                            'Henüz saat eklenmedi',
                            style: TextStyle(
                              color: Colors.grey[500],
                            ),
                          ),
                        ),
                      )
                          : Wrap(
                        spacing: 10,
                        runSpacing: 10,
                        children: _seciliSaatler.map((saat) {
                          return Chip(
                            label: Text(saat),
                            deleteIcon: Icon(Icons.close, size: 16),
                            onDeleted: () => _saatSil(saat),
                            backgroundColor: _seciliSaatler.length == gunlukKullanim ? Colors.green[50] : Colors.red[50],
                            labelStyle: TextStyle(
                              color: _seciliSaatler.length == gunlukKullanim ? Colors.green[700] : Colors.red[700],
                            ),
                          );
                        }).toList(),
                      ),
                      SizedBox(height: 16),

                      // YENİ: Buton durumu
                      OutlinedButton.icon(
                        onPressed: _saatEkle,
                        icon: Icon(
                            Icons.add_circle_outline,
                            color: (gunlukKullanim > 0 && _seciliSaatler.length >= gunlukKullanim)
                                ? Colors.grey
                                : Colors.red[700]
                        ),
                        label: Text(
                            'Saat Ekle',
                            style: TextStyle(
                                color: (gunlukKullanim > 0 && _seciliSaatler.length >= gunlukKullanim)
                                    ? Colors.grey
                                    : Colors.red[700]
                            )
                        ),
                        style: OutlinedButton.styleFrom(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          side: BorderSide(
                              color: (gunlukKullanim > 0 && _seciliSaatler.length >= gunlukKullanim)
                                  ? Colors.grey
                                  : Colors.red[700]!
                          ),
                        ),
                      ),
                      SizedBox(height: 32),

                      Container(
                        width: double.infinity,
                        height: 54,
                        child: ElevatedButton(
                          onPressed: _ilacKaydet,
                          child: Text(
                            'İlacı Kaydet',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.red[700],
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                            elevation: 2,
                          ),
                        ),
                      ),
                      SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hintText,
    required IconData icon,
    TextInputType? keyboardType,
    Function(String)? onChanged,
    String? Function(String?)? validator,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
        SizedBox(height: 8),
        TextFormField(
          controller: controller,
          keyboardType: keyboardType,
          validator: validator,
          onChanged: onChanged,
          decoration: InputDecoration(
            hintText: hintText,
            prefixIcon: Icon(icon, color: Colors.red[700]),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.red[700]!, width: 2),
            ),
          ),
        ),
      ],
    );
  }
}

class IlacDetayBottomSheet extends StatelessWidget {
  final Ilac ilac;
  final Function(Ilac)? onIlacDuzenlendi;
  final Function(String)? onIlacKullanildi;

  const IlacDetayBottomSheet({
    Key? key,
    required this.ilac,
    this.onIlacDuzenlendi,
    this.onIlacKullanildi,
  }) : super(key: key);

  void _ilacDuzenle(BuildContext context) {
    Navigator.of(context).pop();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => IlacDuzenleBottomSheet(
        ilac: ilac,
        onIlacDuzenlendi: onIlacDuzenlendi,
      ),
    );
  }

  void _ilacKullan(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('İlaç Kullanım Onayı'),
        content: Text('${ilac.adi} ilacını kullandığınızı onaylıyor musunuz?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('İptal'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              onIlacKullanildi?.call(ilac.id);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('${ilac.adi} kullanıldı olarak işaretlendi'),
                  backgroundColor: Colors.green[700],
                ),
              );
            },
            child: Text('Onayla', style: TextStyle(color: Colors.green[700])),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('dd.MM.yyyy');
    final now = TimeOfDay.now();
    final nextDoseTime = _findNextDoseTime(ilac.saatler, now);
    final isTimeForDose = nextDoseTime != null && _isTimeForDose(nextDoseTime, now);

    return Container(
      height: MediaQuery.of(context).size.height * 0.85,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
      ),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(24),
                topRight: Radius.circular(24),
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  blurRadius: 8,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.red[700],
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(
                    Icons.medication_outlined,
                    color: Colors.white,
                    size: 24,
                  ),
                ),
                SizedBox(width: 12),
                Text(
                  'İlaç Detayı',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Spacer(),
                IconButton(
                  onPressed: () => Navigator.of(context).pop(),
                  icon: Icon(Icons.close, color: Colors.grey[500]),
                ),
              ],
            ),
          ),

          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(16),
              child: Column(
                children: [
                  _buildDetayItem(
                    icon: Icons.medication_outlined,
                    title: 'İlaç Adı',
                    value: ilac.adi,
                  ),
                  _buildDetayItem(
                    icon: Icons.repeat,
                    title: 'Günlük Kullanım',
                    value: 'Günde ${ilac.gunlukKullanim} kez',
                  ),
                  _buildDetayItem(
                    icon: Icons.access_time,
                    title: 'Alım Saatleri',
                    value: ilac.saatler.join(', '),
                  ),
                  _buildDetayItem(
                    icon: Icons.inventory_2_outlined,
                    title: 'Kalan Adet',
                    value: '${ilac.kalanAdet} adet',
                  ),
                  _buildDetayItem(
                    icon: Icons.calendar_today,
                    title: 'Başlangıç Tarihi',
                    value: dateFormat.format(ilac.baslangicTarihi),
                  ),
                  _buildDetayItem(
                    icon: Icons.event_available,
                    title: 'Bitiş Tarihi',
                    value: dateFormat.format(ilac.bitisTarihi),
                  ),
                  if (isTimeForDose && ilac.kalanAdet > 0)
                    Container(
                      margin: EdgeInsets.only(top: 16),
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.green[50],
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: Colors.green[200]!),
                      ),
                      child: Column(
                        children: [
                          Icon(Icons.notifications_active, size: 40, color: Colors.green[700]),
                          SizedBox(height: 8),
                          Text(
                            'İlaç Saati Geldi!',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              color: Colors.green[700],
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            '${ilac.adi} ilacını kullanma zamanı',
                            textAlign: TextAlign.center,
                          ),
                          SizedBox(height: 16),
                          Container(
                            width: double.infinity,
                            height: 50,
                            child: ElevatedButton.icon(
                              onPressed: () => _ilacKullan(context),
                              icon: Icon(Icons.check),
                              label: Text('İlacı Kullandım'),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.green[700],
                                foregroundColor: Colors.white,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  SizedBox(height: 24),
                  Container(
                    width: double.infinity,
                    height: 54,
                    child: ElevatedButton.icon(
                      onPressed: () => _ilacDuzenle(context),
                      icon: Icon(Icons.edit_outlined),
                      label: Text('İlacı Düzenle'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red[700],
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  String? _findNextDoseTime(List<String> saatler, TimeOfDay now) {
    if (saatler.isEmpty) return null;

    final times = saatler.map((saat) {
      final parts = saat.split(':');
      return TimeOfDay(hour: int.parse(parts[0]), minute: int.parse(parts[1]));
    }).toList();

    times.sort((a, b) {
      if (a.hour != b.hour) return a.hour.compareTo(b.hour);
      return a.minute.compareTo(b.minute);
    });

    for (final time in times) {
      if (time.hour > now.hour || (time.hour == now.hour && time.minute > now.minute)) {
        return '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
      }
    }

    final firstTime = times.first;
    return '${firstTime.hour.toString().padLeft(2, '0')}:${firstTime.minute.toString().padLeft(2, '0')}';
  }

  bool _isTimeForDose(String doseTime, TimeOfDay now) {
    final parts = doseTime.split(':');
    final doseHour = int.parse(parts[0]);
    final doseMinute = int.parse(parts[1]);

    final nowInMinutes = now.hour * 60 + now.minute;
    final doseInMinutes = doseHour * 60 + doseMinute;

    return (nowInMinutes >= doseInMinutes - 15) && (nowInMinutes <= doseInMinutes + 15);
  }

  Widget _buildDetayItem({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 12),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey[200]!),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.red[700]!, width: 2),
            ),
            child: Icon(icon, color: Colors.red[700], size: 20),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey[600],
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 6),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.grey[800],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class IlacDuzenleBottomSheet extends StatefulWidget {
  final Ilac ilac;
  final Function(Ilac)? onIlacDuzenlendi;

  const IlacDuzenleBottomSheet({
    Key? key,
    required this.ilac,
    this.onIlacDuzenlendi,
  }) : super(key: key);

  @override
  State<IlacDuzenleBottomSheet> createState() => _IlacDuzenleBottomSheetState();
}

class _IlacDuzenleBottomSheetState extends State<IlacDuzenleBottomSheet> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _ilacAdiController;
  late TextEditingController _ilacid;
  late TextEditingController _gunlukKullanimController;
  late TextEditingController _kalanAdetController;
  late List<String> _seciliSaatler;

  @override
  void initState() {
    super.initState();
    _ilacid = TextEditingController(text: widget.ilac.id);
    _ilacAdiController = TextEditingController(text: widget.ilac.adi);
    _gunlukKullanimController = TextEditingController(text: widget.ilac.gunlukKullanim.toString());
    _kalanAdetController = TextEditingController(text: widget.ilac.kalanAdet.toString());
    _seciliSaatler = List.from(widget.ilac.saatler);
  }

  // YENİ: Saat sayısı kontrolü (düzenleme için)
  String? _validateSaatSayisi() {
    final gunlukKullanim = int.tryParse(_gunlukKullanimController.text) ?? 0;

    if (_seciliSaatler.isEmpty) {
      return 'En az bir saat eklemelisiniz';
    }

    if (_seciliSaatler.length != gunlukKullanim) {
      return 'Günde $gunlukKullanim kez kullanım için tam $gunlukKullanim adet saat eklemelisiniz. Şu an ${_seciliSaatler.length} saat ekli.';
    }

    return null;
  }

  void _saatEkle() async {
    FocusManager.instance.primaryFocus?.unfocus();

    await Future.delayed(Duration(milliseconds: 100));

    final gunlukKullanim = int.tryParse(_gunlukKullanimController.text) ?? 0;

    // YENİ: Maksimum saat kontrolü
    if (gunlukKullanim > 0 && _seciliSaatler.length >= gunlukKullanim) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Günde $gunlukKullanim kez kullanım için maksimum $gunlukKullanim saat ekleyebilirsiniz'),
          backgroundColor: Colors.orange[700],
        ),
      );
      return;
    }

    final result = await showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _buildModernTimePicker(),
    );

    if (result != null && result is String) {
      if (!_seciliSaatler.contains(result)) {
        setState(() {
          _seciliSaatler.add(result);
          _seciliSaatler.sort();
        });
      }
    }
  }

  Widget _buildModernTimePicker() {
    int selectedHour = TimeOfDay.now().hour;
    int selectedMinute = TimeOfDay.now().minute;

    return StatefulBuilder(
      builder: (context, setState) {
        return Container(
          height: MediaQuery.of(context).size.height * 0.6,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(24),
              topRight: Radius.circular(24),
            ),
          ),
          child: Column(
            children: [
              Container(
                padding: EdgeInsets.all(16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextButton(
                      onPressed: () => Navigator.of(context).pop(),
                      child: Text('İptal'),
                    ),
                    Text('Saat Seç', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                    TextButton(
                      onPressed: () {
                        final saat = '${selectedHour.toString().padLeft(2, '0')}:${selectedMinute.toString().padLeft(2, '0')}';
                        Navigator.of(context).pop(saat);
                      },
                      child: Text('Tamam', style: TextStyle(color: Colors.red[700])),
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Text(
                  '${selectedHour.toString().padLeft(2, '0')}:${selectedMinute.toString().padLeft(2, '0')}',
                  style: TextStyle(fontSize: 48, color: Colors.red[700]),
                ),
              ),
              Expanded(
                child: Row(
                  children: [
                    Expanded(
                      child: ListWheelScrollView(
                        itemExtent: 50,
                        physics: FixedExtentScrollPhysics(),
                        onSelectedItemChanged: (index) => setState(() => selectedHour = index),
                        children: List.generate(24, (hour) {
                          final isSelected = hour == selectedHour;
                          return Container(
                            alignment: Alignment.center,
                            child: Text(
                              hour.toString().padLeft(2, '0'),
                              style: TextStyle(
                                fontSize: isSelected ? 22 : 18,
                                color: isSelected ? Colors.red[700] : Colors.grey[600],
                              ),
                            ),
                          );
                        }),
                      ),
                    ),
                    Expanded(
                      child: ListWheelScrollView(
                        itemExtent: 50,
                        physics: FixedExtentScrollPhysics(),
                        onSelectedItemChanged: (index) => setState(() => selectedMinute = index),
                        children: List.generate(60, (minute) {
                          final isSelected = minute == selectedMinute;
                          return Container(
                            alignment: Alignment.center,
                            child: Text(
                              minute.toString().padLeft(2, '0'),
                              style: TextStyle(
                                fontSize: isSelected ? 22 : 18,
                                color: isSelected ? Colors.red[700] : Colors.grey[600],
                              ),
                            ),
                          );
                        }),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _saatSil(String saat) {
    setState(() {
      _seciliSaatler.remove(saat);
    });
  }

  void _ilacGuncelle() {
    FocusManager.instance.primaryFocus?.unfocus();

    if (_formKey.currentState!.validate()) {
      final saatHatasi = _validateSaatSayisi();
      if (saatHatasi != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(saatHatasi),
            backgroundColor: Colors.red[700],
          ),
        );
        return;
      }

      final guncellenenIlac = Ilac(
        id: widget.ilac.id,
        adi: _ilacAdiController.text,
        gunlukKullanim: int.parse(_gunlukKullanimController.text),
        saatler: _seciliSaatler,
        kalanAdet: int.parse(_kalanAdetController.text),
        baslangicTarihi: widget.ilac.baslangicTarihi,
        bitisTarihi: widget.ilac.bitisTarihi,
        alindi: "0", // Varsayılan olarak "0" (kullanılmadı)

      );

      widget.onIlacDuzenlendi?.call(guncellenenIlac);
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final gunlukKullanim = int.tryParse(_gunlukKullanimController.text) ?? 1;

    return GestureDetector(
      onTap: () {
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Container(
        height: MediaQuery.of(context).size.height * 0.9,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(24),
            topRight: Radius.circular(24),
          ),
        ),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.1),
                    blurRadius: 8,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: Colors.red[700],
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(Icons.edit_outlined, color: Colors.white, size: 22),
                  ),
                  SizedBox(width: 12),
                  Text('İlacı Düzenle', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                  Spacer(),
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: Icon(Icons.close, color: Colors.grey[500]),
                  ),
                ],
              ),
            ),

            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.all(16),
                child: Form(
                  key: _formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _buildTextField(
                        controller: _ilacAdiController,
                        label: 'İlaç Adı',
                        hintText: 'İlacın adını giriniz',
                        icon: Icons.medication_outlined,
                        validator: (value) {
                          if (value == null || value.isEmpty) return 'İlaç adı gereklidir';
                          return null;
                        },
                      ),
                      SizedBox(height: 20),
                      _buildTextField(
                        controller: _gunlukKullanimController,
                        label: 'Günde Kaç Kez',
                        hintText: 'Günlük kullanım sayısı',
                        icon: Icons.repeat,
                        keyboardType: TextInputType.number,
                        validator: (value) {
                          if (value == null || value.isEmpty) return 'Günlük kullanım sayısı gereklidir';
                          final sayi = int.tryParse(value);
                          if (sayi == null) return 'Geçerli bir sayı giriniz';
                          if (sayi < 1) return 'En az 1 olmalıdır';
                          if (sayi > 10) return 'En fazla 10 olabilir';
                          return null;
                        },
                      ),
                      SizedBox(height: 20),
                      _buildTextField(
                        controller: _kalanAdetController,
                        label: 'Kalan Adet',
                        hintText: 'Kalan ilaç adedi',
                        icon: Icons.inventory_2_outlined,
                        keyboardType: TextInputType.number,
                        validator: (value) {
                          if (value == null || value.isEmpty) return 'Kalan adet gereklidir';
                          if (int.tryParse(value) == null) return 'Geçerli bir sayı giriniz';
                          return null;
                        },
                      ),
                      SizedBox(height: 20),
                      Text('Alım Saatleri', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                      SizedBox(height: 8),

                      // YENİ: Saat durumu bilgisi
                      Text(
                        'Günde $gunlukKullanim kez kullanım için $gunlukKullanim adet saat eklemelisiniz (${_seciliSaatler.length}/$gunlukKullanim)',
                        style: TextStyle(
                          color: _seciliSaatler.length == gunlukKullanim ? Colors.green[700] : Colors.orange[700],
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(height: 12),

                      Wrap(
                        spacing: 10,
                        runSpacing: 10,
                        children: _seciliSaatler.map((saat) {
                          return Chip(
                            label: Text(saat),
                            deleteIcon: Icon(Icons.close, size: 16),
                            onDeleted: () => _saatSil(saat),
                            backgroundColor: _seciliSaatler.length == gunlukKullanim ? Colors.green[50] : Colors.red[50],
                            labelStyle: TextStyle(
                              color: _seciliSaatler.length == gunlukKullanim ? Colors.green[700] : Colors.red[700],
                            ),
                          );
                        }).toList(),
                      ),
                      SizedBox(height: 16),

                      // YENİ: Buton durumu
                      OutlinedButton.icon(
                        onPressed: _saatEkle,
                        icon: Icon(
                            Icons.add_circle_outline,
                            color: (gunlukKullanim > 0 && _seciliSaatler.length >= gunlukKullanim)
                                ? Colors.grey
                                : Colors.red[700]
                        ),
                        label: Text(
                            'Saat Ekle',
                            style: TextStyle(
                                color: (gunlukKullanim > 0 && _seciliSaatler.length >= gunlukKullanim)
                                    ? Colors.grey
                                    : Colors.red[700]
                            )
                        ),
                        style: OutlinedButton.styleFrom(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          side: BorderSide(
                              color: (gunlukKullanim > 0 && _seciliSaatler.length >= gunlukKullanim)
                                  ? Colors.grey
                                  : Colors.red[700]!
                          ),
                        ),
                      ),
                      SizedBox(height: 32),
                      Container(
                        width: double.infinity,
                        height: 54,
                        child: ElevatedButton(
                          onPressed: _ilacGuncelle,
                          child: Text(
                            'İlacı Güncelle',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.red[700],
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                            elevation: 2,
                          ),
                        ),
                      ),
                      SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hintText,
    required IconData icon,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
        SizedBox(height: 8),
        TextFormField(
          controller: controller,
          keyboardType: keyboardType,
          validator: validator,
          decoration: InputDecoration(
            hintText: hintText,
            prefixIcon: Icon(icon, color: Colors.red[700]),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.red[700]!, width: 2),
            ),
          ),
        ),
      ],
    );
  }
}