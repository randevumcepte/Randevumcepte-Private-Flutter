class Ilac {
  final String id;
  final String adi;
  final int gunlukKullanim;
  final List<String> saatler;
  int kalanAdet;
  final DateTime baslangicTarihi;
  final DateTime bitisTarihi;
  final String alindi; // String olarak değiştirildi

  Ilac({
    required this.id,
    required this.adi,
    required this.gunlukKullanim,
    required this.saatler,
    required this.kalanAdet,
    required this.baslangicTarihi,
    required this.bitisTarihi,
    required this.alindi, // String olarak değiştirildi
  });

  factory Ilac.fromJson(Map<String, dynamic> json) {
    // Saatleri parse et
    List<String> parsedSaatler = [];
    if (json['saatler'] is List) {
      parsedSaatler = List<String>.from(json['saatler']);
    } else if (json['saatler'] is String) {
      parsedSaatler = (json['saatler'] as String).split(',').map((e) => e.trim()).toList();
    }

    // Tarihleri parse et
    DateTime parseTarih(dynamic tarih) {
      if (tarih == null) return DateTime.now();
      if (tarih is String) {
        return DateTime.parse(tarih);
      }
      return DateTime.now();
    }

    // Alındı durumunu parse et - String olarak
    String parseAlindi(dynamic alindi) {
      if (alindi == null) return "0";
      if (alindi is String) return alindi;
      if (alindi is int) return alindi.toString();
      if (alindi is bool) return alindi ? "1" : "0";
      return "0";
    }

    return Ilac(
      id: json['id'].toString(),
      adi: json['adi'] ?? json['adi'] ?? 'İlaç',
      gunlukKullanim: json['gunluk_kullanim'] ?? json['gunluk_kullanim'] ?? 1,
      saatler: parsedSaatler,
      kalanAdet: json['kalan_adet'] ?? json['kalan_adet'] ?? 0,
      baslangicTarihi: parseTarih(json['baslangic_tarihi'] ?? json['baslangic_tarihi']),
      bitisTarihi: parseTarih(json['bitis_tarihi'] ?? json['bitis_tarihi']),
      alindi: parseAlindi(json['alindi']), // String olarak
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'adi': adi,
      'gunluk_kullanim': gunlukKullanim,
      'saatler': saatler,
      'kalan_adet': kalanAdet,
      'baslangic_tarihi': baslangicTarihi.toIso8601String(),
      'bitis_tarihi': bitisTarihi.toIso8601String(),
      'alindi': alindi, // String olarak
    };
  }

  Ilac copyWith({
    String? id,
    String? adi,
    int? gunlukKullanim,
    List<String>? saatler,
    int? kalanAdet,
    DateTime? baslangicTarihi,
    DateTime? bitisTarihi,
    String? alindi, // String olarak
  }) {
    return Ilac(
      id: id ?? this.id,
      adi: adi ?? this.adi,
      gunlukKullanim: gunlukKullanim ?? this.gunlukKullanim,
      saatler: saatler ?? this.saatler,
      kalanAdet: kalanAdet ?? this.kalanAdet,
      baslangicTarihi: baslangicTarihi ?? this.baslangicTarihi,
      bitisTarihi: bitisTarihi ?? this.bitisTarihi,
      alindi: alindi ?? this.alindi, // String olarak
    );
  }
}