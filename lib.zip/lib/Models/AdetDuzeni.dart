import 'dart:ui';

import 'package:flutter/material.dart';

class AdetDonemi {
  final String id;
  final DateTime baslangicTarihi;
  final DateTime bitisTarihi;
  final int sure;
  final int dongu;
  final List<String> belirtiler;
  final String not;
  final Color renk;

  AdetDonemi({
    required this.id,
    required this.baslangicTarihi,
    required this.bitisTarihi,
    required this.sure,
    required this.dongu,
    required this.belirtiler,
    required this.not,
    required this.renk,
  });

  // JSON'dan AdetDonemi oluşturan factory method
  factory AdetDonemi.fromJson(Map<String, dynamic> json) {
    // Renk string'ini Color'a çevir
    Color renkColor;
    try {
      renkColor = _parseColor(json['renk'] ?? '#C2185B');
    } catch (e) {
      renkColor = Colors.pink[700]!;
    }

    // Belirtileri List<String>'e çevir
    List<String> belirtilerList = [];
    if (json['belirtiler'] != null) {
      if (json['belirtiler'] is List) {
        belirtilerList = List<String>.from(json['belirtiler']);
      }
    }

    return AdetDonemi(
      id: json['id']?.toString() ?? DateTime.now().millisecondsSinceEpoch.toString(),
      baslangicTarihi: DateTime.parse(json['baslangic_tarihi']),
      bitisTarihi: DateTime.parse(json['bitis_tarihi']),
      sure: json['sure'] ?? 0,
      dongu: json['dongu'] ?? 28,
      belirtiler: belirtilerList,
      not: json['not'] ?? '',
      renk: renkColor,
    );
  }

  // Hex color string'ini Color'a çeviren yardımcı method
  static Color _parseColor(String colorString) {
    try {
      String hexColor = colorString.replaceAll('#', '');
      if (hexColor.length == 6) {
        hexColor = 'FF$hexColor'; // Alpha değeri ekle
      }
      return Color(int.parse(hexColor, radix: 16));
    } catch (e) {
      return Colors.pink[700]!;
    }
  }
}