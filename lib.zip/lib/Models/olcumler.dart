import 'dart:convert';

import 'package:randevu_sistem/Models/katilimcilar.dart';
class Olcumler {
  Olcumler({
    required this.id,
    required this.user_id,
     
    required this.olcum_turu,
    required this.olcum_sikligi,
    required this.olcum_saatleri,
    required this.olcum_gecmisi,
    required this.her_x_gun,
    required this.haftanin_gunu,




  });

  final String id;
  final String user_id;
  final dynamic olcum_turu;
  final List<dynamic> olcum_gecmisi;
  final String olcum_sikligi;
  final String olcum_saatleri;
  final String her_x_gun;
  final String haftanin_gunu;

  Map<String, dynamic> toJson() {
    return {
      'id': id,

      'user_id':user_id,
      'olcum_turu':olcum_turu,
      'olcum_sikligi':olcum_sikligi,
      'olcum_saatleri':olcum_saatleri,
      'haftanin_gunu':haftanin_gunu,
      'her_x_gun':her_x_gun,
      'olcum_gecmisi':olcum_gecmisi,


    };
  }

  factory Olcumler.fromJson(Map<String, dynamic> jsonvar) {

    return Olcumler(
      id:jsonvar["id"].toString(),

      user_id: jsonvar["user_id"].toString(),

      olcum_saatleri: jsonvar["olcum_saatleri"].toString(),
      olcum_sikligi: jsonvar["olcum_sikligi"].toString(),
      olcum_turu: jsonvar["olcum_turu"],
      olcum_gecmisi: jsonvar["olcum_gecmisi"],
      her_x_gun: jsonvar["her_x_gun"].toString(),
      haftanin_gunu: jsonvar["haftanin_gunu"].toString(),

    );
  }
}