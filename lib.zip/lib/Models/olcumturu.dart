

class OlcumTuru {
  OlcumTuru({
    required this.id,
    required this.olcum_turu,


  });


  final String id;
  final String olcum_turu;
  factory OlcumTuru.fromJson(Map<String, dynamic> json) {
    return OlcumTuru(
      id: json["id"].toString(),
      olcum_turu: json["olcum_turu"].toString(),



    );
  }

}