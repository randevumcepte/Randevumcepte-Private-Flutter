/*import 'dart:convert';
import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:randevu_sistem/Frontend/popupdialogs.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:package_info_plus/package_info_plus.dart';

// ! import here file animate
import '../Backend/backend.dart';
import '../Frontend/progressloading.dart';
import '../Models/randevuhizmetleri.dart';
import 'login_page.dart';
import 'package:http/http.dart' as http;

class SifremiUnuttum2 extends StatefulWidget {
  final bool randevuSayfasinaYonlendir;
  final List<RandevuHizmet> seciliHizmetler;
  final String tarih;
  final String saat;

  SifremiUnuttum2({
    Key? key,
    required this.randevuSayfasinaYonlendir,
    required this.seciliHizmetler,
    required this.tarih,
    required this.saat,
  }) : super(key: key);

  @override
  _SifremiUnuttumState createState() => _SifremiUnuttumState();
}

class _SifremiUnuttumState extends State<SifremiUnuttum2> {
  final phoneMask = MaskTextInputFormatter(
    mask: '0### ### ## ##',
    filter: {"#": RegExp(r'[0-9]')},
  );
  TextEditingController ceptelefon = TextEditingController();
  bool _isLoading = false;
  final _formKey = GlobalKey<FormState>();
  Timer? _cooldownTimer;
  int _cooldownSeconds = 0;

  @override
  void initState() {
    super.initState();
    ceptelefon.text = "0";
    _checkExistingCooldown();
  }

  @override
  void dispose() {
    _cooldownTimer?.cancel();
    super.dispose();
  }

  // Cooldown kontrolü
  Future<void> _checkExistingCooldown() async {
    final prefs = await SharedPreferences.getInstance();
    final lastRequestTime = prefs.getInt('last_sms_request_time');

    if (lastRequestTime != null) {
      final now = DateTime.now().millisecondsSinceEpoch;
      final diffSeconds = (now - lastRequestTime) ~/ 1000;
      const cooldownDuration = 600; // 10 dakika = 600 saniye

      if (diffSeconds < cooldownDuration) {
        setState(() {
          _cooldownSeconds = cooldownDuration - diffSeconds;
        });
        _startCooldownTimer();
      }
    }
  }

  void _startCooldownTimer() {
    _cooldownTimer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (_cooldownSeconds > 0) {
        setState(() {
          _cooldownSeconds--;
        });
      } else {
        timer.cancel();
        _cooldownTimer = null;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.purple.shade50,
              Colors.purple.shade900,
            ],
          ),
        ),
        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.only(top: 80),
              child: Image.asset(
                'images/edasavutic.png',
                width: 500,
                height: 100,
              ),
            ),
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(50),
                    topRight: Radius.circular(50),
                  ),
                ),
                margin: const EdgeInsets.only(top: 60),
                child: SingleChildScrollView(
                  child: Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        const SizedBox(height: 25),
                        // 🔙 GERİ + BAŞLIK AYNI SATIR
                        Row(
                          children: [
                            IconButton(
                              icon: Icon(Icons.arrow_back,
                                  color: Colors.purple, size: 28),
                              onPressed: () => Navigator.pop(context),
                            ),
                            Expanded(
                              child: Center(
                                child: Text(
                                  "Şifremi Unuttum",
                                  style: TextStyle(
                                    fontSize: 25,
                                    color: Colors.purple,
                                    letterSpacing: 2,
                                    fontFamily: "Lobster",
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(width: 48),
                          ],
                        ),
                        const SizedBox(height: 40),
                        Container(
                          width: double.infinity,
                          height: 50,
                          margin: const EdgeInsets.symmetric(
                              horizontal: 20, vertical: 20),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 15, vertical: 5),
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.purple, width: 1),
                            color: Colors.white,
                            borderRadius: const BorderRadius.all(
                              Radius.circular(20),
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              const Icon(Icons.phone_in_talk),
                              Expanded(
                                child: Container(
                                  margin: const EdgeInsets.only(left: 10),
                                  child: TextFormField(
                                    inputFormatters: [phoneMask],
                                    controller: ceptelefon,
                                    validator: (value) {
                                      if (value == null || value.isEmpty) {
                                        return 'Telefon numarası gerekli';
                                      }
                                      // Sadece rakamları al
                                      final digits = value.replaceAll(RegExp(r'[^0-9]'), '');
                                      if (digits.length < 10) {
                                        return 'Geçerli bir telefon numarası girin';
                                      }
                                      return null;
                                    },
                                    onSaved: (value) {
                                      ceptelefon.text = value!;
                                    },
                                    onTap: () {
                                      if (ceptelefon.text.length < 2) {
                                        ceptelefon.text = "0";
                                      }
                                      ceptelefon.selection =
                                          TextSelection.fromPosition(
                                            TextPosition(
                                                offset: ceptelefon.text.length),
                                          );
                                    },
                                    onChanged: (value) {
                                      if (!value.startsWith("0")) {
                                        ceptelefon.text = "0";
                                        ceptelefon.selection =
                                            TextSelection.fromPosition(
                                              TextPosition(
                                                  offset: ceptelefon.text.length),
                                            );
                                      }
                                    },
                                    keyboardType: TextInputType.number,
                                    maxLines: 1,
                                    decoration: const InputDecoration(
                                      hintText:
                                      " Telefon Numarası (başında 0 olmadan)",
                                      hintStyle: TextStyle(fontSize: 14.2),
                                      border: InputBorder.none,
                                      errorStyle: TextStyle(height: 0),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 10),

                        // Cooldown mesajı
                        if (_cooldownSeconds > 0)
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            child: Text(
                              'Sonraki istek için ${_formatTime(_cooldownSeconds)} bekleyin',
                              style: TextStyle(
                                color: Colors.orange.shade700,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),

                        const SizedBox(height: 10),

                        ElevatedButton(
                          onPressed: _cooldownSeconds > 0 || _isLoading
                              ? null
                              : () {
                            if (_formKey.currentState!.validate()) {
                              _handlePasswordReset();
                            }
                          },
                          style: ElevatedButton.styleFrom(
                            foregroundColor: Colors.purple,
                            backgroundColor: Colors.white,
                            side: BorderSide(color: Colors.purple, width: 1.5),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            elevation: 0,
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            width: 90,
                            height: 40,
                            alignment: Alignment.center,
                            child: _isLoading
                                ? SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                valueColor:
                                AlwaysStoppedAnimation<Color>(Colors.purple),
                              ),
                            )
                                : Text(
                              'Gönder',
                              style: TextStyle(
                                fontSize: 18,
                                color: Colors.purple,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 40),
                      ],
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  String _formatTime(int seconds) {
    final minutes = seconds ~/ 60;
    final remainingSeconds = seconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${remainingSeconds.toString().padLeft(2, '0')}';
  }

  Future<void> _handlePasswordReset() async {
    // 1. İnternet bağlantısı kontrolü
    final connectivityResult = await Connectivity().checkConnectivity();
    if (connectivityResult == ConnectivityResult.none) {
      formWarningDialogs(
        context,
        "İnternet Bağlantısı",
        "İnternet bağlantınız yok. Lütfen bağlantınızı kontrol edin.",
      );
      return;
    }

    // 2. Telefon numarasını temizle
    String tel = ceptelefon.text.replaceAll(RegExp(r'[^0-9]'), '');

    if (tel.length < 10) {
      formWarningDialogs(
        context,
        "UYARI",
        "Lütfen geçerli bir telefon numarası giriniz",
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      // 3. App bilgilerini al
      final packageInfo = await PackageInfo.fromPlatform();
      String appBundle = await appBundleAl();
      String appVersion = packageInfo.version;

      // 4. Device bilgisi (basit)
      final deviceId = await _getDeviceId();

      // 5. API isteği
      final response = await _sendPasswordRequest(
        tel: tel,
        appBundle: appBundle,
        appVersion: appVersion,
        deviceId: deviceId,
      );

      // 6. Cooldown'ı kaydet (her durumda)
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(
          'last_sms_request_time', DateTime.now().millisecondsSinceEpoch);

      print(  'response body '+response.body);
      // 7. Response işleme
      if (response.statusCode == 200) {
        final responseBody = response.body;

        try {
          // JSON response kontrolü
          final jsonResponse = json.decode(responseBody);

          if (jsonResponse is Map) {
            // Yeni API: JSON response
            final message = jsonResponse['message']?.toString() ?? '';
            final success = jsonResponse['success']?.toString() == 'true';

            if (success || message.contains('gönderilecektir')) {
              _showSuccessDialog();
              return;
            }
          }
        } catch (e) {
          // Eski API: "success" veya "error" string
          if (responseBody == "success") {
            _showSuccessDialog();
            return;
          } else if (responseBody == "error") {
            // Generic mesaj göster (bilgi sızdırmadan)
            _showGenericErrorDialog();
            return;
          }
        }

        // Diğer durumlar için generic mesaj
        _showGenericErrorDialog();

      } else if (response.statusCode == 429) {
        // Rate limit hatası
        formWarningDialogs(
          context,
          "Çok Fazla İstek",
          "Çok fazla deneme yaptınız. Lütfen 10 dakika sonra tekrar deneyin.",
        );

        // Cooldown'ı uzat
        await prefs.setInt('last_sms_request_time',
            DateTime.now().millisecondsSinceEpoch - 300000); // 5 dakika önce
        setState(() {
          _cooldownSeconds = 600; // 10 dakika
        });
        _startCooldownTimer();

      } else {
        // Diğer HTTP hataları
        _showGenericErrorDialog();
      }
    } catch (e) {
      // Network veya diğer hatalar
      _showGenericErrorDialog();
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<http.Response> _sendPasswordRequest({
    required String tel,
    required String appBundle,
    required String appVersion,
    required String deviceId,
  }) async {
    Map<String, dynamic> formData = {
      'cep_telefon': tel,
      'sms_baslik': '',
      'sms_apikey': '',
      'salonidler': '249',
      'sms_username': '',
      'sms_secret': '',
      'isletmeadi': 'Eda Savut Güzellik',
      'appBundle': appBundle,
      'appVersion': appVersion,
      'deviceId': deviceId,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    };

    // Timeout ile istek gönder
    return await http
        .post(
      Uri.parse('https://app.randevumcepte.com.tr/api/v1/sifreSifirla'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(formData),
    )
        .timeout(Duration(seconds: 15));
  }

  Future<String> _getDeviceId() async {
    final prefs = await SharedPreferences.getInstance();
    String? deviceId = prefs.getString('device_unique_id');

    if (deviceId == null) {
      // Basit bir device ID oluştur
      deviceId = 'dev_${DateTime.now().millisecondsSinceEpoch}_${Random().nextInt(999999)}';
      await prefs.setString('device_unique_id', deviceId);
    }

    return deviceId;
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Text("Başarılı"),
        content: Text(
          "Eğer bu telefon numarası sistemimizde kayıtlıysa, "
              "şifreniz SMS olarak gönderilecektir.",
          textAlign: TextAlign.center,
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (builder) => LoginPage(
                    randevuSayfasinaYonlendir: widget.randevuSayfasinaYonlendir,
                    seciliHizmetler: widget.seciliHizmetler,
                    tarih: widget.tarih,
                    saat: widget.saat,
                  ),
                ),
              );
            },
            child: Text("Tamam"),
          ),
        ],
      ),
    );
  }

  void _showGenericErrorDialog() {
    formWarningDialogs(
      context,
      "Bilgi",
      "İşleminiz alındı. Eğer telefon numaranız sistemimizde kayıtlıysa, "
          "şifreniz SMS olarak gönderilecektir.",
    );

    // Yine de login sayfasına yönlendir
    /*WidgetsBinding.instance.addPostFrameCallback((_) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (builder) => LoginPage(
            randevuSayfasinaYonlendir: widget.randevuSayfasinaYonlendir,
            seciliHizmetler: widget.seciliHizmetler,
            tarih: widget.tarih,
            saat: widget.saat,
          ),
        ),
      );
    });*/
  }
}*/
import 'dart:convert';
import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:randevu_sistem/Frontend/popupdialogs.dart';

// ! import here file animate
import '../Backend/backend.dart';
import '../Frontend/progressloading.dart';
import '../Models/randevuhizmetleri.dart';
import 'fade_animation.dart';
import 'login_page.dart';
import 'package:http/http.dart' as http;

class SifremiUnuttum extends StatefulWidget {
  final bool randevuSayfasinaYonlendir;
  final List<RandevuHizmet> seciliHizmetler;
  final String tarih;
  final String saat;

  SifremiUnuttum({Key? key,required this.randevuSayfasinaYonlendir, required this.seciliHizmetler,required this.tarih,required this.saat}) : super(key: key);
  @override
  _SifremiUnuttumState createState() => _SifremiUnuttumState();
}

class _SifremiUnuttumState extends State<SifremiUnuttum> {
  final phoneMask = MaskTextInputFormatter(
    mask: '0### ### ## ##',
    filter: { "#": RegExp(r'[0-9]') },
  );
TextEditingController ceptelefon = TextEditingController();
  @override
  void initState() {
    super.initState();
    ceptelefon.text = "0";  // Format en başta görünsün
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Container(
        width: double.infinity,
        decoration: BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  // Colors.purple,
                  Colors.purple.shade50,
                  Colors.purple.shade900,
                ])),
        child: Column(
          children: [

            Container(
                margin: const EdgeInsets.only(top: 80),
                child:
                  Image.asset(
                    'images/aydangurece.png',  // Replace with your image path
                    width: 500,  // Adjust width if needed
                    height: 100,  // Adjust height if needed
                  ),
                ),
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(50),
                    topRight: Radius.circular(50),
                  ),
                ),
                margin: const EdgeInsets.only(top: 60),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      const SizedBox(height: 25),

                      // 🔙 GERİ + BAŞLIK AYNI SATIR
                      Row(
                        children: [
                          // Geri Butonu
                          IconButton(
                            icon: Icon(Icons.arrow_back, color: Colors.purple, size: 28),
                            onPressed: () => Navigator.pop(context),
                          ),

                          // Başlık ortalı kalsın diye Expanded
                          Expanded(
                            child: Center(
                              child:
                                Text(
                                  "Şifremi Unuttum",
                                  style: TextStyle(
                                    fontSize: 25,
                                    color: Colors.purple,
                                    letterSpacing: 2,
                                    fontFamily: "Lobster",
                                  ),
                                ),
                              ),
                            ),


                          // Sağ tarafı dengelemek için boş ikon kadar yer
                          SizedBox(width: 48),
                        ],
                      ),

                      const SizedBox(height: 40),


                        Container(
                          width: double.infinity,
                          height: 50,
                          margin:
                          const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                          padding:
                          const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                          decoration: BoxDecoration(
                            border:
                            Border.all(color: Colors.purple, width: 1),
                            color: Colors.white,
                            borderRadius: const BorderRadius.all(
                              Radius.circular(20),
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              const Icon(Icons.phone_in_talk),
                              Expanded(
                                child: Container(
                                  margin: const EdgeInsets.only(left: 10),
                                  child: TextFormField(
                                    inputFormatters: [phoneMask],
                                    controller: ceptelefon,
                                    onSaved: (value) {
                                      ceptelefon.text = value!;
                                    },
                                    onTap: () {
                                      if (ceptelefon.text.length < 2) {
                                        ceptelefon.text = "0";
                                      }
                                      ceptelefon.selection =
                                          TextSelection.fromPosition(
                                            TextPosition(
                                                offset: ceptelefon.text.length),
                                          );
                                    },
                                    onChanged: (value) {
                                      if (!value.startsWith("0")) {
                                        ceptelefon.text = "0";
                                        ceptelefon.selection =
                                            TextSelection.fromPosition(
                                              TextPosition(
                                                  offset: ceptelefon.text.length),
                                            );
                                      }
                                    },
                                    keyboardType: TextInputType.number,
                                    maxLines: 1,
                                    decoration: const InputDecoration(
                                      hintText:
                                      " Telefon Numarası (başında 0 olmadan)",
                                      hintStyle: TextStyle(fontSize: 14.2),
                                      border: InputBorder.none,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),


                      const SizedBox(height: 10),

                      ElevatedButton(
                        onPressed: () {
                          if (ceptelefon.text == '' || ceptelefon.text == '0') {
                            formWarningDialogs(
                              context,
                              "UYARI",
                              "Lütfen sisteme kayıtlı olan telefon numaranızı başında 0 olmadan giriniz",
                            );
                          } else {
                            sifregonder(
                              ceptelefon.text,
                              context,
                              widget.randevuSayfasinaYonlendir,
                            );
                          }
                        },
                        style: ElevatedButton.styleFrom(
                          foregroundColor: Colors.purple,
                          backgroundColor: Colors.white,
                          side: BorderSide(color: Colors.purple, width: 1.5),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          elevation: 0,
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 90,
                          height: 40,
                          alignment: Alignment.center,
                          child: Text(
                            'Gönder',
                            style: TextStyle(
                              fontSize: 18,
                              color: Colors.purple,
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: 40),
                    ],
                  ),
                ),
              ),
            )


          ],
        ),
      ),
    );
  }
  Future<void> sifregonder(String tel,context,bool randevuSayfasinaYonlendir) async {
    showProgressLoading(context);
    String appBundle = await appBundleAl();


    Map<String, dynamic> formData = {
      'cep_telefon':tel,
      'sms_baslik' : '',
      'sms_apikey' : '',
      'salonidler' : '331',
      'sms_username':'',
      'sms_secret':'',
      'isletmeadi': 'Aydan Gürece Güzellik',
      'appBundle': appBundle
      // Add other form fields
    };

    final response = await http.post(
      Uri.parse('https://app.randevumcepte.com.tr/api/v1/sifregonder'),

      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(formData),
    );

    if (response.statusCode == 200) {
      log("cevap body "+response.body);
      Navigator.of(context,rootNavigator: true).pop();
      if(response.body=="error")
        formWarningDialogs(context, "HATA", "Sistemde kayıtlı telefon numarası bulunamadı!");
      else
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (builder) => LoginPage(randevuSayfasinaYonlendir: randevuSayfasinaYonlendir,seciliHizmetler:widget.seciliHizmetler,tarih: widget.tarih,saat: widget.saat,),
          ),
        );




    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Şifreniz gönderilirken bir hata oluştu : '+response.statusCode.toString()),
        ),
      );
      debugPrint('Error: ${response.body}');
    }
  }

}